<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Parâmetros de filtro
$categoria_id = intval($_GET['categoria'] ?? 0);
$marca_id = intval($_GET['marca'] ?? 0);
$promocao = isset($_GET['promocao']) ? 1 : 0;
$busca = trim($_GET['busca'] ?? '');

// Buscar produtos
try {
    $pdo = conectarBanco();
    
    // Construir query base
    $sql = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
            FROM produtos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            LEFT JOIN marcas m ON p.marca_id = m.id 
            WHERE p.ativo = 1";
    
    $params = [];
    
    // Aplicar filtros
    if ($categoria_id > 0) {
        $sql .= " AND p.categoria_id = ?";
        $params[] = $categoria_id;
    }
    
    if ($marca_id > 0) {
        $sql .= " AND p.marca_id = ?";
        $params[] = $marca_id;
    }
    
    if ($promocao) {
        $sql .= " AND p.em_promocao = 1";
    }
    
    if (!empty($busca)) {
        $sql .= " AND (p.nome LIKE ? OR p.descricao LIKE ? OR m.nome LIKE ?)";
        $search_term = "%$busca%";
        $params[] = $search_term;
        $params[] = $search_term;
        $params[] = $search_term;
    }
    
    $sql .= " ORDER BY p.em_destaque DESC, p.data_cadastro DESC";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar categorias para o filtro
    $sql_categorias = "SELECT * FROM categorias WHERE ativo = 1 ORDER BY nome";
    $categorias = $pdo->query($sql_categorias)->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar marcas para o filtro
    $sql_marcas = "SELECT * FROM marcas WHERE ativo = 1 ORDER BY nome";
    $marcas = $pdo->query($sql_marcas)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $produtos = [];
    $categorias = [];
    $marcas = [];
    error_log("Erro ao carregar produtos: " . $e->getMessage());
}

// Buscar categoria atual (se filtrada)
$categoria_atual = null;
if ($categoria_id > 0) {
    foreach ($categorias as $cat) {
        if ($cat['id'] == $categoria_id) {
            $categoria_atual = $cat;
            break;
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Produtos - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <style>
        .product-card {
            transition: transform 0.3s, box-shadow 0.3s;
            border: 1px solid #dee2e6;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        .price-original {
            text-decoration: line-through;
            color: #6c757d;
            font-size: 0.9em;
        }
        .price-promotional {
            color: #dc3545;
            font-weight: bold;
            font-size: 1.2em;
        }
        .filter-section {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
        }
        .badge-promocao {
            position: absolute;
            top: 10px;
            left: 10px;
            z-index: 1;
        }
        .wishlist-btn {
            position: absolute;
            top: 10px;
            right: 10px;
            z-index: 1;
        }
        .categoria-icon {
            font-size: 1.2em;
            margin-right: 8px;
        }
    </style>
</head>
<body>
    <?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <!-- Filtros -->
            <div class="col-lg-3 mb-4">
                <div class="filter-section" style="position: static;">
                    <h5 class="mb-3">
                        <i class="fas fa-filter me-2"></i>
                        Filtros
                    </h5>
                    
                    <!-- Categorias -->
                    <div class="mb-4">
                        <h6 class="text-primary">Categorias</h6>
                        <div class="list-group list-group-flush">
                            <a href="produtos.php" class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= !$categoria_id ? 'active' : '' ?>">
                                <span>
                                    <i class="fas fa-th-large categoria-icon"></i>
                                    Todas as Categorias
                                </span>
                                <span class="badge bg-primary rounded-pill"><?= count($produtos) ?></span>
                            </a>
                            <?php foreach ($categorias as $categoria): ?>
                            <a href="produtos.php?categoria=<?= $categoria['id'] ?>" 
                               class="list-group-item list-group-item-action d-flex justify-content-between align-items-center <?= $categoria_id == $categoria['id'] ? 'active' : '' ?>">
                                <span>
                                    <i class="fas fa-<?= getCategoriaIcon($categoria['nome']) ?> categoria-icon"></i>
                                    <?= htmlspecialchars($categoria['nome']) ?>
                                </span>
                                <span class="badge bg-secondary rounded-pill">
                                    <?= array_reduce($produtos, function($count, $prod) use ($categoria) {
                                        return $count + ($prod['categoria_id'] == $categoria['id'] ? 1 : 0);
                                    }, 0) ?>
                                </span>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Marcas -->
                    <div class="mb-4">
                        <h6 class="text-primary">Marcas</h6>
                        <div class="list-group list-group-flush">
                            <a href="produtos.php<?= $categoria_id ? "?categoria=$categoria_id" : '' ?>" 
                               class="list-group-item list-group-item-action <?= !$marca_id ? 'active' : '' ?>">
                                <i class="fas fa-tags me-2"></i>
                                Todas as Marcas
                            </a>
                            <?php foreach ($marcas as $marca): ?>
                            <a href="produtos.php?<?= $categoria_id ? "categoria=$categoria_id&" : '' ?>marca=<?= $marca['id'] ?>" 
                               class="list-group-item list-group-item-action <?= $marca_id == $marca['id'] ? 'active' : '' ?>">
                                <i class="fas fa-copyright me-2"></i>
                                <?= htmlspecialchars($marca['nome']) ?>
                            </a>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    
                    <!-- Promoções -->
                    <div class="mb-3">
                        <h6 class="text-primary">Ofertas</h6>
                        <a href="produtos.php?promocao=1<?= $categoria_id ? "&categoria=$categoria_id" : '' ?><?= $marca_id ? "&marca=$marca_id" : '' ?>" 
                           class="btn btn-outline-danger w-100 <?= $promocao ? 'active' : '' ?>">
                            <i class="fas fa-tag me-2"></i>
                            Produtos em Promoção
                        </a>
                    </div>
                </div>
            </div>

            <!-- Lista de Produtos -->
            <div class="col-lg-9">
                <!-- Cabeçalho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <div>
                        <h1 class="h3 mb-1">
                            <?php if ($categoria_atual): ?>
                                <i class="fas fa-<?= getCategoriaIcon($categoria_atual['nome']) ?> me-2 text-primary"></i>
                                <?= htmlspecialchars($categoria_atual['nome']) ?>
                            <?php elseif ($promocao): ?>
                                <i class="fas fa-tag me-2 text-danger"></i>
                                Produtos em Promoção
                            <?php elseif (!empty($busca)): ?>
                                <i class="fas fa-search me-2 text-primary"></i>
                                Resultados para "<?= htmlspecialchars($busca) ?>"
                            <?php else: ?>
                                <i class="fas fa-boxes me-2 text-primary"></i>
                                Todos os Produtos
                            <?php endif; ?>
                        </h1>
                        <p class="text-muted mb-0">
                            <?= count($produtos) ?> produto(s) encontrado(s)
                        </p>
                    </div>
                </div>

                <?php mostrarMensagem(); ?>

                <!-- Grid de Produtos -->
                <?php if (empty($produtos)): ?>
                    <div class="text-center py-5">
                        <i class="fas fa-box-open fa-4x text-muted mb-3"></i>
                        <h4 class="text-muted">Nenhum produto encontrado</h4>
                        <p class="text-muted">Tente ajustar os filtros ou buscar por outros termos.</p>
                        <a href="produtos.php" class="btn btn-primary">
                            <i class="fas fa-redo me-2"></i>
                            Ver Todos os Produtos
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <?php foreach ($produtos as $produto): ?>
                        <div class="col-xl-3 col-lg-4 col-md-6 mb-4">
                            <div class="card h-100 product-card">
                                <div class="position-relative">
                                    <?php if ($produto['em_promocao']): ?>
                                        <span class="badge bg-danger badge-promocao">-<?= calcularDesconto($produto['preco'], $produto['preco_promocional']) ?>%</span>
                                    <?php elseif ($produto['em_destaque']): ?>
                                        <span class="badge bg-warning badge-promocao">Destaque</span>
                                    <?php endif; ?>
                                    
                                    <button class="btn btn-outline-danger btn-sm wishlist-btn" 
                                            data-product="<?= $produto['id'] ?>"
                                            onclick="toggleWishlist(<?= $produto['id'] ?>)">
                                        <i class="far fa-heart"></i>
                                    </button>
                                    
                                    <!-- IMAGEM CORRIGIDA AQUI -->
                                    <img src="uploads/imagens_produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                                         class="card-img-top" 
                                         alt="<?= htmlspecialchars($produto['nome']) ?>"
                                         style="height: 200px; object-fit: cover; background: #f8f9fa;"
                                         onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                                    </img>
                                </div>
                                
                                <div class="card-body d-flex flex-column">
                                    <div class="mb-2">
                                        <span class="badge bg-secondary"><?= htmlspecialchars($produto['marca_nome']) ?></span>
                                    </div>
                                    
                                    <h6 class="card-title"><?= htmlspecialchars($produto['nome']) ?></h6>
                                    
                                    <p class="card-text text-muted small flex-grow-1">
                                        <?= truncateText($produto['descricao'] ?? 'Descrição não disponível', 80) ?>
                                    </p>
                                    
                                    <div class="mt-auto">
                                        <!-- Avaliação -->
                                        <?php if ($produto['media_avaliacoes'] > 0): ?>
                                        <div class="mb-2">
                                            <small class="text-warning">
                                                <?= str_repeat('★', round($produto['media_avaliacoes'])) ?><?= str_repeat('☆', 5 - round($produto['media_avaliacoes'])) ?>
                                                <span class="text-muted">(<?= $produto['total_avaliacoes'] ?>)</span>
                                            </small>
                                        </div>
                                        <?php endif; ?>
                                        
                                        <!-- Preço -->
                                        <div class="mb-2">
                                            <?php if ($produto['em_promocao'] && $produto['preco_promocional']): ?>
                                                <span class="price-promotional">
                                                    R$ <?= number_format($produto['preco_promocional'], 2, ',', '.') ?>
                                                </span>
                                                <br>
                                                <span class="price-original">
                                                    R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                                </span>
                                            <?php else: ?>
                                                <span class="h6 text-primary">
                                                    R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        
                                        <!-- Estoque -->
                                        <div class="mb-2">
                                            <small class="<?= $produto['estoque'] > 0 ? 'text-success' : 'text-danger' ?>">
                                                <i class="fas fa-<?= $produto['estoque'] > 0 ? 'check' : 'times' ?> me-1"></i>
                                                <?= $produto['estoque'] > 0 ? 'Em estoque' : 'Fora de estoque' ?>
                                            </small>
                                        </div>
                                        
                                       <!-- Botões -->
<div class="d-grid gap-2">
    <a href="produto.php?id=<?= $produto['id'] ?>" class="btn btn-outline-primary btn-sm">
        <i class="fas fa-eye me-1"></i>
        Ver Detalhes
    </a>
    <?php if ($produto['estoque'] > 0): ?>
        <form method="GET" action="includes/processa_carrinho.php" class="d-inline">
            <input type="hidden" name="action" value="add">
            <input type="hidden" name="product_id" value="<?= $produto['id'] ?>">
            <input type="hidden" name="quantity" value="1">
            <button type="submit" class="btn btn-primary btn-sm w-100">
                <i class="fas fa-cart-plus me-1"></i>
                Adicionar
            </button>
        </form>
    <?php else: ?>
        <button class="btn btn-secondary btn-sm" disabled>
            <i class="fas fa-bell me-1"></i>
            Avise-me
        </button>
    <?php endif; ?>
</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Função para Wishlist
        function toggleWishlist(productId) {
            <?php if (usuarioEstaLogado()): ?>
                const btn = document.querySelector(`.wishlist-btn[data-product="${productId}"]`);
                const icon = btn.querySelector('i');
                
                if (icon.classList.contains('far')) {
                    // Adicionar
                    fetch(`includes/processa_wishlist.php?action=add&product_id=${productId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                icon.classList.remove('far');
                                icon.classList.add('fas');
                                btn.classList.remove('btn-outline-danger');
                                btn.classList.add('btn-danger');
                                showToast('Produto adicionado à lista de desejos!', 'success');
                            } else {
                                showToast(data.message || 'Erro ao adicionar', 'error');
                            }
                        });
                } else {
                    // Remover
                    fetch(`includes/processa_wishlist.php?action=remove&product_id=${productId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                icon.classList.remove('fas');
                                icon.classList.add('far');
                                btn.classList.remove('btn-danger');
                                btn.classList.add('btn-outline-danger');
                                showToast('Produto removido da lista de desejos!', 'success');
                            } else {
                                showToast(data.message || 'Erro ao remover', 'error');
                            }
                        });
                }
            <?php else: ?>
                window.location.href = 'login.php?redirect=produtos';
            <?php endif; ?>
        }

        // Função para mostrar toast
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
            toast.setAttribute('role', 'alert');
            toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;
            
            let toastContainer = document.getElementById('toast-container');
            if (!toastContainer) {
                toastContainer = document.createElement('div');
                toastContainer.id = 'toast-container';
                toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
                document.body.appendChild(toastContainer);
            }
            
            toastContainer.appendChild(toast);
            const bsToast = new bootstrap.Toast(toast);
            bsToast.show();
            
            toast.addEventListener('hidden.bs.toast', () => {
                toast.remove();
            });
        }
    </script>
</body>
</html>

<?php
// Funções auxiliares
function getCategoriaIcon($categoria) {
    $icons = [
        'Teclados' => 'keyboard',
        'Mouses' => 'mouse',
        'Headsets' => 'headphones',
        'Monitores' => 'desktop',
        'Mousepads' => 'mouse-pointer',
        'Webcams' => 'video',
        'Microfones' => 'microphone'
    ];
    return $icons[$categoria] ?? 'box';
}

function calcularDesconto($precoOriginal, $precoPromocional) {
    if (!$precoPromocional || $precoPromocional >= $precoOriginal) {
        return 0;
    }
    $desconto = (($precoOriginal - $precoPromocional) / $precoOriginal) * 100;
    return round($desconto);
}