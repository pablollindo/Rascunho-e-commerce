<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se pode gerenciar funcionários
if (!podeGerenciarFuncionarios()) {
    $_SESSION['erro'] = "Acesso restrito.";
    header("Location: ../indexx.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$usuario_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

try {
    $pdo = conectarBanco();
    
    switch ($action) {
        case 'edit':
            $usuario = null;
            if ($usuario_id > 0) {
                $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE id = ?");
                $stmt->execute([$usuario_id]);
                $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$usuario) {
                    $_SESSION['erro'] = "Usuário não encontrado.";
                    header("Location: admin_usuarios.php");
                    exit;
                }
            }
            break;
            
        case 'toggle_status':
            if ($usuario_id > 0) {
                // Buscar status atual
                $stmt = $pdo->prepare("SELECT ativo FROM usuarios WHERE id = ?");
                $stmt->execute([$usuario_id]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($result) {
                    $novo_status = $result['ativo'] ? 0 : 1;
                    $stmt = $pdo->prepare("UPDATE usuarios SET ativo = ? WHERE id = ?");
                    $stmt->execute([$novo_status, $usuario_id]);
                    
                    $acao = $novo_status ? 'ativado' : 'desativado';
                    $_SESSION['sucesso'] = "Usuário {$acao} com sucesso!";
                }
            }
            header("Location: admin_usuarios.php");
            exit;
            
        case 'delete':
            if ($usuario_id > 0 && podeGerenciarFuncionarios()) {
                try {
                    $pdo->beginTransaction();
                    
                    // 1. Primeiro excluir os ITENS dos pedidos desse cliente
                    $stmt = $pdo->prepare("DELETE ip FROM itens_pedido ip 
                                         JOIN pedidos p ON ip.pedido_id = p.id 
                                         WHERE p.cliente_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 2. Agora excluir os PEDIDOS do cliente
                    $stmt = $pdo->prepare("DELETE FROM pedidos WHERE cliente_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 3. Excluir da tabela clientes
                    $stmt = $pdo->prepare("DELETE FROM clientes WHERE usuario_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 4. Excluir endereços
                    $stmt = $pdo->prepare("DELETE FROM enderecos WHERE usuario_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 5. Excluir wishlist
                    $stmt = $pdo->prepare("DELETE FROM wishlist WHERE usuario_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 6. Excluir avaliações
                    $stmt = $pdo->prepare("DELETE FROM avaliacoes WHERE usuario_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 7. Excluir mensagens de suporte
                    $stmt = $pdo->prepare("DELETE ms FROM mensagens_suporte ms 
                                         JOIN tickets_suporte ts ON ms.ticket_id = ts.id 
                                         WHERE ts.usuario_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 8. Excluir tickets de suporte
                    $stmt = $pdo->prepare("DELETE FROM tickets_suporte WHERE usuario_id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    // 9. Finalmente excluir o usuário
                    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE id = ?");
                    $stmt->execute([$usuario_id]);
                    
                    $pdo->commit();
                    $_SESSION['sucesso'] = "Cliente e todos os dados relacionados (incluindo pedidos) excluídos permanentemente com sucesso!";
                    
                } catch (Exception $e) {
                    $pdo->rollBack();
                    $_SESSION['erro'] = "Erro ao excluir cliente: " . $e->getMessage();
                }
            } else {
                $_SESSION['erro'] = "Acesso negado para exclusão.";
            }
            header("Location: admin_usuarios.php");
            exit;
            
        case 'save':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $dados = [
                    'nome' => trim($_POST['nome']),
                    'email' => trim($_POST['email']),
                    'cpf' => trim($_POST['cpf']),
                    'telefone' => trim($_POST['telefone']),
                    'data_nascimento' => $_POST['data_nascimento'],
                    'ativo' => isset($_POST['ativo']) ? 1 : 0
                ];
                
                if (empty($dados['nome']) || empty($dados['email'])) {
                    $_SESSION['erro'] = "Nome e email são obrigatórios.";
                    header("Location: admin_usuarios.php?action=edit&id=" . $_POST['id']);
                    exit;
                }
                
                // Verificar se email já existe (para outro usuário)
                if ($_POST['id']) {
                    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ? AND id != ?");
                    $stmt->execute([$dados['email'], $_POST['id']]);
                } else {
                    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE email = ?");
                    $stmt->execute([$dados['email']]);
                }
                
                if ($stmt->fetch()) {
                    $_SESSION['erro'] = "Este email já está cadastrado para outro usuário.";
                    header("Location: admin_usuarios.php?action=edit&id=" . ($_POST['id'] ?? ''));
                    exit;
                }
                
                if ($_POST['id']) {
                    // Atualizar usuário
                    $stmt = $pdo->prepare("UPDATE usuarios SET nome = ?, email = ?, cpf = ?, telefone = ?, data_nascimento = ?, ativo = ? WHERE id = ?");
                    $dados[] = $_POST['id'];
                    $stmt->execute(array_values($dados));
                    $_SESSION['sucesso'] = "Usuário atualizado com sucesso!";
                }
                
                header("Location: admin_usuarios.php");
                exit;
            }
            break;
    }
    
    // Buscar APENAS clientes (tipo = 'cliente')
    $sql_usuarios = "SELECT u.*, 
                    (SELECT COUNT(*) FROM pedidos WHERE cliente_id = u.id) as total_pedidos,
                    (SELECT SUM(total) FROM pedidos WHERE cliente_id = u.id AND status = 'entregue') as total_gasto
                   FROM usuarios u 
                   WHERE u.tipo = 'cliente'
                   ORDER BY u.data_cadastro DESC";
    $usuarios = $pdo->query($sql_usuarios)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro no banco de dados: " . $e->getMessage();
    $usuarios = [];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Clientes - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php 
    $tituloPagina = "Gerenciar Clientes - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>Produtos
                        </a>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>Estoque
                        </a>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>Categorias & Marcas
                        </a>
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>Pedidos
                        </a>
                        <?php if (podeGerenciarUsuarios()): ?>
                        <a href="admin_usuarios.php" class="nav-link active">
                            <i class="fas fa-users me-2"></i>Clientes
                        </a>
                        <?php endif; ?>
                        <?php if (podeVerFuncionarios()): ?>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>Funcionários
                        </a>
                        <?php endif; ?>
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>Suporte
                        </a>
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>Relatórios
                        </a>
                        <hr class="bg-light my-3">
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-users me-2"></i>
                                Gerenciar Clientes
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <span class="badge bg-primary fs-6">
                                    Total: <?= count($usuarios) ?> clientes
                                </span>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <?php if ($action === 'edit'): ?>
                        <!-- Formulário de Edição -->
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-edit me-2"></i>
                                    Editar Cliente
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="admin_usuarios.php?action=save">
                                    <input type="hidden" name="id" value="<?= $usuario['id'] ?>">
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="nome" class="form-label">Nome Completo *</label>
                                            <input type="text" class="form-control" id="nome" name="nome" 
                                                   value="<?= htmlspecialchars($usuario['nome']) ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label">Email *</label>
                                            <input type="email" class="form-control" id="email" name="email" 
                                                   value="<?= htmlspecialchars($usuario['email']) ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label for="cpf" class="form-label">CPF</label>
                                            <input type="text" class="form-control" id="cpf" name="cpf" 
                                                   value="<?= htmlspecialchars($usuario['cpf'] ?? '') ?>">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="telefone" class="form-label">Telefone</label>
                                            <input type="text" class="form-control" id="telefone" name="telefone" 
                                                   value="<?= htmlspecialchars($usuario['telefone'] ?? '') ?>">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="data_nascimento" class="form-label">Data de Nascimento</label>
                                            <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" 
                                                   value="<?= $usuario['data_nascimento'] ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <div class="form-check form-switch">
                                            <input type="checkbox" class="form-check-input" id="ativo" name="ativo" 
                                                   <?= $usuario['ativo'] ? 'checked' : '' ?>>
                                            <label class="form-check-label" for="ativo">Usuário ativo</label>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between">
                                        <a href="admin_usuarios.php" class="btn btn-secondary">
                                            <i class="fas fa-arrow-left me-2"></i>
                                            Voltar
                                        </a>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-save me-2"></i>
                                            Atualizar Cliente
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Lista de Clientes -->
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Cliente</th>
                                                <th>Contato</th>
                                                <th>Cadastro</th>
                                                <th>Pedidos</th>
                                                <th>Total Gasto</th>
                                                <th>Status</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($usuarios)): ?>
                                                <tr>
                                                    <td colspan="8" class="text-center py-4 text-muted">
                                                        <i class="fas fa-users fa-2x mb-3"></i><br>
                                                        Nenhum cliente cadastrado.
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($usuarios as $user): ?>
                                                <tr>
                                                    <td>#<?= $user['id'] ?></td>
                                                    <td>
                                                        <strong><?= htmlspecialchars($user['nome']) ?></strong>
                                                        <br>
                                                        <small class="text-muted">CPF: <?= $user['cpf'] ?? 'N/A' ?></small>
                                                    </td>
                                                    <td>
                                                        <div>
                                                            <i class="fas fa-envelope me-1 text-muted"></i>
                                                            <?= htmlspecialchars($user['email']) ?>
                                                            <?php if ($user['telefone']): ?>
                                                                <br>
                                                                <i class="fas fa-phone me-1 text-muted"></i>
                                                                <?= htmlspecialchars($user['telefone']) ?>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td>
                                                        <?= date('d/m/Y', strtotime($user['data_cadastro'])) ?>
                                                        <br>
                                                        <small class="text-muted">
                                                            <?= date('H:i', strtotime($user['data_cadastro'])) ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-info">
                                                            <?= $user['total_pedidos'] ?> pedidos
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <strong>R$ <?= number_format($user['total_gasto'] ?? 0, 2, ',', '.') ?></strong>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= $user['ativo'] ? 'success' : 'secondary' ?>">
                                                            <?= $user['ativo'] ? 'Ativo' : 'Inativo' ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="admin_usuarios.php?action=edit&id=<?= $user['id'] ?>" 
                                                               class="btn btn-outline-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <a href="admin_usuarios.php?action=toggle_status&id=<?= $user['id'] ?>" 
                                                               class="btn btn-outline-<?= $user['ativo'] ? 'warning' : 'success' ?>" 
                                                               onclick="return confirm('Tem certeza que deseja <?= $user['ativo'] ? 'desativar' : 'ativar' ?> este cliente?')"
                                                               title="<?= $user['ativo'] ? 'Desativar' : 'Ativar' ?>">
                                                                <i class="fas fa-<?= $user['ativo'] ? 'user-slash' : 'user-check' ?>"></i>
                                                            </a>
                                                            <?php if (podeGerenciarFuncionarios()): ?>
                                                            <a href="admin_usuarios.php?action=delete&id=<?= $user['id'] ?>" 
                                                               class="btn btn-outline-danger" 
                                                               onclick="return confirm('🚨🚨🚨 EXCLUSÃO PERMANENTE - ALERTA CRÍTICO 🚨🚨🚨\n\n📋 O QUE SERÁ REMOVIDO PERMANENTEMENTE:\n• ✅ TODOS os dados pessoais do cliente\n• ✅ TODOS os endereços cadastrados\n• ✅ TODOS os pedidos deste cliente\n• ✅ TODOS os itens desses pedidos\n• ✅ TODOS os produtos da lista de desejos\n• ✅ TODAS as avaliações feitas\n• ✅ TODOS os tickets de suporte\n• ✅ TODAS as mensagens de suporte\n\n⚠️ RISCOS E CONSEQUÊNCIAS:\n• 📊 Relatórios de vendas serão afetados\n• 📈 Estatísticas de pedidos serão alteradas\n• 🔍 Histórico comercial será perdido\n• 💰 Dados financeiros serão removidos\n• 🗃️ Backup não restaurará esses dados\n\n❌ ESTA AÇÃO É:\n• 🔥 IRREVERSÍVEL\n• 🚫 SEM VOLTA\n• 💀 PERMANENTE\n\n🔒 CONFIRMA ABSOLUTA EXCLUSÃO?')"
                                                               title="Excluir Permanentemente - CUIDADO!">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Estatísticas -->
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="card text-white bg-primary">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Total Clientes</h6>
                                        <p class="card-text h4"><?= count($usuarios) ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-success">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Clientes Ativos</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($usuarios, function($u) { return $u['ativo']; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-warning">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Com Pedidos</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($usuarios, function($u) { return $u['total_pedidos'] > 0; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-info">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Novos (30 dias)</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($usuarios, function($u) { 
                                                return strtotime($u['data_cadastro']) >= strtotime('-30 days'); 
                                            })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>