<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se pode ver relatórios
if (!podeVerRelatorios()) {
    $_SESSION['erro'] = "Acesso restrito.";
    header("Location: ../indexx.php");
    exit;
}

// Parâmetros de filtro
$periodo = $_GET['periodo'] ?? 'hoje';
$data_inicio = $_GET['data_inicio'] ?? date('Y-m-d', strtotime('-7 days'));
$data_fim = $_GET['data_fim'] ?? date('Y-m-d');

try {
    $pdo = conectarBanco();
    
    // Definir período baseado no filtro
    switch ($periodo) {
        case 'hoje':
            $data_inicio = date('Y-m-d');
            $data_fim = date('Y-m-d');
            break;
        case 'ontem':
            $data_inicio = date('Y-m-d', strtotime('-1 day'));
            $data_fim = date('Y-m-d', strtotime('-1 day'));
            break;
        case 'semana':
            $data_inicio = date('Y-m-d', strtotime('-7 days'));
            $data_fim = date('Y-m-d');
            break;
        case 'mes':
            $data_inicio = date('Y-m-01');
            $data_fim = date('Y-m-t');
            break;
        case 'custom':
            // Usar datas personalizadas
            break;
    }
    
    // Estatísticas gerais
    $sql_estatisticas = "
        SELECT 
            COUNT(*) as total_pedidos,
            SUM(CASE WHEN status = 'entregue' THEN total ELSE 0 END) as total_vendido,
            SUM(CASE WHEN status = 'entregue' THEN 1 ELSE 0 END) as pedidos_entregues,
            AVG(CASE WHEN status = 'entregue' THEN total ELSE NULL END) as ticket_medio,
            COUNT(DISTINCT cliente_id) as clientes_ativos
        FROM pedidos 
        WHERE DATE(data_pedido) BETWEEN ? AND ?
    ";
    $stmt = $pdo->prepare($sql_estatisticas);
    $stmt->execute([$data_inicio, $data_fim]);
    $estatisticas = $stmt->fetch(PDO::FETCH_ASSOC);
    
    // Vendas por dia (para gráfico)
    $sql_vendas_dia = "
        SELECT 
            DATE(data_pedido) as data,
            COUNT(*) as total_pedidos,
            SUM(total) as total_vendas
        FROM pedidos 
        WHERE status = 'entregue' AND DATE(data_pedido) BETWEEN ? AND ?
        GROUP BY DATE(data_pedido)
        ORDER BY data
    ";
    $stmt = $pdo->prepare($sql_vendas_dia);
    $stmt->execute([$data_inicio, $data_fim]);
    $vendas_dia = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Produtos mais vendidos
    $sql_produtos_vendidos = "
        SELECT 
            p.nome,
            p.marca_id,
            m.nome as marca_nome,
            SUM(ip.quantidade) as total_vendido,
            SUM(ip.quantidade * ip.preco_unitario) as total_faturado
        FROM itens_pedido ip
        JOIN produtos p ON ip.produto_id = p.id
        LEFT JOIN marcas m ON p.marca_id = m.id
        JOIN pedidos ped ON ip.pedido_id = ped.id
        WHERE ped.status = 'entregue' AND DATE(ped.data_pedido) BETWEEN ? AND ?
        GROUP BY p.id, p.nome
        ORDER BY total_vendido DESC
        LIMIT 10
    ";
    $stmt = $pdo->prepare($sql_produtos_vendidos);
    $stmt->execute([$data_inicio, $data_fim]);
    $produtos_vendidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Métodos de pagamento
    $sql_metodos_pagamento = "
        SELECT 
            metodo_pagamento,
            COUNT(*) as total_pedidos,
            SUM(total) as total_vendas
        FROM pedidos 
        WHERE status = 'entregue' AND DATE(data_pedido) BETWEEN ? AND ?
        GROUP BY metodo_pagamento
        ORDER BY total_vendas DESC
    ";
    $stmt = $pdo->prepare($sql_metodos_pagamento);
    $stmt->execute([$data_inicio, $data_fim]);
    $metodos_pagamento = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Clientes que mais compraram
    $sql_melhores_clientes = "
        SELECT 
            u.nome,
            u.email,
            COUNT(p.id) as total_pedidos,
            SUM(p.total) as total_gasto
        FROM pedidos p
        JOIN usuarios u ON p.cliente_id = u.id
        WHERE p.status = 'entregue' AND DATE(p.data_pedido) BETWEEN ? AND ?
        GROUP BY u.id, u.nome
        ORDER BY total_gasto DESC
        LIMIT 10
    ";
    $stmt = $pdo->prepare($sql_melhores_clientes);
    $stmt->execute([$data_inicio, $data_fim]);
    $melhores_clientes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar relatórios: " . $e->getMessage();
    $estatisticas = [];
    $vendas_dia = [];
    $produtos_vendidos = [];
    $metodos_pagamento = [];
    $melhores_clientes = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
        .stat-card {
            transition: transform 0.3s;
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .stat-card:hover {
            transform: translateY(-5px);
        }
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
    </style>
</head>
<body>
    <?php 
    $tituloPagina = "Relatórios - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            Dashboard
                        </a>
                        
                        <?php if (podeGerenciarProdutos()): ?>
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>
                            Produtos
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarEstoque()): ?>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>
                            Estoque
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarCategorias()): ?>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>
                            Categorias & Marcas
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos
                        </a>
                        
                        <?php if (podeGerenciarUsuarios()): ?>
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>
                            Clientes
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarFuncionarios()): ?>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>
                            Funcionários
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>
                            Suporte
                        </a>
                        
                        <a href="admin_relatorios.php" class="nav-link active">
                            <i class="fas fa-chart-bar me-2"></i>
                            Relatórios
                        </a>
                        
                        <hr class="bg-light my-3">
                        
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>
                            Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-chart-bar me-2"></i>
                                Relatórios de Vendas
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <button class="btn btn-outline-primary" onclick="window.print()">
                                    <i class="fas fa-print me-2"></i>
                                    Imprimir Relatório
                                </button>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <!-- Filtros -->
                    <div class="card mb-4">
                        <div class="card-header bg-light">
                            <h5 class="mb-0">
                                <i class="fas fa-filter me-2"></i>
                                Filtros do Relatório
                            </h5>
                        </div>
                        <div class="card-body">
                            <form method="GET" class="row g-3">
                                <div class="col-md-3">
                                    <label for="periodo" class="form-label">Período</label>
                                    <select class="form-select" id="periodo" name="periodo" onchange="this.form.submit()">
                                        <option value="hoje" <?= $periodo === 'hoje' ? 'selected' : '' ?>>Hoje</option>
                                        <option value="ontem" <?= $periodo === 'ontem' ? 'selected' : '' ?>>Ontem</option>
                                        <option value="semana" <?= $periodo === 'semana' ? 'selected' : '' ?>>Últimos 7 dias</option>
                                        <option value="mes" <?= $periodo === 'mes' ? 'selected' : '' ?>>Este mês</option>
                                        <option value="custom" <?= $periodo === 'custom' ? 'selected' : '' ?>>Personalizado</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <label for="data_inicio" class="form-label">Data Início</label>
                                    <input type="date" class="form-control" id="data_inicio" name="data_inicio" 
                                           value="<?= $data_inicio ?>" 
                                           <?= $periodo !== 'custom' ? 'disabled' : '' ?>>
                                </div>
                                <div class="col-md-3">
                                    <label for="data_fim" class="form-label">Data Fim</label>
                                    <input type="date" class="form-control" id="data_fim" name="data_fim" 
                                           value="<?= $data_fim ?>" 
                                           <?= $periodo !== 'custom' ? 'disabled' : '' ?>>
                                </div>
                                <div class="col-md-3">
                                    <label class="form-label">&nbsp;</label>
                                    <div>
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-sync-alt me-2"></i>
                                            Atualizar
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                    <!-- Período Selecionado -->
                    <div class="alert alert-info mb-4">
                        <i class="fas fa-calendar me-2"></i>
                        Período selecionado: 
                        <strong><?= date('d/m/Y', strtotime($data_inicio)) ?> a <?= date('d/m/Y', strtotime($data_fim)) ?></strong>
                    </div>

                    <!-- Cards de Estatísticas -->
                    <div class="row mb-4">
                        <div class="col-xl-2 col-md-4 mb-4">
                            <div class="card stat-card border-left-primary">
                                <div class="card-body text-center">
                                    <div class="text-primary mb-2">
                                        <i class="fas fa-shopping-cart fa-2x"></i>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= $estatisticas['total_pedidos'] ?? 0 ?>
                                    </div>
                                    <div class="text-xs font-weight-bold text-primary text-uppercase">
                                        Total Pedidos
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-2 col-md-4 mb-4">
                            <div class="card stat-card border-left-success">
                                <div class="card-body text-center">
                                    <div class="text-success mb-2">
                                        <i class="fas fa-dollar-sign fa-2x"></i>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        R$ <?= number_format($estatisticas['total_vendido'] ?? 0, 2, ',', '.') ?>
                                    </div>
                                    <div class="text-xs font-weight-bold text-success text-uppercase">
                                        Total Vendido
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-2 col-md-4 mb-4">
                            <div class="card stat-card border-left-info">
                                <div class="card-body text-center">
                                    <div class="text-info mb-2">
                                        <i class="fas fa-check-circle fa-2x"></i>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= $estatisticas['pedidos_entregues'] ?? 0 ?>
                                    </div>
                                    <div class="text-xs font-weight-bold text-info text-uppercase">
                                        Pedidos Entregues
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-2 col-md-4 mb-4">
                            <div class="card stat-card border-left-warning">
                                <div class="card-body text-center">
                                    <div class="text-warning mb-2">
                                        <i class="fas fa-receipt fa-2x"></i>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        R$ <?= number_format($estatisticas['ticket_medio'] ?? 0, 2, ',', '.') ?>
                                    </div>
                                    <div class="text-xs font-weight-bold text-warning text-uppercase">
                                        Ticket Médio
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-2 col-md-4 mb-4">
                            <div class="card stat-card border-left-danger">
                                <div class="card-body text-center">
                                    <div class="text-danger mb-2">
                                        <i class="fas fa-users fa-2x"></i>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= $estatisticas['clientes_ativos'] ?? 0 ?>
                                    </div>
                                    <div class="text-xs font-weight-bold text-danger text-uppercase">
                                        Clientes Ativos
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="col-xl-2 col-md-4 mb-4">
                            <div class="card stat-card border-left-secondary">
                                <div class="card-body text-center">
                                    <div class="text-secondary mb-2">
                                        <i class="fas fa-percentage fa-2x"></i>
                                    </div>
                                    <div class="h5 mb-0 font-weight-bold text-gray-800">
                                        <?= $estatisticas['total_pedidos'] > 0 ? 
                                            round(($estatisticas['pedidos_entregues'] / $estatisticas['total_pedidos']) * 100, 1) : 0 ?>%
                                    </div>
                                    <div class="text-xs font-weight-bold text-secondary text-uppercase">
                                        Taxa de Entrega
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Gráfico de Vendas por Dia -->
                        <div class="col-lg-8 mb-4">
                            <div class="card">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-chart-line me-2"></i>
                                        Vendas por Dia
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="chart-container">
                                        <canvas id="vendasChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Métodos de Pagamento -->
                        <div class="col-lg-4 mb-4">
                            <div class="card">
                                <div class="card-header bg-success text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-credit-card me-2"></i>
                                        Métodos de Pagamento
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="chart-container">
                                        <canvas id="pagamentosChart"></canvas>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <!-- Produtos Mais Vendidos -->
                        <div class="col-lg-6 mb-4">
                            <div class="card">
                                <div class="card-header bg-warning text-dark">
                                    <h5 class="mb-0">
                                        <i class="fas fa-star me-2"></i>
                                        Produtos Mais Vendidos
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Produto</th>
                                                    <th>Quantidade</th>
                                                    <th>Faturamento</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (empty($produtos_vendidos)): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center text-muted py-3">
                                                            Nenhum produto vendido no período.
                                                        </td>
                                                    </tr>
                                                <?php else: ?>
                                                    <?php foreach ($produtos_vendidos as $produto): ?>
                                                    <tr>
                                                        <td>
                                                            <strong><?= htmlspecialchars($produto['nome']) ?></strong>
                                                            <br>
                                                            <small class="text-muted"><?= htmlspecialchars($produto['marca_nome']) ?></small>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-primary"><?= $produto['total_vendido'] ?> unid.</span>
                                                        </td>
                                                        <td>
                                                            <strong>R$ <?= number_format($produto['total_faturado'], 2, ',', '.') ?></strong>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Melhores Clientes -->
                        <div class="col-lg-6 mb-4">
                            <div class="card">
                                <div class="card-header bg-info text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-crown me-2"></i>
                                        Melhores Clientes
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-sm">
                                            <thead>
                                                <tr>
                                                    <th>Cliente</th>
                                                    <th>Pedidos</th>
                                                    <th>Total Gasto</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php if (empty($melhores_clientes)): ?>
                                                    <tr>
                                                        <td colspan="3" class="text-center text-muted py-3">
                                                            Nenhum cliente com compras no período.
                                                        </td>
                                                    </tr>
                                                <?php else: ?>
                                                    <?php foreach ($melhores_clientes as $cliente): ?>
                                                    <tr>
                                                        <td>
                                                            <strong><?= htmlspecialchars($cliente['nome']) ?></strong>
                                                            <br>
                                                            <small class="text-muted"><?= htmlspecialchars($cliente['email']) ?></small>
                                                        </td>
                                                        <td>
                                                            <span class="badge bg-info"><?= $cliente['total_pedidos'] ?> pedidos</span>
                                                        </td>
                                                        <td>
                                                            <strong>R$ <?= number_format($cliente['total_gasto'], 2, ',', '.') ?></strong>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>

    <script>
        // Gráfico de Vendas por Dia
        const vendasCtx = document.getElementById('vendasChart').getContext('2d');
        const vendasChart = new Chart(vendasCtx, {
            type: 'line',
            data: {
                labels: [<?= implode(',', array_map(function($v) { return "'" . date('d/m', strtotime($v['data'])) . "'"; }, $vendas_dia)) ?>],
                datasets: [{
                    label: 'Vendas (R$)',
                    data: [<?= implode(',', array_map(function($v) { return $v['total_vendas']; }, $vendas_dia)) ?>],
                    borderColor: '#0d6efd',
                    backgroundColor: 'rgba(13, 110, 253, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: true
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toLocaleString('pt-BR');
                            }
                        }
                    }
                }
            }
        });

        // Gráfico de Métodos de Pagamento
        const pagamentosCtx = document.getElementById('pagamentosChart').getContext('2d');
        const pagamentosChart = new Chart(pagamentosCtx, {
            type: 'doughnut',
            data: {
                labels: [<?= implode(',', array_map(function($m) { return "'" . ucfirst($m['metodo_pagamento']) . "'"; }, $metodos_pagamento)) ?>],
                datasets: [{
                    data: [<?= implode(',', array_map(function($m) { return $m['total_vendas']; }, $metodos_pagamento)) ?>],
                    backgroundColor: [
                        '#0d6efd',
                        '#198754',
                        '#ffc107',
                        '#dc3545',
                        '#6f42c1'
                    ]
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });

        // Habilitar campos de data quando selecionar período personalizado
        document.getElementById('periodo').addEventListener('change', function() {
            const isCustom = this.value === 'custom';
            document.getElementById('data_inicio').disabled = !isCustom;
            document.getElementById('data_fim').disabled = !isCustom;
        });
    </script>
</body>
</html>