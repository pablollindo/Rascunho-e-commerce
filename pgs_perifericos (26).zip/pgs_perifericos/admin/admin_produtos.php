<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// DEBUG DETALHADO DAS PERMISSÕES
echo "<!-- ========= DEBUG PERMISSÕES ========= -->";
echo "<!-- usuario_tipo: " . ($_SESSION['usuario_tipo'] ?? 'NULL') . " -->";
echo "<!-- usuario_cargo: " . ($_SESSION['usuario_cargo'] ?? 'NULL') . " -->";
echo "<!-- isFuncionario(): " . (isFuncionario() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- podeGerenciarProdutos(): " . (podeGerenciarProdutos() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- podeAdicionarProdutos(): " . (podeAdicionarProdutos() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- podeEditarProdutos(): " . (podeEditarProdutos() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- podeExcluirProdutos(): " . (podeExcluirProdutos() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- ========= FIM DEBUG ========= -->";

// Verificar se pode gerenciar produtos
if (!podeGerenciarProdutos()) {
    $_SESSION['erro'] = "Acesso restrito.";
    header("Location: ../indexx.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$produto_id = intval($_GET['id'] ?? 0);

try {
    $pdo = conectarBanco();
    
    // Buscar categorias e marcas para formulários
    $categorias = $pdo->query("SELECT * FROM categorias WHERE ativo = 1 ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
    $marcas = $pdo->query("SELECT * FROM marcas WHERE ativo = 1 ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
    
    switch ($action) {
        case 'add':
        case 'edit':
            // Verificar permissão específica para editar/adicionar
            if (!podeEditarProdutos()) {
                $_SESSION['erro'] = "Acesso negado para editar produtos.";
                header("Location: admin_produtos.php");
                exit;
            }
            
            // Preparar dados do produto se for edição
            $produto = null;
            if ($action === 'edit' && $produto_id > 0) {
                $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
                $stmt->execute([$produto_id]);
                $produto = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$produto) {
                    $_SESSION['erro'] = "Produto não encontrado.";
                    header("Location: admin_produtos.php");
                    exit;
                }
            }
            break;
            
        case 'delete':
            // Verificar permissão específica para excluir
            if ($produto_id > 0 && podeExcluirProdutos()) {
                // Soft delete - marcar como inativo
                $stmt = $pdo->prepare("UPDATE produtos SET ativo = 0 WHERE id = ?");
                $stmt->execute([$produto_id]);
                $_SESSION['sucesso'] = "Produto excluído com sucesso!";
            } else {
                $_SESSION['erro'] = "Acesso negado para exclusão.";
            }
            header("Location: admin_produtos.php");
            exit;
            
        case 'save':
            // Verificar permissão específica para salvar
            if (!podeEditarProdutos()) {
                $_SESSION['erro'] = "Acesso negado para salvar produtos.";
                header("Location: admin_produtos.php");
                exit;
            }
            
            // Processar salvamento do produto
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $dados = [
                    'categoria_id' => intval($_POST['categoria_id']),
                    'marca_id' => intval($_POST['marca_id']),
                    'nome' => trim($_POST['nome']),
                    'descricao' => trim($_POST['descricao']),
                    'especificacoes' => trim($_POST['especificacoes']),
                    'preco' => floatval(str_replace(['R$', '.', ','], ['', '', '.'], $_POST['preco'])),
                    'preco_promocional' => !empty($_POST['preco_promocional']) ? 
                        floatval(str_replace(['R$', '.', ','], ['', '', '.'], $_POST['preco_promocional'])) : null,
                    'estoque' => intval($_POST['estoque']),
                    'garantia_meses' => intval($_POST['garantia_meses']),
                    'em_destaque' => isset($_POST['em_destaque']) ? 1 : 0,
                    'em_promocao' => isset($_POST['em_promocao']) ? 1 : 0,
                    'ativo' => isset($_POST['ativo']) ? 1 : 0
                ];
                
                // Validações básicas
                if (empty($dados['nome']) || empty($dados['preco'])) {
                    $_SESSION['erro'] = "Nome e preço são obrigatórios.";
                    header("Location: admin_produtos.php?action=" . ($_POST['id'] ? 'edit&id=' . $_POST['id'] : 'add'));
                    exit;
                }
                
                if ($_POST['id']) {
                    // Edição
                    $stmt = $pdo->prepare("UPDATE produtos SET 
                        categoria_id = ?, marca_id = ?, nome = ?, descricao = ?, especificacoes = ?,
                        preco = ?, preco_promocional = ?, estoque = ?, garantia_meses = ?,
                        em_destaque = ?, em_promocao = ?, ativo = ?
                        WHERE id = ?");
                    $dados[] = $_POST['id'];
                    $stmt->execute(array_values($dados));
                    $_SESSION['sucesso'] = "Produto atualizado com sucesso!";
                } else {
                    // Inserção
                    $stmt = $pdo->prepare("INSERT INTO produtos 
                        (categoria_id, marca_id, nome, descricao, especificacoes, preco, preco_promocional, 
                         estoque, garantia_meses, em_destaque, em_promocao, ativo, data_cadastro) 
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NOW())");
                    $stmt->execute(array_values($dados));
                    $_SESSION['sucesso'] = "Produto cadastrado com sucesso!";
                }
                
                header("Location: admin_produtos.php");
                exit;
            }
            break;
    }
    
    // Buscar produtos para listagem
    $sql_produtos = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
                    FROM produtos p 
                    LEFT JOIN categorias c ON p.categoria_id = c.id 
                    LEFT JOIN marcas m ON p.marca_id = m.id 
                    ORDER BY p.data_cadastro DESC";
    $produtos = $pdo->query($sql_produtos)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro no banco de dados: " . $e->getMessage();
    $produtos = [];
    $categorias = [];
    $marcas = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Produtos - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Cabeçalho Igual ao Indexx -->
    <?php 
    $tituloPagina = "Gerenciar Produtos - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            Dashboard
                        </a>
                        
                        <?php if (podeGerenciarProdutos()): ?>
                        <a href="admin_produtos.php" class="nav-link active">
                            <i class="fas fa-box me-2"></i>
                            Produtos
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarEstoque()): ?>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>
                            Estoque
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarCategorias()): ?>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>
                            Categorias & Marcas
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos
                        </a>
                        
                        <?php if (podeGerenciarUsuarios()): ?>
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>
                            Clientes
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarFuncionarios()): ?>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>
                            Funcionários
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>
                            Suporte
                        </a>
                        
                        <?php if (podeVerRelatorios()): ?>
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>
                            Relatórios
                        </a>
                        <?php endif; ?>
                        
                        <hr class="bg-light my-3">
                        
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>
                            Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-box me-2"></i>
                                Gerenciar Produtos
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <?php if (podeAdicionarProdutos()): ?>
                                <a href="admin_produtos.php?action=add" class="btn btn-success">
                                    <i class="fas fa-plus me-2"></i>
                                    Novo Produto
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <?php if (($action === 'add' || $action === 'edit') && podeAdicionarProdutos()): ?>
                        <!-- Formulário de Adicionar/Editar Produto -->
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-<?= $action === 'add' ? 'plus' : 'edit' ?> me-2"></i>
                                    <?= $action === 'add' ? 'Adicionar' : 'Editar' ?> Produto
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="admin_produtos.php?action=save">
                                    <input type="hidden" name="id" value="<?= $produto['id'] ?? '' ?>">
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="nome" class="form-label">Nome do Produto *</label>
                                            <input type="text" class="form-control" id="nome" name="nome" 
                                                   value="<?= htmlspecialchars($produto['nome'] ?? '') ?>" required>
                                        </div>
                                        
                                        <div class="col-md-3 mb-3">
                                            <label for="categoria_id" class="form-label">Categoria *</label>
                                            <select class="form-select" id="categoria_id" name="categoria_id" required>
                                                <option value="">Selecione...</option>
                                                <?php foreach ($categorias as $categoria): ?>
                                                <option value="<?= $categoria['id'] ?>" 
                                                    <?= ($produto['categoria_id'] ?? '') == $categoria['id'] ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($categoria['nome']) ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                        
                                        <div class="col-md-3 mb-3">
                                            <label for="marca_id" class="form-label">Marca *</label>
                                            <select class="form-select" id="marca_id" name="marca_id" required>
                                                <option value="">Selecione...</option>
                                                <?php foreach ($marcas as $marca): ?>
                                                <option value="<?= $marca['id'] ?>" 
                                                    <?= ($produto['marca_id'] ?? '') == $marca['id'] ? 'selected' : '' ?>>
                                                    <?= htmlspecialchars($marca['nome']) ?>
                                                </option>
                                                <?php endforeach; ?>
                                            </select>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label for="preco" class="form-label">Preço *</label>
                                            <div class="input-group">
                                                <span class="input-group-text">R$</span>
                                                <input type="text" class="form-control money" id="preco" name="preco" 
                                                       value="<?= $produto ? number_format($produto['preco'], 2, ',', '.') : '' ?>" required>
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4 mb-3">
                                            <label for="preco_promocional" class="form-label">Preço Promocional</label>
                                            <div class="input-group">
                                                <span class="input-group-text">R$</span>
                                                <input type="text" class="form-control money" id="preco_promocional" name="preco_promocional" 
                                                       value="<?= $produto && $produto['preco_promocional'] ? number_format($produto['preco_promocional'], 2, ',', '.') : '' ?>">
                                            </div>
                                        </div>
                                        
                                        <div class="col-md-4 mb-3">
                                            <label for="estoque" class="form-label">Estoque *</label>
                                            <input type="number" class="form-control" id="estoque" name="estoque" 
                                                   value="<?= $produto['estoque'] ?? 0 ?>" min="0" required>
                                        </div>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="descricao" class="form-label">Descrição</label>
                                        <textarea class="form-control" id="descricao" name="descricao" rows="3"><?= htmlspecialchars($produto['descricao'] ?? '') ?></textarea>
                                    </div>
                                    
                                    <div class="mb-3">
                                        <label for="especificacoes" class="form-label">Especificações Técnicas</label>
                                        <textarea class="form-control" id="especificacoes" name="especificacoes" rows="4"><?= htmlspecialchars($produto['especificacoes'] ?? '') ?></textarea>
                                        <small class="text-muted">Separe cada especificação por linha.</small>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-3 mb-3">
                                            <label for="garantia_meses" class="form-label">Garantia (meses)</label>
                                            <input type="number" class="form-control" id="garantia_meses" name="garantia_meses" 
                                                   value="<?= $produto['garantia_meses'] ?? 12 ?>" min="0">
                                        </div>
                                        
                                        <div class="col-md-9 mb-3">
                                            <div class="form-check mt-4">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <input type="checkbox" class="form-check-input" id="em_destaque" name="em_destaque" 
                                                               <?= ($produto['em_destaque'] ?? 0) ? 'checked' : '' ?>>
                                                        <label class="form-check-label" for="em_destaque">Em Destaque</label>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <input type="checkbox" class="form-check-input" id="em_promocao" name="em_promocao" 
                                                               <?= ($produto['em_promocao'] ?? 0) ? 'checked' : '' ?>>
                                                        <label class="form-check-label" for="em_promocao">Em Promoção</label>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <input type="checkbox" class="form-check-input" id="ativo" name="ativo" 
                                                               <?= ($produto['ativo'] ?? 1) ? 'checked' : '' ?>>
                                                        <label class="form-check-label" for="ativo">Ativo</label>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="d-flex justify-content-between">
                                        <a href="admin_produtos.php" class="btn btn-secondary">
                                            <i class="fas fa-arrow-left me-2"></i>
                                            Voltar
                                        </a>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-save me-2"></i>
                                            Salvar Produto
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Lista de Produtos -->
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Produto</th>
                                                <th>Categoria</th>
                                                <th>Marca</th>
                                                <th>Preço</th>
                                                <th>Estoque</th>
                                                <th>Status</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($produtos)): ?>
                                                <tr>
                                                    <td colspan="8" class="text-center py-4 text-muted">
                                                        <i class="fas fa-box-open fa-2x mb-3"></i><br>
                                                        Nenhum produto cadastrado.
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($produtos as $prod): ?>
                                                <tr>
                                                    <td>#<?= str_pad($prod['id'], 6, '0', STR_PAD_LEFT) ?></td>
                                                    <td>
                                                        <strong><?= htmlspecialchars($prod['nome']) ?></strong>
                                                        <div class="small text-muted">
                                                            <?php if ($prod['em_destaque']): ?>
                                                                <span class="badge bg-warning me-1">Destaque</span>
                                                            <?php endif; ?>
                                                            <?php if ($prod['em_promocao']): ?>
                                                                <span class="badge bg-danger me-1">Promoção</span>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                    <td><?= htmlspecialchars($prod['categoria_nome']) ?></td>
                                                    <td><?= htmlspecialchars($prod['marca_nome']) ?></td>
                                                    <td>
                                                        <?php if ($prod['em_promocao'] && $prod['preco_promocional']): ?>
                                                            <span class="text-danger fw-bold">R$ <?= number_format($prod['preco_promocional'], 2, ',', '.') ?></span>
                                                            <br>
                                                            <small class="text-muted text-decoration-line-through">
                                                                R$ <?= number_format($prod['preco'], 2, ',', '.') ?>
                                                            </small>
                                                        <?php else: ?>
                                                            R$ <?= number_format($prod['preco'], 2, ',', '.') ?>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= $prod['estoque'] > 5 ? 'success' : ($prod['estoque'] > 0 ? 'warning' : 'danger') ?>">
                                                            <?= $prod['estoque'] ?> unid.
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= $prod['ativo'] ? 'success' : 'secondary' ?>">
                                                            <?= $prod['ativo'] ? 'Ativo' : 'Inativo' ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <?php if (podeAdicionarProdutos()): ?>
                                                            <a href="admin_produtos.php?action=edit&id=<?= $prod['id'] ?>" 
                                                               class="btn btn-outline-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <?php endif; ?>
                                                            <a href="../produto.php?id=<?= $prod['id'] ?>" 
                                                               target="_blank" class="btn btn-outline-info" title="Visualizar">
                                                                <i class="fas fa-eye"></i>
                                                            </a>
                                                            <?php if (isAdmin()): ?>
                                                            <a href="admin_produtos.php?action=delete&id=<?= $prod['id'] ?>" 
                                                               class="btn btn-outline-danger" 
                                                               onclick="return confirm('Tem certeza que deseja excluir este produto?')"
                                                               title="Excluir">
                                                                <i class="fas fa-trash"></i>
                                                            </a>
                                                            <?php endif; ?>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>

    <script>
        // Máscara para campos de preço
        document.addEventListener('DOMContentLoaded', function() {
            const moneyInputs = document.querySelectorAll('.money');
            moneyInputs.forEach(input => {
                input.addEventListener('input', function(e) {
                    let value = e.target.value.replace(/\D/g, '');
                    value = (value / 100).toFixed(2) + '';
                    value = value.replace(".", ",");
                    value = value.replace(/(\d)(\d{3})(\d{3}),/g, "$1.$2.$3,");
                    value = value.replace(/(\d)(\d{3}),/g, "$1.$2,");
                    e.target.value = value;
                });
            });
        });
    </script>
</body>
</html>