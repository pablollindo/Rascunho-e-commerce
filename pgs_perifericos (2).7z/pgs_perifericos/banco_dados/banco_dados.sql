-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS pgs_perifericos;
USE pgs_perifericos;

-- Tabela de usuários (clientes)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('cliente','admin','funcionario') DEFAULT 'cliente',
    cpf VARCHAR(14) UNIQUE,
    telefone VARCHAR(15),
    data_nascimento DATE,
    endereco_cep VARCHAR(9),
    endereco_rua VARCHAR(200),
    endereco_numero VARCHAR(10),
    endereco_complemento VARCHAR(100),
    endereco_bairro VARCHAR(100),
    endereco_cidade VARCHAR(100),
    endereco_estado VARCHAR(2),
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de funcionários
CREATE TABLE funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNIQUE,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    cargo ENUM('gerente','vendedor','suporte','estoque') NOT NULL,
    departamento VARCHAR(50),
    data_admissao DATE NOT NULL,
    data_demissao DATE NULL,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de categorias
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    descricao TEXT,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de produtos
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    especificacoes TEXT,
    preco DECIMAL(10,2) NOT NULL,
    preco_promocional DECIMAL(10,2),
    estoque INT DEFAULT 0,
    imagem VARCHAR(255),
    garantia_meses INT DEFAULT 12,
    ativo BOOLEAN DEFAULT TRUE,
    em_destaque BOOLEAN DEFAULT FALSE,
    em_promocao BOOLEAN DEFAULT FALSE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
);

-- Tabela de endereços dos clientes
CREATE TABLE enderecos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(50) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(200) NOT NULL,
    numero VARCHAR(10) NOT NULL,
    complemento VARCHAR(100),
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    principal BOOLEAN DEFAULT FALSE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    total DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    desconto DECIMAL(10,2) DEFAULT 0,
    status ENUM('pendente','pago','processando','enviado','entregue','cancelado') DEFAULT 'pendente',
    metodo_pagamento ENUM('cartao','pix','boleto'),
    numero_cartao VARCHAR(20),
    nome_titular VARCHAR(100),
    data_vencimento DATE,
    codigo_seguranca VARCHAR(4),
    codigo_pix TEXT,
    codigo_boleto VARCHAR(50),
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_pagamento TIMESTAMP NULL,
    data_envio TIMESTAMP NULL,
    endereco_entrega TEXT,
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id)
);

-- Tabela de itens do pedido
CREATE TABLE itens_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT,
    produto_id INT,
    quantidade INT DEFAULT 1,
    preco_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
);

-- Tabela de cupons de desconto
CREATE TABLE cupons_desconto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    desconto_percentual DECIMAL(5,2),
    desconto_valor DECIMAL(10,2),
    data_validade DATE,
    usos_maximos INT,
    usos_atuais INT DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de tickets de suporte
CREATE TABLE tickets_suporte (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    assunto VARCHAR(200) NOT NULL,
    categoria ENUM('compra','produto','garantia','entrega','conta','outros') NOT NULL,
    descricao TEXT NOT NULL,
    status ENUM('aberto','em_andamento','respondido','fechado') DEFAULT 'aberto',
    prioridade ENUM('baixa','media','alta','urgente') DEFAULT 'media',
    data_abertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_ultima_resposta TIMESTAMP NULL,
    data_fechamento TIMESTAMP NULL,
    funcionario_responsavel INT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (funcionario_responsavel) REFERENCES funcionarios(id)
);

-- Tabela de mensagens do suporte
CREATE TABLE mensagens_suporte (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT,
    usuario_id INT,
    mensagem TEXT NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    eh_funcionario BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (ticket_id) REFERENCES tickets_suporte(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de FAQ
CREATE TABLE faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pergunta VARCHAR(255) NOT NULL,
    resposta TEXT NOT NULL,
    categoria ENUM('compra','produto','garantia','entrega','pagamento') NOT NULL,
    ordem INT DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE
);

-- Índices para performance
CREATE INDEX idx_produtos_destaque ON produtos(em_destaque, ativo);
CREATE INDEX idx_produtos_promocao ON produtos(em_promocao, ativo);
CREATE INDEX idx_pedidos_status ON pedidos(status, data_pedido);
CREATE INDEX idx_tickets_status ON tickets_suporte(status, data_abertura);
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_funcionarios_email ON funcionarios(email);
CREATE INDEX idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX idx_pedidos_cliente ON pedidos(cliente_id);

-- Dados iniciais
INSERT INTO categorias (nome, descricao) VALUES 
('Teclados', 'Teclados mecânicos, membrana e gaming'),
('Mouses', 'Mouses gamers, ópticos e sem fio'),
('Headsets', 'Fones de ouvido e headsets gamers'),
('Monitores', 'Monitores gaming e profissionais'),
('Mousepads', 'Mousepads speed e control'),
('Webcams', 'Webcams para streaming e reuniões'),
('Microfones', 'Microfones para streaming e gravação');

-- Usuários iniciais (senha: password)
INSERT INTO usuarios (nome, email, senha, tipo, cpf, telefone, data_nascimento) VALUES 
('Administrador', 'admin@pgsperifericos.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '123.456.789-00', '(11) 99999-9999', '1980-01-01'),
('João Silva', 'cliente@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cliente', '987.654.321-00', '(11) 98888-8888', '1990-05-15'),
('Maria Santos', 'funcionario@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario', '111.222.333-44', '(11) 97777-7777', '1985-03-20');

-- Funcionários iniciais
INSERT INTO funcionarios (usuario_id, nome, email, senha, cargo, departamento, data_admissao) VALUES
(3, 'Maria Santos', 'funcionario@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'vendedor', 'Vendas', '2023-01-15');

-- Produtos
INSERT INTO produtos (categoria_id, nome, descricao, especificacoes, preco, preco_promocional, estoque, imagem, garantia_meses, em_destaque, em_promocao) VALUES
(1, 1, 'Teclado Mecânico RGB Kumara', 'Teclado mecânico gaming com iluminação RGB, switches Outemu Blue', 'Switches: Outemu Blue | Layout: ABNT2 | Iluminação: RGB | Conexão: USB | Peso: 1.2kg', 299.90, 249.90, 50, 'teclado-mecanico.jpg', 12, TRUE, TRUE),
(2, 1, 'Mouse Gamer G502 HERO', 'Mouse gaming com sensor HERO 25K DPI, 11 botões programáveis', 'Sensor: HERO 25K DPI | Botões: 11 programáveis | Peso: 121g | Iluminação: RGB | Polling Rate: 1000Hz', 349.90, 299.90, 30, 'mouse-gamer.jpg', 24, TRUE, TRUE),
(3, 1, 'Headset Cloud II', 'Headset gamer com som surround virtual 7.1, microfone removível', 'Driver: 53mm | Impedância: 60Ω | Sensibilidade: 98±3dB | Microfone: Removível com cancelamento de ruído', 399.90, 349.90, 25, 'headset.jpg', 12, TRUE, TRUE);

-- Cupons de desconto
INSERT INTO cupons_desconto (codigo, desconto_percentual, data_validade, usos_maximos, ativo) VALUES
('PRIMEIRACOMPRA', 15.00, '2024-12-31', 1000, TRUE),
('PROMO10', 10.00, '2024-06-30', 500, TRUE);

-- FAQ
INSERT INTO faq (pergunta, resposta, categoria, ordem) VALUES 
('Como faço para rastrear meu pedido?', 'Após a confirmação do pagamento, você receberá um código de rastreamento por email.', 'entrega', 1),
('Quais formas de pagamento são aceitas?', 'Aceitamos cartão de crédito (até 12x), PIX (5% off) e boleto bancário.', 'pagamento', 1),
('Como funciona a garantia dos produtos?', 'Todos os produtos possuem garantia do fabricante, que varia de 3 a 12 meses.', 'garantia', 1);

-- Tickets de suporte de exemplo
INSERT INTO tickets_suporte (usuario_id, assunto, categoria, descricao, status, prioridade) VALUES
(2, 'Produto não chegou', 'entrega', 'Comprei um teclado há 15 dias e ainda não recebi.', 'aberto', 'alta'),
(2, 'Dúvida sobre garantia', 'garantia', 'Gostaria de saber como acionar a garantia do meu headset.', 'em_andamento', 'media');

SELECT 'Banco de dados PGS Periféricos criado com sucesso!' as status;