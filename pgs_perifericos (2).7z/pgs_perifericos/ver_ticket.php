<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para ver tickets.";
    header("Location: login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$ticket_id = intval($_GET['id'] ?? 0);

if ($ticket_id <= 0) {
    $_SESSION['erro'] = "Ticket não especificado.";
    header("Location: meus_tickets.php");
    exit;
}

// Buscar informações do ticket
try {
    $pdo = conectarBanco();
    
    // Buscar ticket específico do usuário
    $sql_ticket = "SELECT ts.*, u.nome as usuario_nome 
                   FROM tickets_suporte ts 
                   JOIN usuarios u ON ts.usuario_id = u.id 
                   WHERE ts.id = ? AND ts.usuario_id = ?";
    $stmt = $pdo->prepare($sql_ticket);
    $stmt->execute([$ticket_id, $usuario_id]);
    $ticket = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$ticket) {
        $_SESSION['erro'] = "Ticket não encontrado ou você não tem permissão para visualizá-lo.";
        header("Location: meus_tickets.php");
        exit;
    }
    
    // Buscar mensagens do ticket
    $sql_mensagens = "SELECT ms.*, u.nome as usuario_nome, 
                      CASE WHEN ms.eh_funcionario = 1 THEN 'Funcionário' ELSE 'Cliente' END as tipo_usuario
                      FROM mensagens_suporte ms 
                      JOIN usuarios u ON ms.usuario_id = u.id 
                      WHERE ms.ticket_id = ? 
                      ORDER BY ms.data_envio ASC";
    $stmt = $pdo->prepare($sql_mensagens);
    $stmt->execute([$ticket_id]);
    $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar ticket: " . $e->getMessage();
    header("Location: meus_tickets.php");
    exit;
}

// Processar exclusão do ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['excluir_ticket'])) {
    try {
        // Iniciar transação para garantir que todas as operações sejam realizadas
        $pdo->beginTransaction();
        
        // Primeiro excluir as mensagens do ticket
        $sql_excluir_mensagens = "DELETE FROM mensagens_suporte WHERE ticket_id = ?";
        $stmt = $pdo->prepare($sql_excluir_mensagens);
        $stmt->execute([$ticket_id]);
        
        // Depois excluir o ticket
        $sql_excluir_ticket = "DELETE FROM tickets_suporte WHERE id = ? AND usuario_id = ?";
        $stmt = $pdo->prepare($sql_excluir_ticket);
        $stmt->execute([$ticket_id, $usuario_id]);
        
        $pdo->commit();
        
        $_SESSION['sucesso'] = "Ticket excluído com sucesso!";
        header("Location: meus_tickets.php");
        exit;
        
    } catch (PDOException $e) {
        $pdo->rollBack();
        $_SESSION['erro'] = "Erro ao excluir ticket: " . $e->getMessage();
        header("Location: ver_ticket.php?id=" . $ticket_id);
        exit;
    }
}
?>

<?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho do Ticket -->
                <div class="card ticket-header text-white mb-4">
                    <div class="card-body">
                        <div class="row align-items-center">
                            <div class="col-md-8">
                                <h1 class="h3 mb-2">
                                    <i class="fas fa-ticket-alt me-2"></i>
                                    Detalhes do Ticket #<?= $ticket_id ?>
                                </h1>
                                <h2 class="h5 mb-3"><?= htmlspecialchars($ticket['assunto']) ?></h2>
                            </div>
                            <div class="col-md-4 text-md-end">
                                <div class="btn-group">
                                    <a href="meus_tickets.php" class="btn btn-light">
                                        <i class="fas fa-arrow-left me-1"></i>
                                        Voltar
                                    </a>
                                    <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#modalExcluir">
                                        <i class="fas fa-trash me-1"></i>
                                        Excluir
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <?php mostrarMensagem(); ?>

                <div class="row">
                    <!-- Informações Principais do Ticket -->
                    <div class="col-lg-6 mb-4">
                        <div class="card info-card h-100">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-info-circle me-2"></i>
                                    Informações do Ticket
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-hashtag me-2 text-primary"></i>
                                        Número do Ticket
                                    </div>
                                    <div class="info-value">#<?= $ticket_id ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-user me-2 text-primary"></i>
                                        Cliente
                                    </div>
                                    <div class="info-value"><?= htmlspecialchars($ticket['usuario_nome']) ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-heading me-2 text-primary"></i>
                                        Assunto
                                    </div>
                                    <div class="info-value"><?= htmlspecialchars($ticket['assunto']) ?></div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-folder me-2 text-primary"></i>
                                        Categoria
                                    </div>
                                    <div class="info-value">
                                        <span class="badge bg-secondary">
                                            <?= ucfirst($ticket['categoria']) ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-flag me-2 text-primary"></i>
                                        Status
                                    </div>
                                    <div class="info-value">
                                        <?php
                                        $status_class = [
                                            'aberto' => 'bg-success',
                                            'em_andamento' => 'bg-warning',
                                            'respondido' => 'bg-info',
                                            'fechado' => 'bg-secondary'
                                        ];
                                        ?>
                                        <span class="badge status-badge <?= $status_class[$ticket['status']] ?? 'bg-secondary' ?>">
                                            <i class="fas fa-circle me-1"></i>
                                            <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-exclamation-circle me-2 text-primary"></i>
                                        Prioridade
                                    </div>
                                    <div class="info-value">
                                        <?php
                                        $prioridade_class = [
                                            'baixa' => 'bg-secondary',
                                            'media' => 'bg-info',
                                            'alta' => 'bg-warning',
                                            'urgente' => 'bg-danger'
                                        ];
                                        ?>
                                        <span class="badge status-badge <?= $prioridade_class[$ticket['prioridade']] ?? 'bg-secondary' ?>">
                                            <i class="fas fa-exclamation me-1"></i>
                                            <?= ucfirst($ticket['prioridade']) ?>
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Datas e Informações Temporais -->
                    <div class="col-lg-6 mb-4">
                        <div class="card info-card h-100">
                            <div class="card-header bg-info text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-calendar-alt me-2"></i>
                                    Datas e Prazos
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-calendar-plus me-2 text-info"></i>
                                        Data de Abertura
                                    </div>
                                    <div class="info-value">
                                        <?= date('d/m/Y H:i', strtotime($ticket['data_abertura'])) ?>
                                    </div>
                                </div>
                                
                                <?php if ($ticket['data_ultima_resposta']): ?>
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-clock me-2 text-info"></i>
                                        Última Resposta
                                    </div>
                                    <div class="info-value">
                                        <?= date('d/m/Y H:i', strtotime($ticket['data_ultima_resposta'])) ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <?php if ($ticket['data_fechamento']): ?>
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-lock me-2 text-info"></i>
                                        Data de Fechamento
                                    </div>
                                    <div class="info-value">
                                        <?= date('d/m/Y H:i', strtotime($ticket['data_fechamento'])) ?>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-comments me-2 text-info"></i>
                                        Total de Mensagens
                                    </div>
                                    <div class="info-value">
                                        <span class="badge bg-primary"><?= count($mensagens) ?></span>
                                    </div>
                                </div>
                                
                                <?php if ($ticket['funcionario_responsavel']): ?>
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-user-tie me-2 text-info"></i>
                                        Funcionário Responsável
                                    </div>
                                    <div class="info-value">
                                        ID: <?= $ticket['funcionario_responsavel'] ?>
                                    </div>
                                </div>
                                <?php else: ?>
                                <div class="info-item">
                                    <div class="info-label">
                                        <i class="fas fa-user-tie me-2 text-info"></i>
                                        Funcionário Responsável
                                    </div>
                                    <div class="info-value text-muted">
                                        <i>Aguardando atribuição</i>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Descrição Detalhada -->
                <div class="row">
                    <div class="col-12">
                        <div class="card descricao-card mb-4">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="mb-0">
                                    <i class="fas fa-file-alt me-2"></i>
                                    Descrição Detalhada do Problema
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="info-label mb-3">
                                    <i class="fas fa-align-left me-2 text-warning"></i>
                                    Descrição completa enviada por você:
                                </div>
                                <div class="bg-light p-4 rounded">
                                    <p class="mb-0" style="line-height: 1.6;"><?= nl2br(htmlspecialchars($ticket['descricao'])) ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Histórico de Mensagens -->
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="fas fa-comments me-2"></i>
                                    Histórico de Mensagens
                                </h5>
                                <span class="badge bg-primary"><?= count($mensagens) ?> mensagens</span>
                            </div>
                            <div class="card-body" style="max-height: 500px; overflow-y: auto;">
                                <?php if (empty($mensagens)): ?>
                                    <div class="text-center py-4">
                                        <i class="fas fa-comments fa-3x text-muted mb-3"></i>
                                        <p class="text-muted">Nenhuma mensagem ainda.</p>
                                        <p class="text-muted small">Aguardando primeira resposta da equipe de suporte.</p>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($mensagens as $mensagem): ?>
                                    <div class="card mb-3 <?= $mensagem['eh_funcionario'] ? 'mensagem-funcionario' : 'mensagem-cliente' ?>">
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between align-items-start mb-2">
                                                <div>
                                                    <strong class="<?= $mensagem['eh_funcionario'] ? 'text-purple' : 'text-primary' ?>">
                                                        <i class="fas fa-user me-1"></i>
                                                        <?= htmlspecialchars($mensagem['usuario_nome']) ?>
                                                    </strong>
                                                    <small class="text-muted ms-2">
                                                        (<?= $mensagem['tipo_usuario'] ?>)
                                                    </small>
                                                </div>
                                                <small class="text-muted">
                                                    <i class="fas fa-clock me-1"></i>
                                                    <?= date('d/m/Y H:i', strtotime($mensagem['data_envio'])) ?>
                                                </small>
                                            </div>
                                            <p class="card-text mb-0" style="line-height: 1.5;"><?= nl2br(htmlspecialchars($mensagem['mensagem'])) ?></p>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Modal de Confirmação de Exclusão -->
    <div class="modal fade" id="modalExcluir" tabindex="-1" aria-labelledby="modalExcluirLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-danger text-white">
                    <h5 class="modal-title" id="modalExcluirLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Confirmar Exclusão
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p><strong>Tem certeza que deseja excluir este ticket?</strong></p>
                    <p class="text-muted">Ticket #<?= $ticket_id ?> - <?= htmlspecialchars($ticket['assunto']) ?></p>
                    <p class="text-danger">
                        <i class="fas fa-exclamation-circle me-1"></i>
                        Esta ação não pode ser desfeita. Todas as mensagens serão perdidas.
                    </p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <form method="POST" class="d-inline">
                        <button type="submit" name="excluir_ticket" class="btn btn-danger">
                            <i class="fas fa-trash me-1"></i>
                            Sim, Excluir Ticket
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </div>

<?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Rolagem automática para a última mensagem
        document.addEventListener('DOMContentLoaded', function() {
            const conversaContainer = document.querySelector('.card-body[style*="max-height"]');
            if (conversaContainer) {
                conversaContainer.scrollTop = conversaContainer.scrollHeight;
            }
        });
    </script>
</body>
</html>