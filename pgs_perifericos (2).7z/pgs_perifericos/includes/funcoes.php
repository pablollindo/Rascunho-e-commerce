<?php
// Função para conectar ao banco
function conectarBanco() {
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro na conexão: " . $e->getMessage());
    }
}

// Função para sanitizar dados
function sanitizar($dados) {
    return htmlspecialchars(trim($dados));
}

// Função para validar email
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Função para validar CPF (simplificada)
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    return strlen($cpf) === 11;
}

// Função para gerar hash da senha
function gerarHashSenha($senha) {
    return password_hash($senha, PASSWORD_DEFAULT);
}

// Função para verificar se usuário está logado
function usuarioEstaLogado() {
    return isset($_SESSION['usuario_id']);
}

// Função para verificar se é admin
function isAdmin() {
    return isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'admin';
}

// Função para verificar se é funcionário
function isFuncionario() {
    return isset($_SESSION['usuario_tipo']) && ($_SESSION['usuario_tipo'] === 'funcionario' || $_SESSION['usuario_tipo'] === 'admin');
}

// ============================================================================
// FUNÇÕES DE PERMISSÃO BASEADAS EM CARGO - CORRIGIDAS
// ============================================================================

// Função para obter cargo do funcionário
function getCargoFuncionario() {
    return $_SESSION['usuario_cargo'] ?? null;
}

// Verificar se pode acessar painel admin
function podeAcessarAdmin() {
    return isFuncionario();
}

// Verificar se pode VER produtos (todos funcionários podem ver)
function podeGerenciarProdutos() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'estoquista', 'vendedor', 'atendente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode ADICIONAR produtos (apenas admin, gerente)
function podeAdicionarProdutos() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode EDITAR produtos (apenas admin, gerente)
function podeEditarProdutos() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode EXCLUIR/DESATIVAR produtos (apenas admin e gerente)
function podeExcluirProdutos() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar estoque (apenas admin, gerente, estoquista)
function podeGerenciarEstoque() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'estoquista'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode VER categorias e marcas (todos funcionários podem ver)
function podeGerenciarCategorias() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'estoquista', 'vendedor', 'atendente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode EDITAR/ADICIONAR categorias e marcas (apenas admin e gerente)
function podeEditarCategorias() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar marcas (apenas admin e gerente)
function podeGerenciarMarcas() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar pedidos (admin, gerente, vendedor, atendente, estoquista)
function podeGerenciarPedidos() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'vendedor', 'atendente', 'estoquista'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar usuários (apenas admin e gerente)
function podeGerenciarUsuarios() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode VER funcionários (todos funcionários podem ver)
function podeVerFuncionarios() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'estoquista', 'vendedor', 'atendente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode EDITAR/ADICIONAR funcionários (apenas admin E GERENTE)
function podeGerenciarFuncionarios() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode ver relatórios (apenas admin e gerente)
function podeVerRelatorios() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar suporte (admin, gerente, atendente, estoquista)
function podeGerenciarSuporte() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'atendente', 'estoquista'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar FAQ (admin, gerente, atendente, estoquista)
function podeGerenciarFAQ() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente', 'atendente', 'estoquista'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode gerenciar cupons (apenas admin e gerente)
function podeGerenciarCupons() {
    if (!isFuncionario()) return false;
    
    $cargo = getCargoFuncionario();
    $cargos_permitidos = ['administrador', 'gerente'];
    return in_array($cargo, $cargos_permitidos);
}

// Verificar se pode ver dashboard (todos funcionários)
function podeVerDashboard() {
    return isFuncionario();
}
// Função para redirecionar
function redirecionar($pagina) {
    header("Location: $pagina");
    exit;
}

// Função para mostrar mensagens
function mostrarMensagem() {
    if (isset($_SESSION['sucesso'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                ' . $_SESSION['sucesso'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['sucesso']);
    }
    
    if (isset($_SESSION['erro'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                ' . $_SESSION['erro'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['erro']);
    }
    
    if (isset($_SESSION['info'])) {
        echo '<div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle me-2"></i>
                ' . $_SESSION['info'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['info']);
    }
}

// Função para verificar permissões de admin
function requererAdmin() {
    if (!isAdmin()) {
        $_SESSION['erro'] = "Acesso restrito à administração.";
        redirecionar('../indexx.php');
    }
}

// Função para verificar permissões de funcionário
function requererFuncionario() {
    if (!isFuncionario()) {
        $_SESSION['erro'] = "Acesso restrito à funcionários.";
        redirecionar('../indexx.php');
    }
}

// Função para fazer logout
function logout() {
    session_destroy();
    redirecionar('../indexx.php');
}

// Função para formatar preço
function formatarPreco($preco) {
    return 'R$ ' . number_format($preco, 2, ',', '.');
}

// ============================================================================
// FUNÇÕES AUXILIARES PARA CORES E FORMATAÇÃO
// ============================================================================

// Função para obter cor do badge baseado no status
function getStatusBadgeColor($status) {
    $colors = [
        'pendente' => 'warning',
        'pago' => 'info',
        'processando' => 'primary',
        'enviado' => 'success',
        'entregue' => 'success',
        'cancelado' => 'danger',
        'aberto' => 'warning',
        'em_andamento' => 'primary',
        'respondido' => 'info',
        'fechado' => 'success'
    ];
    return $colors[$status] ?? 'secondary';
}

// Função para obter cor do badge baseado na prioridade
function getPrioridadeBadgeColor($prioridade) {
    $colors = [
        'urgente' => 'danger',
        'alta' => 'warning',
        'media' => 'info',
        'baixa' => 'secondary'
    ];
    return $colors[$prioridade] ?? 'secondary';
}

// Função para obter cor do badge baseado no cargo
function getCargoBadgeColor($cargo) {
    $colors = [
        'administrador' => 'danger',
        'gerente' => 'warning',
        'vendedor' => 'info',
        'atendente' => 'primary',
        'estoquista' => 'success'
    ];
    return $colors[$cargo] ?? 'secondary';
}

// Função para calcular tempo de admissão
function calcularTempoAdmissao($data_admissao) {
    $admissao = new DateTime($data_admissao);
    $hoje = new DateTime();
    $intervalo = $admissao->diff($hoje);
    
    if ($intervalo->y > 0) {
        return $intervalo->y . ' ano' . ($intervalo->y > 1 ? 's' : '');
    } elseif ($intervalo->m > 0) {
        return $intervalo->m . ' mes' . ($intervalo->m > 1 ? 'es' : '');
    } else {
        return $intervalo->d . ' dia' . ($intervalo->d > 1 ? 's' : '');
    }
}

// Função para truncar texto
function truncateText($text, $length) {
    if (strlen($text) <= $length) {
        return $text;
    }
    return substr($text, 0, $length) . '...';
}

// Função para validar dados do produto
function validarDadosProduto($dados) {
    $erros = [];
    
    if (empty($dados['nome'])) {
        $erros[] = "Nome do produto é obrigatório.";
    }
    
    if (empty($dados['preco']) || $dados['preco'] <= 0) {
        $erros[] = "Preço deve ser maior que zero.";
    }
    
    if (!isset($dados['estoque']) || $dados['estoque'] < 0) {
        $erros[] = "Estoque não pode ser negativo.";
    }
    
    if (empty($dados['categoria_id'])) {
        $erros[] = "Categoria é obrigatória.";
    }
    
    if (empty($dados['marca_id'])) {
        $erros[] = "Marca é obrigatória.";
    }
    
    return $erros;
}

// Função para validar dados do funcionário
function validarDadosFuncionario($dados) {
    $erros = [];
    
    if (empty($dados['nome'])) {
        $erros[] = "Nome é obrigatório.";
    }
    
    if (empty($dados['email']) || !validarEmail($dados['email'])) {
        $erros[] = "Email válido é obrigatório.";
    }
    
    if (empty($dados['cargo'])) {
        $erros[] = "Cargo é obrigatório.";
    }
    
    if (empty($dados['departamento'])) {
        $erros[] = "Departamento é obrigatório.";
    }
    
    if (empty($dados['data_admissao'])) {
        $erros[] = "Data de admissão é obrigatória.";
    }
    
    return $erros;
}
?>