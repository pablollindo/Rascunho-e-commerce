<?php
// Iniciar sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Inicializar carrinho se não existir
if (!isset($_SESSION['carrinho']) || !is_array($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Incluir funções (sem redeclarar)
require_once 'funcoes.php';
require_once 'config.php';

// Verificar se usuário está logado e obter dados
$usuarioLogado = false;
$nomeUsuario = '';
$tipoUsuario = '';
$carrinhoCount = 0;

// SEMPRE contar itens do carrinho, independente de estar logado
$carrinhoCount = 0;
foreach ($_SESSION['carrinho'] as $item) {
    if (isset($item['quantidade'])) {
        $carrinhoCount += $item['quantidade'];
    }
}

// CORREÇÃO: Buscar contador da wishlist do banco de dados
$total_wishlist = 0;
if (isset($_SESSION['usuario_id']) && $_SESSION['usuario_tipo'] === 'cliente') {
    $usuario_id = $_SESSION['usuario_id'];
    $wishlist_query = "SELECT COUNT(*) as total FROM wishlist WHERE usuario_id = ?";
    $stmt = $conn->prepare($wishlist_query);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $total_wishlist = $row['total'];
    $stmt->close();
}

if (isset($_SESSION['usuario_id'])) {
    $usuarioLogado = true;
    $nomeUsuario = $_SESSION['usuario_nome'] ?? '';
    $tipoUsuario = $_SESSION['usuario_tipo'] ?? '';
}

// Buscar categorias para o menu
$categorias = [];
try {
    $pdo = conectarBanco();
    $stmt = $pdo->query("SELECT id, nome FROM categorias WHERE ativo = TRUE ORDER BY nome");
    $categorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    // Em caso de erro, categorias vazias
    error_log("Erro ao buscar categorias: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PGS Periféricos - Loja de Periféricos Gamers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <!-- Header - EXATAMENTE IGUAL AO INDEXX -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Barra de Pesquisa -->
                <div class="col-md-5">
                    <form action="produtos.php" method="GET" class="d-flex">
                        <div class="input-group">
                            <input type="text" class="form-control" name="busca" placeholder="Buscar produtos...">
                            <button class="btn btn-warning" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Menu Usuário - EXATAMENTE IGUAL AO INDEXX -->
                <div class="col-md-5 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                            <a href="lista_desejos.php" class="text-white text-decoration-none me-3 position-relative">
                                <i class="fas fa-heart me-1"></i>
                                Lista de Desejos
                                <?php if ($total_wishlist > 0): ?>
                                    <span class="badge bg-danger position-absolute top-0 start-100 translate-middle" id="wishlist-count">
                                        <?php echo $total_wishlist; ?>
                                    </span>
                                <?php endif; ?>
                            </a>
                            <!-- BOTÃO PAINEL ADMIN APENAS PARA FUNCIONÁRIOS -->
                            <?php if (isFuncionario()): ?>
                                <a href="admin/admin.php" class="text-white text-decoration-none me-3">
                                    <i class="fas fa-cog me-1"></i>
                                    Painel Admin
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none position-relative">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <?php if ($carrinhoCount > 0): ?>
                                <span class="badge bg-warning text-dark position-absolute top-0 start-100 translate-middle">
                                    <?php echo $carrinhoCount; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu de Navegação - EXATAMENTE IGUAL AO INDEXX -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="indexx.php">
                                <i class="fas fa-home me-1"></i>Início
                            </a>
                        </li>
                        
                        <!-- Teclados - SEM DROPDOWN -->
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=1">
                                <i class="fas fa-keyboard me-1"></i>Teclados
                            </a>
                        </li>
                        
                        <!-- Mouses - SEM DROPDOWN -->
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=2">
                                <i class="fas fa-mouse me-1"></i>Mouses
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=3">
                                <i class="fas fa-headphones me-1"></i>Headsets
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=4">
                                <i class="fas fa-desktop me-1"></i>Monitores
                            </a>
                        </li>
                        
                        <!-- Adicionei as outras categorias que estavam no seu banco -->
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=5">
                                <i class="fas fa-mouse-pointer me-1"></i>Mousepads
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=6">
                                <i class="fas fa-video me-1"></i>Webcams
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=7">
                                <i class="fas fa-microphone me-1"></i>Microfones
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?promocao=1">
                                <i class="fas fa-tag me-1"></i>Promoções
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <?php mostrarMensagem(); ?>

    <!-- Conteúdo Principal -->
    <main>