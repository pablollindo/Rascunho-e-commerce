<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';


// DEBUG - VERIFICAR SESSÃO
echo "<!-- ========= DEBUG SESSION ========= -->";
echo "<!-- usuario_id: " . ($_SESSION['usuario_id'] ?? 'NULL') . " -->";
echo "<!-- usuario_nome: " . ($_SESSION['usuario_nome'] ?? 'NULL') . " -->";
echo "<!-- usuario_tipo: " . ($_SESSION['usuario_tipo'] ?? 'NULL') . " -->";
echo "<!-- usuario_email: " . ($_SESSION['usuario_email'] ?? 'NULL') . " -->";
echo "<!-- isAdmin(): " . (isAdmin() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- isFuncionario(): " . (isFuncionario() ? 'TRUE' : 'FALSE') . " -->";
echo "<!-- ========= FIM DEBUG ========= -->";

// Verificar se é admin ou funcionário
if (!isFuncionario()) {
    $_SESSION['erro'] = "Acesso restrito à funcionários.";
    header("Location: ../indexx.php");
    exit;
}
// ... resto do código

// Buscar estatísticas para o dashboard
try {
    $pdo = conectarBanco();
    
    // Estatísticas gerais
    $sql_estatisticas = "
        SELECT 
            (SELECT COUNT(*) FROM pedidos WHERE status = 'pendente') as pedidos_pendentes,
            (SELECT COUNT(*) FROM pedidos WHERE status = 'pago') as pedidos_pagos,
            (SELECT COUNT(*) FROM produtos WHERE estoque <= 5 AND ativo = 1) as produtos_estoque_baixo,
            (SELECT COUNT(*) FROM tickets_suporte WHERE status = 'aberto') as tickets_abertos,
            (SELECT COUNT(*) FROM usuarios WHERE tipo = 'cliente') as total_clientes,
            (SELECT SUM(total) FROM pedidos WHERE status = 'entregue' AND DATE(data_pedido) = CURDATE()) as vendas_hoje,
            (SELECT COUNT(*) FROM produtos WHERE ativo = 1) as total_produtos,
            (SELECT COUNT(*) FROM pedidos WHERE DATE(data_pedido) = CURDATE()) as pedidos_hoje,
            (SELECT COUNT(*) FROM funcionarios WHERE ativo = 1) as total_funcionarios,
            (SELECT COUNT(*) FROM categorias WHERE ativo = 1) as total_categorias,
            (SELECT COUNT(*) FROM marcas WHERE ativo = 1) as total_marcas,
            (SELECT SUM(total) FROM pedidos WHERE status = 'entregue' AND MONTH(data_pedido) = MONTH(CURDATE())) as vendas_mes,
            (SELECT COUNT(*) FROM pedidos WHERE status = 'entregue' AND MONTH(data_pedido) = MONTH(CURDATE())) as pedidos_mes
    ";
    $estatisticas = $pdo->query($sql_estatisticas)->fetch(PDO::FETCH_ASSOC);
    
    // Últimos pedidos
    $sql_pedidos = "SELECT p.*, u.nome as cliente_nome 
                   FROM pedidos p 
                   JOIN usuarios u ON p.cliente_id = u.id 
                   ORDER BY p.data_pedido DESC 
                   LIMIT 5";
    $ultimos_pedidos = $pdo->query($sql_pedidos)->fetchAll(PDO::FETCH_ASSOC);
    
    // Produtos com estoque baixo
    $sql_estoque_baixo = "SELECT p.*, m.nome as marca_nome 
                         FROM produtos p 
                         LEFT JOIN marcas m ON p.marca_id = m.id 
                         WHERE p.estoque <= 5 AND p.ativo = 1 
                         ORDER BY p.estoque ASC 
                         LIMIT 5";
    $estoque_baixo = $pdo->query($sql_estoque_baixo)->fetchAll(PDO::FETCH_ASSOC);
    
    // Tickets abertos
    $sql_tickets = "SELECT t.*, u.nome as usuario_nome 
                   FROM tickets_suporte t 
                   JOIN usuarios u ON t.usuario_id = u.id 
                   WHERE t.status = 'aberto' 
                   ORDER BY t.prioridade DESC, t.data_abertura DESC 
                   LIMIT 5";
    $tickets_abertos = $pdo->query($sql_tickets)->fetchAll(PDO::FETCH_ASSOC);
    
    // Produtos mais vendidos do mês
    $sql_produtos_vendidos = "
        SELECT 
            p.nome,
            m.nome as marca_nome,
            SUM(ip.quantidade) as total_vendido,
            SUM(ip.quantidade * ip.preco_unitario) as total_faturado
        FROM itens_pedido ip
        JOIN produtos p ON ip.produto_id = p.id
        LEFT JOIN marcas m ON p.marca_id = m.id
        JOIN pedidos ped ON ip.pedido_id = ped.id
        WHERE ped.status = 'entregue' AND MONTH(ped.data_pedido) = MONTH(CURDATE())
        GROUP BY p.id, p.nome
        ORDER BY total_vendido DESC
        LIMIT 5
    ";
    $produtos_vendidos = $pdo->query($sql_produtos_vendidos)->fetchAll(PDO::FETCH_ASSOC);
    
    // Vendas dos últimos 7 dias para gráfico
    $sql_vendas_semana = "
        SELECT 
            DATE(data_pedido) as data,
            COUNT(*) as total_pedidos,
            SUM(total) as total_vendas
        FROM pedidos 
        WHERE status = 'entregue' AND data_pedido >= DATE_SUB(CURDATE(), INTERVAL 7 DAY)
        GROUP BY DATE(data_pedido)
        ORDER BY data
    ";
    $vendas_semana = $pdo->query($sql_vendas_semana)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar dashboard: " . $e->getMessage();
    $estatisticas = [];
    $ultimos_pedidos = [];
    $estoque_baixo = [];
    $tickets_abertos = [];
    $produtos_vendidos = [];
    $vendas_semana = [];
}
?>

<?php
// Incluir apenas o cabeçalho padrão
require_once '../includes/cabecalho.php';
?>

<style>
    .admin-container {
        background: #f8f9fa;
        min-height: 100vh;
    }
    .stat-card {
        transition: transform 0.3s;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .stat-card:hover {
        transform: translateY(-5px);
    }
    .stat-icon {
        font-size: 2.5rem;
        opacity: 0.8;
    }
    .admin-sidebar {
        background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
        min-height: calc(100vh - 200px);
        color: white;
    }
    .admin-sidebar .nav-link {
        color: white;
        padding: 12px 20px;
        margin: 2px 0;
        border-radius: 5px;
        transition: all 0.3s;
    }
    .admin-sidebar .nav-link:hover {
        background: rgba(255,255,255,0.1);
        transform: translateX(5px);
    }
    .admin-sidebar .nav-link.active {
        background: rgba(255,255,255,0.2);
        font-weight: bold;
        border-left: 4px solid #ffc107;
    }
    .admin-content {
        background: white;
        min-height: calc(100vh - 200px);
        padding: 20px;
    }
    .content-header {
        background: white;
        border-bottom: 1px solid #dee2e6;
        padding: 20px 0;
        margin-bottom: 20px;
    }
    .quick-actions .btn {
        margin: 5px;
        min-width: 150px;
    }
    .chart-container {
        position: relative;
        height: 250px;
        width: 100%;
    }
    .module-card {
        transition: all 0.3s;
        border: none;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    .module-card:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 15px rgba(0,0,0,0.2);
    }
    .module-icon {
        font-size: 2rem;
        margin-bottom: 15px;
    }
</style>

<div class="admin-container">
    <div class="container-fluid">
        <div class="row">
            <!-- Sidebar -->
            <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                <div class="p-4 text-center text-white">
                    <h4 class="mb-0">PGS Admin</h4>
                    <small>Painel de Controle</small>
                </div>
                
                <nav class="nav flex-column p-3">
                    <a href="admin.php" class="nav-link active">
                        <i class="fas fa-tachometer-alt me-2"></i>
                        Dashboard
                    </a>
                    
                    <?php if (isAdmin()): ?>
                    <a href="admin_produtos.php" class="nav-link">
                        <i class="fas fa-box me-2"></i>
                        Produtos
                    </a>
                    <a href="admin_estoque.php" class="nav-link">
                        <i class="fas fa-warehouse me-2"></i>
                        Estoque
                    </a>
                    <a href="admin_categorias_marcas.php" class="nav-link">
                        <i class="fas fa-tags me-2"></i>
                        Categorias & Marcas
                    </a>
                    <?php endif; ?>
                    
                    <a href="admin_pedidos.php" class="nav-link">
                        <i class="fas fa-shopping-cart me-2"></i>
                        Pedidos
                    </a>
                    
                    <?php if (isAdmin()): ?>
                    <a href="admin_usuarios.php" class="nav-link">
                        <i class="fas fa-users me-2"></i>
                        Clientes
                    </a>
                    <a href="admin_funcionarios.php" class="nav-link">
                        <i class="fas fa-user-tie me-2"></i>
                        Funcionários
                    </a>
                    <?php endif; ?>
                    
                    <a href="admin_suporte.php" class="nav-link">
                        <i class="fas fa-headset me-2"></i>
                        Suporte
                    </a>
                    
                    <?php if (isAdmin()): ?>
                    <a href="admin_relatorios.php" class="nav-link">
                        <i class="fas fa-chart-bar me-2"></i>
                        Relatórios
                    </a>
                    <?php endif; ?>
                    
                    <hr class="bg-light my-3">
                    
                    <a href="../indexx.php" class="nav-link">
                        <i class="fas fa-store me-2"></i>
                        Voltar para Loja
                    </a>
                </nav>
            </div>

            <!-- Conteúdo Principal -->
            <div class="col-md-9 col-lg-10 admin-content">
                <!-- Header Interno -->
                <div class="content-header">
                    <div class="d-flex justify-content-between align-items-center">
                        <h1 class="h3 mb-0">
                            <i class="fas fa-tachometer-alt me-2 text-primary"></i>
                            Dashboard
                        </h1>
                        <div class="d-flex align-items-center">
                            <span class="me-3 text-muted">
                                <i class="fas fa-user me-1"></i>
                                <?= $_SESSION['usuario_nome'] ?>
                                <small class="badge bg-secondary ms-1"><?= $_SESSION['usuario_tipo'] ?></small>
                            </span>
                            <small class="text-muted"><?= date('d/m/Y H:i') ?></small>
                        </div>
                    </div>
                </div>

                <?php mostrarMensagem(); ?>

                <!-- Ações Rápidas -->
                <?php if (isAdmin()): ?>
                <div class="row mb-4">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header bg-light">
                                <h5 class="mb-0">
                                    <i class="fas fa-bolt me-2 text-warning"></i>
                                    Ações Rápidas
                                </h5>
                            </div>
                            <div class="card-body text-center quick-actions">
                                <a href="admin_produtos.php?action=add" class="btn btn-success">
                                    <i class="fas fa-plus me-2"></i>
                                    Novo Produto
                                </a>
                                <a href="admin_estoque.php" class="btn btn-warning">
                                    <i class="fas fa-warehouse me-2"></i>
                                    Gerenciar Estoque
                                </a>
                                <a href="admin_pedidos.php" class="btn btn-primary">
                                    <i class="fas fa-shopping-cart me-2"></i>
                                    Ver Pedidos
                                </a>
                                <a href="admin_categorias_marcas.php" class="btn btn-info">
                                    <i class="fas fa-tags me-2"></i>
                                    Categorias & Marcas
                                </a>
                                <a href="admin_funcionarios.php?action=add" class="btn btn-dark">
                                    <i class="fas fa-user-plus me-2"></i>
                                    Novo Funcionário
                                </a>
                                <a href="admin_relatorios.php" class="btn btn-secondary">
                                    <i class="fas fa-chart-bar me-2"></i>
                                    Ver Relatórios
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>

                <!-- Cards de Estatísticas Principais -->
                <div class="row mb-4">
                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card border-left-primary">
                            <div class="card-body text-center">
                                <div class="text-primary mb-2">
                                    <i class="fas fa-shopping-cart fa-2x"></i>
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $estatisticas['pedidos_hoje'] ?? 0 ?>
                                </div>
                                <div class="text-xs font-weight-bold text-primary text-uppercase">
                                    Pedidos Hoje
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card border-left-success">
                            <div class="card-body text-center">
                                <div class="text-success mb-2">
                                    <i class="fas fa-dollar-sign fa-2x"></i>
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    R$ <?= number_format($estatisticas['vendas_hoje'] ?? 0, 2, ',', '.') ?>
                                </div>
                                <div class="text-xs font-weight-bold text-success text-uppercase">
                                    Vendas Hoje
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card border-left-info">
                            <div class="card-body text-center">
                                <div class="text-info mb-2">
                                    <i class="fas fa-box fa-2x"></i>
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $estatisticas['total_produtos'] ?? 0 ?>
                                </div>
                                <div class="text-xs font-weight-bold text-info text-uppercase">
                                    Total Produtos
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card border-left-warning">
                            <div class="card-body text-center">
                                <div class="text-warning mb-2">
                                    <i class="fas fa-users fa-2x"></i>
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $estatisticas['total_clientes'] ?? 0 ?>
                                </div>
                                <div class="text-xs font-weight-bold text-warning text-uppercase">
                                    Total Clientes
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card border-left-danger">
                            <div class="card-body text-center">
                                <div class="text-danger mb-2">
                                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $estatisticas['produtos_estoque_baixo'] ?? 0 ?>
                                </div>
                                <div class="text-xs font-weight-bold text-danger text-uppercase">
                                    Estoque Baixo
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-2 col-md-4 mb-4">
                        <div class="card stat-card border-left-secondary">
                            <div class="card-body text-center">
                                <div class="text-secondary mb-2">
                                    <i class="fas fa-headset fa-2x"></i>
                                </div>
                                <div class="h5 mb-0 font-weight-bold text-gray-800">
                                    <?= $estatisticas['tickets_abertos'] ?? 0 ?>
                                </div>
                                <div class="text-xs font-weight-bold text-secondary text-uppercase">
                                    Tickets Abertos
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                     <div class="row">
                    <!-- Gráfico de Vendas da Semana -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-chart-line me-2"></i>
                                    Vendas dos Últimos 7 Dias
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="chart-container">
                                    <canvas id="vendasSemanaChart"></canvas>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Estatísticas do Mês -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-calendar me-2"></i>
                                    Este Mês
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="row text-center">
                                    <div class="col-6 mb-3">
                                        <div class="h4 text-primary"><?= $estatisticas['pedidos_mes'] ?? 0 ?></div>
                                        <small class="text-muted">Pedidos Entregues</small>
                                    </div>
                                    <div class="col-6 mb-3">
                                        <div class="h4 text-success">R$ <?= number_format($estatisticas['vendas_mes'] ?? 0, 2, ',', '.') ?></div>
                                        <small class="text-muted">Total em Vendas</small>
                                    </div>
                                    <div class="col-6">
                                        <div class="h4 text-info"><?= $estatisticas['total_categorias'] ?? 0 ?></div>
                                        <small class="text-muted">Categorias</small>
                                    </div>
                                    <div class="col-6">
                                        <div class="h4 text-warning"><?= $estatisticas['total_marcas'] ?? 0 ?></div>
                                        <small class="text-muted">Marcas</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Módulos do Sistema -->
                    <div class="col-12 mb-4">
                        <h4 class="border-bottom pb-2 mb-4">
                            <i class="fas fa-th-large me-2 text-primary"></i>
                            Módulos do Sistema
                        </h4>
                        <div class="row">
                            <!-- Gestão de Produtos -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-primary">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-primary">
                                            <i class="fas fa-box"></i>
                                        </div>
                                        <h5 class="card-title">Gestão de Produtos</h5>
                                        <p class="card-text text-muted small">
                                            Cadastrar, editar e gerenciar produtos do catálogo
                                        </p>
                                        <div class="btn-group w-100">
                                            <a href="admin_produtos.php" class="btn btn-outline-primary btn-sm">
                                                <i class="fas fa-list me-1"></i> Ver Todos
                                            </a>
                                            <a href="admin_produtos.php?action=add" class="btn btn-primary btn-sm">
                                                <i class="fas fa-plus me-1"></i> Novo
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Controle de Estoque -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-warning">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-warning">
                                            <i class="fas fa-warehouse"></i>
                                        </div>
                                        <h5 class="card-title">Controle de Estoque</h5>
                                        <p class="card-text text-muted small">
                                            Gerenciar quantidades e alertas de estoque
                                        </p>
                                        <a href="admin_estoque.php" class="btn btn-warning btn-sm w-100">
                                            <i class="fas fa-cog me-1"></i> Gerenciar Estoque
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Gestão de Pedidos -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-success">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-success">
                                            <i class="fas fa-shopping-cart"></i>
                                        </div>
                                        <h5 class="card-title">Gestão de Pedidos</h5>
                                        <p class="card-text text-muted small">
                                            Acompanhar e atualizar status dos pedidos
                                        </p>
                                        <a href="admin_pedidos.php" class="btn btn-success btn-sm w-100">
                                            <i class="fas fa-eye me-1"></i> Ver Pedidos
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Categorias & Marcas -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-info">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-info">
                                            <i class="fas fa-tags"></i>
                                        </div>
                                        <h5 class="card-title">Categorias & Marcas</h5>
                                        <p class="card-text text-muted small">
                                            Organizar categorias e marcas dos produtos
                                        </p>
                                        <a href="admin_categorias_marcas.php" class="btn btn-info btn-sm w-100">
                                            <i class="fas fa-cog me-1"></i> Gerenciar
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Gestão de Clientes -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-primary">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-primary">
                                            <i class="fas fa-users"></i>
                                        </div>
                                        <h5 class="card-title">Gestão de Clientes</h5>
                                        <p class="card-text text-muted small">
                                            Visualizar e gerenciar clientes cadastrados
                                        </p>
                                        <a href="admin_usuarios.php" class="btn btn-outline-primary btn-sm w-100">
                                            <i class="fas fa-list me-1"></i> Ver Clientes
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Gestão de Funcionários -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-dark">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-dark">
                                            <i class="fas fa-user-tie"></i>
                                        </div>
                                        <h5 class="card-title">Gestão de Funcionários</h5>
                                        <p class="card-text text-muted small">
                                            Cadastrar e gerenciar equipe de funcionários
                                        </p>
                                        <div class="btn-group w-100">
                                            <a href="admin_funcionarios.php" class="btn btn-outline-dark btn-sm">
                                                <i class="fas fa-list me-1"></i> Ver
                                            </a>
                                            <a href="admin_funcionarios.php?action=add" class="btn btn-dark btn-sm">
                                                <i class="fas fa-plus me-1"></i> Novo
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Central de Suporte -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-warning">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-warning">
                                            <i class="fas fa-headset"></i>
                                        </div>
                                        <h5 class="card-title">Central de Suporte</h5>
                                        <p class="card-text text-muted small">
                                            Atender e gerenciar tickets de suporte
                                        </p>
                                        <a href="admin_suporte.php" class="btn btn-warning btn-sm w-100">
                                            <i class="fas fa-inbox me-1"></i> Ver Tickets
                                        </a>
                                    </div>
                                </div>
                            </div>

                            <!-- Relatórios -->
                            <div class="col-xl-3 col-md-6 mb-4">
                                <div class="card module-card border-secondary">
                                    <div class="card-body text-center">
                                        <div class="module-icon text-secondary">
                                            <i class="fas fa-chart-bar"></i>
                                        </div>
                                        <h5 class="card-title">Relatórios</h5>
                                        <p class="card-text text-muted small">
                                            Relatórios detalhados de vendas e performance
                                        </p>
                                        <a href="admin_relatorios.php" class="btn btn-secondary btn-sm w-100">
                                            <i class="fas fa-chart-line me-1"></i> Ver Relatórios
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Últimos Pedidos -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-primary text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-shopping-cart me-2"></i>
                                    Últimos Pedidos
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($ultimos_pedidos)): ?>
                                    <p class="text-muted text-center py-3">Nenhum pedido recente.</p>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($ultimos_pedidos as $pedido): ?>
                                        <div class="list-group-item d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong>#<?= str_pad($pedido['id'], 6, '0', STR_PAD_LEFT) ?></strong>
                                                <br>
                                                <small class="text-muted"><?= htmlspecialchars($pedido['cliente_nome']) ?></small>
                                            </div>
                                            <div class="text-end">
                                                <span class="badge bg-<?= getStatusBadgeColor($pedido['status']) ?>">
                                                    <?= ucfirst($pedido['status']) ?>
                                                </span>
                                                <br>
                                                <small class="text-muted"><?= date('d/m H:i', strtotime($pedido['data_pedido'])) ?></small>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="admin_pedidos.php" class="btn btn-outline-primary btn-sm">
                                            Ver Todos os Pedidos
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Estoque Baixo -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-warning text-dark">
                                <h5 class="mb-0">
                                    <i class="fas fa-exclamation-triangle me-2"></i>
                                    Estoque Baixo
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($estoque_baixo)): ?>
                                    <p class="text-muted text-center py-3">Nenhum produto com estoque baixo.</p>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($estoque_baixo as $produto): ?>
                                        <div class="list-group-item d-flex justify-content-between align-items-center">
                                            <div>
                                                <strong><?= htmlspecialchars($produto['nome']) ?></strong>
                                                <br>
                                                <small class="text-muted"><?= htmlspecialchars($produto['marca_nome']) ?></small>
                                            </div>
                                            <div class="text-end">
                                                <span class="badge bg-<?= $produto['estoque'] == 0 ? 'danger' : 'warning' ?>">
                                                    <?= $produto['estoque'] ?> unid.
                                                </span>
                                                <br>
                                                <small class="text-muted">Cód: #<?= str_pad($produto['id'], 6, '0', STR_PAD_LEFT) ?></small>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="admin_estoque.php" class="btn btn-outline-warning btn-sm">
                                            Gerenciar Estoque
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <!-- Produtos Mais Vendidos -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-star me-2"></i>
                                    Produtos Mais Vendidos (Mês)
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($produtos_vendidos)): ?>
                                    <p class="text-muted text-center py-3">Nenhum produto vendido este mês.</p>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($produtos_vendidos as $produto): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <strong><?= htmlspecialchars($produto['nome']) ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?= htmlspecialchars($produto['marca_nome']) ?></small>
                                                </div>
                                                <div class="text-end">
                                                    <span class="badge bg-success"><?= $produto['total_vendido'] ?> vendas</span>
                                                    <br>
                                                    <small class="text-muted">R$ <?= number_format($produto['total_faturado'], 2, ',', '.') ?></small>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <!-- Tickets Abertos -->
                    <div class="col-lg-6 mb-4">
                        <div class="card">
                            <div class="card-header bg-info text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-headset me-2"></i>
                                    Tickets de Suporte Abertos
                                </h5>
                            </div>
                            <div class="card-body">
                                <?php if (empty($tickets_abertos)): ?>
                                    <p class="text-muted text-center py-3">Nenhum ticket aberto no momento.</p>
                                <?php else: ?>
                                    <div class="list-group list-group-flush">
                                        <?php foreach ($tickets_abertos as $ticket): ?>
                                        <div class="list-group-item">
                                            <div class="d-flex justify-content-between align-items-center">
                                                <div>
                                                    <strong><?= htmlspecialchars($ticket['assunto']) ?></strong>
                                                    <br>
                                                    <small class="text-muted"><?= htmlspecialchars($ticket['usuario_nome']) ?></small>
                                                </div>
                                                <div class="text-end">
                                                    <span class="badge bg-<?= getPrioridadeBadgeColor($ticket['prioridade']) ?>">
                                                        <?= ucfirst($ticket['prioridade']) ?>
                                                    </span>
                                                    <br>
                                                    <small class="text-muted"><?= date('d/m H:i', strtotime($ticket['data_abertura'])) ?></small>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>
                                    <div class="text-center mt-3">
                                        <a href="admin_suporte.php" class="btn btn-outline-info btn-sm">
                                            Gerenciar Suporte
                                        </a>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
// Incluir apenas o rodapé padrão
include '../includes/rodape.php';
?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Gráfico de Vendas da Semana - CONEXÃO DIRETA
    document.addEventListener('DOMContentLoaded', function() {
        const ctx = document.getElementById('vendasSemanaChart').getContext('2d');
        
        // Dados do gráfico - Buscar dados reais do banco
        const dadosVendas = {
            labels: [
                <?php
                // Gerar labels dos últimos 7 dias
                $labels = [];
                for ($i = 6; $i >= 0; $i--) {
                    $data = date('d/m', strtotime("-$i days"));
                    $labels[] = "'$data'";
                }
                echo implode(', ', $labels);
                ?>
            ],
            datasets: [{
                label: 'Vendas (R$)',
                data: [
                    <?php
                    // Buscar vendas dos últimos 7 dias
                    try {
                        $pdo = conectarBanco();
                        $dados_grafico = [];
                        
                        for ($i = 6; $i >= 0; $i--) {
                            $data = date('Y-m-d', strtotime("-$i days"));
                            
                            $sql = "SELECT COALESCE(SUM(total), 0) as total_vendas 
                                    FROM pedidos 
                                    WHERE status = 'entregue' AND DATE(data_pedido) = ?";
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute([$data]);
                            $result = $stmt->fetch(PDO::FETCH_ASSOC);
                            
                            $dados_grafico[] = $result['total_vendas'];
                        }
                        
                        echo implode(', ', $dados_grafico);
                    } catch (PDOException $e) {
                        echo "0, 0, 0, 0, 0, 0, 0";
                    }
                    ?>
                ],
                backgroundColor: 'rgba(54, 162, 235, 0.6)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                borderRadius: 5,
                borderSkipped: false,
            }]
        };

        // Configurações do gráfico
        const config = {
            type: 'bar',
            data: dadosVendas,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function(context) {
                                return 'R$ ' + context.raw.toLocaleString('pt-BR', {minimumFractionDigits: 2});
                            }
                        }
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        ticks: {
                            callback: function(value) {
                                return 'R$ ' + value.toLocaleString('pt-BR');
                            }
                        },
                        grid: {
                            color: 'rgba(0, 0, 0, 0.1)'
                        }
                    },
                    x: {
                        grid: {
                            display: false
                        }
                    }
                },
                animation: {
                    duration: 1000,
                    easing: 'easeInOutQuart'
                }
            }
        };

        // Criar o gráfico
        new Chart(ctx, config);
    });

    // Funções auxiliares para cores dos badges
    function getStatusBadgeColor(status) {
        const colors = {
            'pendente': 'warning',
            'pago': 'info',
            'processando': 'primary',
            'enviado': 'success',
            'entregue': 'success',
            'cancelado': 'danger'
        };
        return colors[status] || 'secondary';
    }

    function getPrioridadeBadgeColor(prioridade) {
        const colors = {
            'baixa': 'secondary',
            'media': 'info',
            'alta': 'warning',
            'urgente': 'danger'
        };
        return colors[prioridade] || 'secondary';
    }
</script>