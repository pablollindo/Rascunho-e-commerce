<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se pode ver categorias e marcas
if (!podeGerenciarCategorias()) {
    $_SESSION['erro'] = "Acesso restrito.";
    header("Location: ../indexx.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$tipo = $_GET['tipo'] ?? 'categorias';
$id = intval($_GET['id'] ?? 0);

try {
    $pdo = conectarBanco();
    
    switch ($action) {
        case 'add':
        case 'edit':
            // Verificar permissão para editar
            if (!podeEditarCategorias()) {
                $_SESSION['erro'] = "Acesso negado para editar categorias/marcas.";
                header("Location: admin_categorias_marcas.php");
                exit;
            }
            
            $item = null;
            if ($action === 'edit' && $id > 0) {
                if ($tipo === 'categorias') {
                    $stmt = $pdo->prepare("SELECT * FROM categorias WHERE id = ?");
                } else {
                    $stmt = $pdo->prepare("SELECT * FROM marcas WHERE id = ?");
                }
                $stmt->execute([$id]);
                $item = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$item) {
                    $_SESSION['erro'] = ucfirst($tipo) . " não encontrada.";
                    header("Location: admin_categorias_marcas.php");
                    exit;
                }
            }
            break;
            
        case 'delete':
            // Verificar permissão para excluir
            if (!podeEditarCategorias()) {
                $_SESSION['erro'] = "Acesso negado para excluir categorias/marcas.";
                header("Location: admin_categorias_marcas.php");
                exit;
            }
            
            if ($id > 0) {
                if ($tipo === 'categorias') {
                    // Verificar se existem produtos usando esta categoria
                    $stmt_check = $pdo->prepare("SELECT COUNT(*) as total FROM produtos WHERE categoria_id = ?");
                    $stmt_check->execute([$id]);
                    $result = $stmt_check->fetch(PDO::FETCH_ASSOC);
                    
                    if ($result['total'] > 0) {
                        $_SESSION['erro'] = "Não é possível excluir esta categoria pois existem produtos vinculados a ela.";
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM categorias WHERE id = ?");
                        $stmt->execute([$id]);
                        $_SESSION['sucesso'] = "Categoria excluída com sucesso!";
                    }
                } else {
                    // Verificar se existem produtos usando esta marca
                    $stmt_check = $pdo->prepare("SELECT COUNT(*) as total FROM produtos WHERE marca_id = ?");
                    $stmt_check->execute([$id]);
                    $result = $stmt_check->fetch(PDO::FETCH_ASSOC);
                    
                    if ($result['total'] > 0) {
                        $_SESSION['erro'] = "Não é possível excluir esta marca pois existem produtos vinculados a ela.";
                    } else {
                        $stmt = $pdo->prepare("DELETE FROM marcas WHERE id = ?");
                        $stmt->execute([$id]);
                        $_SESSION['sucesso'] = "Marca excluída com sucesso!";
                    }
                }
            }
            header("Location: admin_categorias_marcas.php?tipo=" . $tipo);
            exit;
            
        case 'save':
            // Verificar permissão para salvar
            if (!podeEditarCategorias()) {
                $_SESSION['erro'] = "Acesso negado para salvar categorias/marcas.";
                header("Location: admin_categorias_marcas.php");
                exit;
            }
            
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $dados = [
                    'nome' => trim($_POST['nome']),
                    'descricao' => trim($_POST['descricao'] ?? ''),
                    'ativo' => isset($_POST['ativo']) ? 1 : 0
                ];
                
                if ($tipo === 'marcas') {
                    $dados['site_url'] = trim($_POST['site_url'] ?? '');
                }
                
                if (empty($dados['nome'])) {
                    $_SESSION['erro'] = "Nome é obrigatório.";
                    header("Location: admin_categorias_marcas.php?action=" . ($_POST['id'] ? 'edit&id=' . $_POST['id'] . '&tipo=' . $tipo : 'add&tipo=' . $tipo));
                    exit;
                }
                
                if ($_POST['id']) {
                    // Edição
                    if ($tipo === 'categorias') {
                        $stmt = $pdo->prepare("UPDATE categorias SET nome = ?, descricao = ?, ativo = ? WHERE id = ?");
                    } else {
                        $stmt = $pdo->prepare("UPDATE marcas SET nome = ?, descricao = ?, site_url = ?, ativo = ? WHERE id = ?");
                        $dados[] = $_POST['id'];
                    }
                    $dados[] = $_POST['id'];
                    $stmt->execute(array_values($dados));
                    $_SESSION['sucesso'] = ucfirst($tipo) . " atualizada com sucesso!";
                } else {
                    // Inserção
                    if ($tipo === 'categorias') {
                        $stmt = $pdo->prepare("INSERT INTO categorias (nome, descricao, ativo) VALUES (?, ?, ?)");
                    } else {
                        $stmt = $pdo->prepare("INSERT INTO marcas (nome, descricao, site_url, ativo, data_criacao) VALUES (?, ?, ?, ?, NOW())");
                    }
                    $stmt->execute(array_values($dados));
                    $_SESSION['sucesso'] = ucfirst($tipo) . " cadastrada com sucesso!";
                }
                
                header("Location: admin_categorias_marcas.php?tipo=" . $tipo);
                exit;
            }
            break;
    }
    
    // Buscar categorias e marcas para listagem
    $categorias = $pdo->query("SELECT * FROM categorias ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
    $marcas = $pdo->query("SELECT * FROM marcas ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro no banco de dados: " . $e->getMessage();
    $categorias = [];
    $marcas = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Categorias e Marcas - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
        .nav-tabs .nav-link.active {
            font-weight: bold;
            border-bottom: 3px solid #0d6efd;
        }
    </style>
</head>
<body>
    <!-- Cabeçalho Igual ao Indexx -->
    <?php 
    $tituloPagina = "Gerenciar Categorias e Marcas - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            Dashboard
                        </a>
                        
                        <?php if (podeGerenciarProdutos()): ?>
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>
                            Produtos
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarEstoque()): ?>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>
                            Estoque
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarCategorias()): ?>
                        <a href="admin_categorias_marcas.php" class="nav-link active">
                            <i class="fas fa-tags me-2"></i>
                            Categorias & Marcas
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos
                        </a>
                        
                        <?php if (podeGerenciarUsuarios()): ?>
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>
                            Clientes
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeVerFuncionarios()): ?>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>
                            Funcionários
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>
                            Suporte
                        </a>
                        
                        <?php if (podeVerRelatorios()): ?>
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>
                            Relatórios
                        </a>
                        <?php endif; ?>
                        
                        <hr class="bg-light my-3">
                        
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>
                            Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-tags me-2"></i>
                                Gerenciar Categorias e Marcas
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <?php if (podeEditarCategorias()): ?>
                                <div class="btn-group">
                                    <a href="admin_categorias_marcas.php?action=add&tipo=categorias" class="btn btn-success">
                                        <i class="fas fa-plus me-2"></i>
                                        Nova Categoria
                                    </a>
                                    <a href="admin_categorias_marcas.php?action=add&tipo=marcas" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>
                                        Nova Marca
                                    </a>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <!-- Abas para Categorias e Marcas -->
                    <ul class="nav nav-tabs mb-4" id="myTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?= $tipo === 'categorias' ? 'active' : '' ?>" id="categorias-tab" data-bs-toggle="tab" data-bs-target="#categorias" type="button" role="tab" aria-controls="categorias" aria-selected="true">
                                <i class="fas fa-folder me-2"></i>
                                Categorias
                            </button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link <?= $tipo === 'marcas' ? 'active' : '' ?>" id="marcas-tab" data-bs-toggle="tab" data-bs-target="#marcas" type="button" role="tab" aria-controls="marcas" aria-selected="false">
                                <i class="fas fa-trademark me-2"></i>
                                Marcas
                            </button>
                        </li>
                    </ul>

                    <div class="tab-content" id="myTabContent">
                        <!-- ABA CATEGORIAS -->
                        <div class="tab-pane fade <?= $tipo === 'categorias' ? 'show active' : '' ?>" id="categorias" role="tabpanel" aria-labelledby="categorias-tab">
                            <?php if (($action === 'add' || $action === 'edit') && $tipo === 'categorias' && podeEditarCategorias()): ?>
                                <!-- Formulário de Categoria -->
                                <div class="card">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-<?= $action === 'add' ? 'plus' : 'edit' ?> me-2"></i>
                                            <?= $action === 'add' ? 'Adicionar' : 'Editar' ?> Categoria
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST" action="admin_categorias_marcas.php?action=save&tipo=categorias">
                                            <input type="hidden" name="id" value="<?= $item['id'] ?? '' ?>">
                                            
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="nome" class="form-label">Nome da Categoria *</label>
                                                    <input type="text" class="form-control" id="nome" name="nome" 
                                                           value="<?= htmlspecialchars($item['nome'] ?? '') ?>" required>
                                                </div>
                                                
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Status</label>
                                                    <div class="form-check mt-2">
                                                        <input type="checkbox" class="form-check-input" id="ativo" name="ativo" 
                                                               <?= ($item['ativo'] ?? 1) ? 'checked' : '' ?>>
                                                        <label class="form-check-label" for="ativo">Ativa</label>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="descricao" class="form-label">Descrição</label>
                                                <textarea class="form-control" id="descricao" name="descricao" rows="3"><?= htmlspecialchars($item['descricao'] ?? '') ?></textarea>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between">
                                                <a href="admin_categorias_marcas.php?tipo=categorias" class="btn btn-secondary">
                                                    <i class="fas fa-arrow-left me-2"></i>
                                                    Voltar
                                                </a>
                                                <button type="submit" class="btn btn-success">
                                                    <i class="fas fa-save me-2"></i>
                                                    Salvar Categoria
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <!-- Lista de Categorias -->
                                <div class="card">
                                    <div class="card-header bg-light">
                                        <h5 class="mb-0">
                                            <i class="fas fa-list me-2"></i>
                                            Lista de Categorias
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($categorias)): ?>
                                            <p class="text-muted text-center py-4">
                                                <i class="fas fa-folder-open fa-2x mb-3"></i><br>
                                                Nenhuma categoria cadastrada.
                                            </p>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-striped table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Nome</th>
                                                            <th>Descrição</th>
                                                            <th>Status</th>
                                                            <?php if (podeEditarCategorias()): ?>
                                                            <th>Ações</th>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </thead>
                                                   <tbody>
    <?php foreach ($categorias as $cat): ?>
    <tr>
        <td>#<?= str_pad($cat['id'], 3, '0', STR_PAD_LEFT) ?></td>
        <td>
            <strong><?= htmlspecialchars($cat['nome']) ?></strong>
        </td>
        <td><?= htmlspecialchars($cat['descricao'] ?? 'Sem descrição') ?></td>
        <td>
            <span class="badge bg-<?= ($cat['ativo'] ?? 0) ? 'success' : 'secondary' ?>">
                <?= ($cat['ativo'] ?? 0) ? 'Ativa' : 'Inativa' ?>
            </span>
        </td>
        <?php if (podeEditarCategorias()): ?>
        <td>
            <div class="btn-group btn-group-sm">
                <a href="admin_categorias_marcas.php?action=edit&id=<?= $cat['id'] ?>&tipo=categorias" 
                   class="btn btn-outline-primary" title="Editar">
                    <i class="fas fa-edit"></i>
                </a>
                <a href="admin_categorias_marcas.php?action=delete&id=<?= $cat['id'] ?>&tipo=categorias" 
                   class="btn btn-outline-danger" 
                   onclick="return confirm('Tem certeza que deseja excluir esta categoria?')"
                   title="Excluir">
                    <i class="fas fa-trash"></i>
                </a>
            </div>
        </td>
        <?php endif; ?>
    </tr>
    <?php endforeach; ?>
</tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>

                        <!-- ABA MARCAS -->
                        <div class="tab-pane fade <?= $tipo === 'marcas' ? 'show active' : '' ?>" id="marcas" role="tabpanel" aria-labelledby="marcas-tab">
                            <?php if (($action === 'add' || $action === 'edit') && $tipo === 'marcas' && podeEditarCategorias()): ?>
                                <!-- Formulário de Marca -->
                                <div class="card">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-<?= $action === 'add' ? 'plus' : 'edit' ?> me-2"></i>
                                            <?= $action === 'add' ? 'Adicionar' : 'Editar' ?> Marca
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST" action="admin_categorias_marcas.php?action=save&tipo=marcas">
                                            <input type="hidden" name="id" value="<?= $item['id'] ?? '' ?>">
                                            
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="nome" class="form-label">Nome da Marca *</label>
                                                    <input type="text" class="form-control" id="nome" name="nome" 
                                                           value="<?= htmlspecialchars($item['nome'] ?? '') ?>" required>
                                                </div>
                                                
                                                <div class="col-md-6 mb-3">
                                                    <label for="site_url" class="form-label">Site URL</label>
                                                    <input type="url" class="form-control" id="site_url" name="site_url" 
                                                           value="<?= htmlspecialchars($item['site_url'] ?? '') ?>">
                                                </div>
                                            </div>
                                            
                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label class="form-label">Status</label>
                                                    <div class="form-check mt-2">
                                                        <input type="checkbox" class="form-check-input" id="ativo" name="ativo" 
                                                               <?= ($item['ativo'] ?? 1) ? 'checked' : '' ?>>
                                                        <label class="form-check-label" for="ativo">Ativa</label>
                                                    </div>
                                                </div>
                                            </div>
                                            
                                            <div class="mb-3">
                                                <label for="descricao" class="form-label">Descrição</label>
                                                <textarea class="form-control" id="descricao" name="descricao" rows="3"><?= htmlspecialchars($item['descricao'] ?? '') ?></textarea>
                                            </div>
                                            
                                            <div class="d-flex justify-content-between">
                                                <a href="admin_categorias_marcas.php?tipo=marcas" class="btn btn-secondary">
                                                    <i class="fas fa-arrow-left me-2"></i>
                                                    Voltar
                                                </a>
                                                <button type="submit" class="btn btn-success">
                                                    <i class="fas fa-save me-2"></i>
                                                    Salvar Marca
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            <?php else: ?>
                                <!-- Lista de Marcas -->
                                <div class="card">
                                    <div class="card-header bg-light">
                                        <h5 class="mb-0">
                                            <i class="fas fa-list me-2"></i>
                                            Lista de Marcas
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($marcas)): ?>
                                            <p class="text-muted text-center py-4">
                                                <i class="fas fa-trademark fa-2x mb-3"></i><br>
                                                Nenhuma marca cadastrada.
                                            </p>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-striped table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>ID</th>
                                                            <th>Nome</th>
                                                            <th>Site</th>
                                                            <th>Descrição</th>
                                                            <th>Status</th>
                                                            <?php if (podeEditarCategorias()): ?>
                                                            <th>Ações</th>
                                                            <?php endif; ?>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($marcas as $marca): ?>
                                                        <tr>
                                                            <td>#<?= str_pad($marca['id'], 3, '0', STR_PAD_LEFT) ?></td>
                                                            <td>
                                                                <strong><?= htmlspecialchars($marca['nome']) ?></strong>
                                                            </td>
                                                            <td>
                                                                <?php if (!empty($marca['site_url'])): ?>
                                                                    <a href="<?= htmlspecialchars($marca['site_url']) ?>" target="_blank" class="text-decoration-none">
                                                                        <i class="fas fa-external-link-alt me-1"></i>
                                                                        Site
                                                                    </a>
                                                                <?php else: ?>
                                                                    <span class="text-muted">-</span>
                                                                <?php endif; ?>
                                                            </td>
                                                            <td><?= htmlspecialchars($marca['descricao'] ?? 'Sem descrição') ?></td>
                                                            <td>
                                                                <span class="badge bg-<?= $marca['ativo'] ? 'success' : 'secondary' ?>">
                                                                    <?= $marca['ativo'] ? 'Ativa' : 'Inativa' ?>
                                                                </span>
                                                            </td>
                                                            <?php if (podeEditarCategorias()): ?>
                                                            <td>
                                                                <div class="btn-group btn-group-sm">
                                                                    <a href="admin_categorias_marcas.php?action=edit&id=<?= $marca['id'] ?>&tipo=marcas" 
                                                                       class="btn btn-outline-primary" title="Editar">
                                                                        <i class="fas fa-edit"></i>
                                                                    </a>
                                                                    <a href="admin_categorias_marcas.php?action=delete&id=<?= $marca['id'] ?>&tipo=marcas" 
                                                                       class="btn btn-outline-danger" 
                                                                       onclick="return confirm('Tem certeza que deseja excluir esta marca?')"
                                                                       title="Excluir">
                                                                        <i class="fas fa-trash"></i>
                                                                    </a>
                                                                </div>
                                                            </td>
                                                            <?php endif; ?>
                                                        </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>

    <script>
        // Ativar abas ao carregar a página
        document.addEventListener('DOMContentLoaded', function() {
            var triggerTabList = [].slice.call(document.querySelectorAll('#myTab button'))
            triggerTabList.forEach(function (triggerEl) {
                var tabTrigger = new bootstrap.Tab(triggerEl)
                triggerEl.addEventListener('click', function (event) {
                    event.preventDefault()
                    tabTrigger.show()
                })
            })
        });
    </script>
</body>
</html>