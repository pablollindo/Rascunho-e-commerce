<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se é admin ou funcionário com permissão
if (!isFuncionario()) {
    $_SESSION['erro'] = "Acesso restrito à funcionários.";
    header("Location: ../indexx.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$pedido_id = intval($_GET['id'] ?? 0);
$status_filter = $_GET['status'] ?? 'todos';

try {
    $pdo = conectarBanco();
    
    switch ($action) {
        case 'view':
            if ($pedido_id > 0) {
                // Buscar pedido e itens
                $stmt = $pdo->prepare("SELECT p.*, u.nome as cliente_nome, u.email as cliente_email 
                                      FROM pedidos p 
                                      JOIN usuarios u ON p.cliente_id = u.id 
                                      WHERE p.id = ?");
                $stmt->execute([$pedido_id]);
                $pedido = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$pedido) {
                    $_SESSION['erro'] = "Pedido não encontrado.";
                    header("Location: admin_pedidos.php");
                    exit;
                }
                
                // Buscar itens do pedido
                $stmt = $pdo->prepare("SELECT ip.*, p.nome as produto_nome, p.imagem as produto_imagem
                                      FROM itens_pedido ip
                                      JOIN produtos p ON ip.produto_id = p.id
                                      WHERE ip.pedido_id = ?");
                $stmt->execute([$pedido_id]);
                $itens_pedido = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            break;
            
        case 'update_status':
            if ($pedido_id > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $novo_status = $_POST['status'];
                $stmt = $pdo->prepare("UPDATE pedidos SET status = ? WHERE id = ?");
                $stmt->execute([$novo_status, $pedido_id]);
                
                $_SESSION['sucesso'] = "Status do pedido atualizado com sucesso!";
                header("Location: admin_pedidos.php?action=view&id=" . $pedido_id);
                exit;
            }
            break;
    }
    
    // Buscar pedidos com filtro
    $sql_pedidos = "SELECT p.*, u.nome as cliente_nome, u.email as cliente_email 
                   FROM pedidos p 
                   JOIN usuarios u ON p.cliente_id = u.id";
    
    $params = [];
    if ($status_filter !== 'todos') {
        $sql_pedidos .= " WHERE p.status = ?";
        $params[] = $status_filter;
    }
    
    $sql_pedidos .= " ORDER BY p.data_pedido DESC";
    
    $stmt = $pdo->prepare($sql_pedidos);
    $stmt->execute($params);
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar pedidos: " . $e->getMessage();
    $pedidos = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Pedidos - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container { background: #f8f9fa; min-height: 100vh; }
        .admin-sidebar { background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%); min-height: calc(100vh - 200px); color: white; }
        .admin-sidebar .nav-link { color: white; padding: 12px 20px; margin: 2px 0; border-radius: 5px; transition: all 0.3s; }
        .admin-sidebar .nav-link:hover { background: rgba(255,255,255,0.1); transform: translateX(5px); }
        .admin-sidebar .nav-link.active { background: rgba(255,255,255,0.2); font-weight: bold; border-left: 4px solid #ffc107; }
        .admin-content { background: white; min-height: calc(100vh - 200px); padding: 20px; }
        .content-header { background: white; border-bottom: 1px solid #dee2e6; padding: 20px 0; margin-bottom: 20px; }
    </style>
</head>
<body>
    <?php 
    $tituloPagina = "Gerenciar Pedidos - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>Dashboard
                        </a>
                        <?php if (isAdmin()): ?>
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>Produtos
                        </a>
                        <?php endif; ?>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>Estoque
                        </a>
                        <?php if (isAdmin()): ?>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>Categorias & Marcas
                        </a>
                        <?php endif; ?>
                        <a href="admin_pedidos.php" class="nav-link active">
                            <i class="fas fa-shopping-cart me-2"></i>Pedidos
                        </a>
                        <?php if (isAdmin()): ?>
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>Clientes
                        </a>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>Funcionários
                        </a>
                        <?php endif; ?>
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>Suporte
                        </a>
                        <?php if (isAdmin()): ?>
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>Relatórios
                        </a>
                        <?php endif; ?>
                        <hr class="bg-light my-3">
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-shopping-cart me-2"></i>
                                Gerenciar Pedidos
                            </h1>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <?php if ($action === 'view' && isset($pedido)): ?>
                        <!-- Visualização do Pedido -->
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">
                                        <i class="fas fa-receipt me-2"></i>
                                        Pedido #<?= str_pad($pedido['id'], 6, '0', STR_PAD_LEFT) ?>
                                    </h5>
                                    <a href="admin_pedidos.php" class="btn btn-sm btn-light">
                                        <i class="fas fa-arrow-left me-1"></i>Voltar
                                    </a>
                                </div>
                            </div>
                            <div class="card-body">
                                <!-- Informações do Pedido -->
                                <div class="row mb-4">
                                    <div class="col-md-4">
                                        <strong>Cliente:</strong><br>
                                        <?= htmlspecialchars($pedido['cliente_nome']) ?><br>
                                        <small class="text-muted"><?= htmlspecialchars($pedido['cliente_email']) ?></small>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Data do Pedido:</strong><br>
                                        <?= date('d/m/Y H:i', strtotime($pedido['data_pedido'])) ?>
                                    </div>
                                    <div class="col-md-4">
                                        <strong>Total:</strong><br>
                                        <span class="h5 text-success">R$ <?= number_format($pedido['total'], 2, ',', '.') ?></span>
                                    </div>
                                </div>
                                
                                <!-- Status do Pedido -->
                                <div class="row mb-4">
                                    <div class="col-12">
                                        <form method="POST" action="admin_pedidos.php?action=update_status&id=<?= $pedido['id'] ?>">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <label class="form-label"><strong>Status do Pedido:</strong></label>
                                                    <div class="input-group">
                                                        <select name="status" class="form-select">
                                                            <option value="pendente" <?= $pedido['status'] == 'pendente' ? 'selected' : '' ?>>Pendente</option>
                                                            <option value="pago" <?= $pedido['status'] == 'pago' ? 'selected' : '' ?>>Pago</option>
                                                            <option value="processando" <?= $pedido['status'] == 'processando' ? 'selected' : '' ?>>Processando</option>
                                                            <option value="enviado" <?= $pedido['status'] == 'enviado' ? 'selected' : '' ?>>Enviado</option>
                                                            <option value="entregue" <?= $pedido['status'] == 'entregue' ? 'selected' : '' ?>>Entregue</option>
                                                            <option value="cancelado" <?= $pedido['status'] == 'cancelado' ? 'selected' : '' ?>>Cancelado</option>
                                                        </select>
                                                        <button type="submit" class="btn btn-primary">Atualizar</button>
                                                    </div>
                                                </div>
                                                <div class="col-md-6">
                                                    <label class="form-label"><strong>Status Atual:</strong></label>
                                                    <div>
                                                        <span class="badge bg-<?= getStatusBadgeColor($pedido['status']) ?> fs-6">
                                                            <?= ucfirst($pedido['status']) ?>
                                                        </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                
                                <!-- Itens do Pedido -->
                                <h5 class="mb-3">Itens do Pedido</h5>
                                <div class="table-responsive">
                                    <table class="table table-striped">
                                        <thead>
                                            <tr>
                                                <th>Produto</th>
                                                <th>Quantidade</th>
                                                <th>Preço Unitário</th>
                                                <th>Subtotal</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($itens_pedido as $item): ?>
                                            <tr>
                                                <td><?= htmlspecialchars($item['produto_nome']) ?></td>
                                                <td><?= $item['quantidade'] ?></td>
                                                <td>R$ <?= number_format($item['preco_unitario'], 2, ',', '.') ?></td>
                                                <td>R$ <?= number_format($item['quantidade'] * $item['preco_unitario'], 2, ',', '.') ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <td colspan="3" class="text-end"><strong>Total:</strong></td>
                                                <td><strong>R$ <?= number_format($pedido['total'], 2, ',', '.') ?></strong></td>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Filtros -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="d-flex flex-wrap gap-2">
                                    <a href="admin_pedidos.php?status=todos" class="btn btn-sm btn-outline-secondary <?= $status_filter === 'todos' ? 'active' : '' ?>">
                                        Todos (<?= count($pedidos) ?>)
                                    </a>
                                    <a href="admin_pedidos.php?status=pendente" class="btn btn-sm btn-outline-warning <?= $status_filter === 'pendente' ? 'active' : '' ?>">
                                        Pendentes (<?= count(array_filter($pedidos, function($p) { return $p['status'] == 'pendente'; })) ?>)
                                    </a>
                                    <a href="admin_pedidos.php?status=pago" class="btn btn-sm btn-outline-info <?= $status_filter === 'pago' ? 'active' : '' ?>">
                                        Pagos (<?= count(array_filter($pedidos, function($p) { return $p['status'] == 'pago'; })) ?>)
                                    </a>
                                    <a href="admin_pedidos.php?status=processando" class="btn btn-sm btn-outline-primary <?= $status_filter === 'processando' ? 'active' : '' ?>">
                                        Processando (<?= count(array_filter($pedidos, function($p) { return $p['status'] == 'processando'; })) ?>)
                                    </a>
                                    <a href="admin_pedidos.php?status=enviado" class="btn btn-sm btn-outline-success <?= $status_filter === 'enviado' ? 'active' : '' ?>">
                                        Enviados (<?= count(array_filter($pedidos, function($p) { return $p['status'] == 'enviado'; })) ?>)
                                    </a>
                                    <a href="admin_pedidos.php?status=entregue" class="btn btn-sm btn-outline-success <?= $status_filter === 'entregue' ? 'active' : '' ?>">
                                        Entregues (<?= count(array_filter($pedidos, function($p) { return $p['status'] == 'entregue'; })) ?>)
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Lista de Pedidos -->
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Cliente</th>
                                                <th>Data</th>
                                                <th>Total</th>
                                                <th>Status</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($pedidos)): ?>
                                                <tr>
                                                    <td colspan="6" class="text-center py-4 text-muted">
                                                        <i class="fas fa-shopping-cart fa-2x mb-3"></i><br>
                                                        Nenhum pedido encontrado.
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($pedidos as $ped): ?>
                                                <tr>
                                                    <td>#<?= str_pad($ped['id'], 6, '0', STR_PAD_LEFT) ?></td>
                                                    <td>
                                                        <?= htmlspecialchars($ped['cliente_nome']) ?>
                                                        <br>
                                                        <small class="text-muted"><?= htmlspecialchars($ped['cliente_email']) ?></small>
                                                    </td>
                                                    <td>
                                                        <?= date('d/m/Y', strtotime($ped['data_pedido'])) ?>
                                                        <br>
                                                        <small class="text-muted"><?= date('H:i', strtotime($ped['data_pedido'])) ?></small>
                                                    </td>
                                                    <td>
                                                        <strong>R$ <?= number_format($ped['total'], 2, ',', '.') ?></strong>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= getStatusBadgeColor($ped['status']) ?>">
                                                            <?= ucfirst($ped['status']) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="admin_pedidos.php?action=view&id=<?= $ped['id'] ?>" class="btn btn-outline-primary" title="Visualizar">
                                                                <i class="fas fa-eye"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <?php include '../includes/rodape.php'; ?>
</body>
</html>