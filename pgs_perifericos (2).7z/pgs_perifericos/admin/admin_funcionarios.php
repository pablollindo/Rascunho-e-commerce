<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se pode gerenciar funcionários
if (!podeGerenciarFuncionarios()) {
    $_SESSION['erro'] = "Acesso restrito.";
    header("Location: ../indexx.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$funcionario_id = intval($_GET['id'] ?? 0);

try {
    $pdo = conectarBanco();
    
    switch ($action) {
        case 'add':
        case 'edit':
            $funcionario = null;
            if ($action === 'edit' && $funcionario_id > 0) {
                $stmt = $pdo->prepare("SELECT f.*, u.email, u.data_cadastro 
                                     FROM funcionarios f 
                                     JOIN usuarios u ON f.usuario_id = u.id 
                                     WHERE f.id = ?");
                $stmt->execute([$funcionario_id]);
                $funcionario = $stmt->fetch(PDO::FETCH_ASSOC);
            }
            break;
            
        case 'delete':
            if ($funcionario_id > 0 && podeGerenciarFuncionarios()) {
                $stmt = $pdo->prepare("SELECT usuario_id FROM funcionarios WHERE id = ?");
                $stmt->execute([$funcionario_id]);
                $result = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if ($result) {
                    $stmt = $pdo->prepare("UPDATE usuarios SET ativo = 0 WHERE id = ?");
                    $stmt->execute([$result['usuario_id']]);
                    $_SESSION['sucesso'] = "Funcionário desativado com sucesso!";
                }
            } else {
                $_SESSION['erro'] = "Acesso negado para exclusão.";
            }
            header("Location: admin_funcionarios.php");
            exit;
            
        case 'save':
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {
                $dados = [
                    'nome' => trim($_POST['nome']),
                    'email' => trim($_POST['email']),
                    'cpf' => trim($_POST['cpf']),
                    'telefone' => trim($_POST['telefone']),
                    'data_nascimento' => $_POST['data_nascimento'],
                    'cargo' => $_POST['cargo'],
                    'departamento' => $_POST['departamento'],
                    'data_admissao' => $_POST['data_admissao'],
                    'matricula' => trim($_POST['matricula'])
                ];
                
                if (empty($dados['nome']) || empty($dados['email']) || empty($dados['cargo'])) {
                    $_SESSION['erro'] = "Nome, email e cargo são obrigatórios.";
                    header("Location: admin_funcionarios.php?action=" . ($_POST['id'] ? 'edit&id=' . $_POST['id'] : 'add'));
                    exit;
                }
                
                if ($_POST['id']) {
                    // Edição
                    $stmt = $pdo->prepare("UPDATE funcionarios SET nome = ?, cpf = ?, telefone = ?, data_nascimento = ?, cargo = ?, departamento = ?, data_admissao = ?, matricula = ? WHERE id = ?");
                    $dados[] = $_POST['id'];
                    $stmt->execute(array_values($dados));
                    
                    // Atualizar email na tabela usuarios
                    $stmt = $pdo->prepare("UPDATE usuarios SET email = ? WHERE id = (SELECT usuario_id FROM funcionarios WHERE id = ?)");
                    $stmt->execute([$dados['email'], $_POST['id']]);
                    
                    $_SESSION['sucesso'] = "Funcionário atualizado com sucesso!";
                } else {
                    // Inserção - criar usuário primeiro
                    $senha_hash = password_hash('123456', PASSWORD_DEFAULT); // senha padrão
                    
                    $pdo->beginTransaction();
                    
                    try {
                        // Inserir na tabela usuarios
                        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, email, senha, tipo, cpf, telefone, data_nascimento) VALUES (?, ?, ?, 'funcionario', ?, ?, ?)");
                        $stmt->execute([$dados['nome'], $dados['email'], $senha_hash, $dados['cpf'], $dados['telefone'], $dados['data_nascimento']]);
                        $usuario_id = $pdo->lastInsertId();
                        
                        // Inserir na tabela funcionarios
                        $stmt = $pdo->prepare("INSERT INTO funcionarios (usuario_id, nome, email, cpf, telefone, data_nascimento, cargo, departamento, data_admissao, matricula) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
                        $stmt->execute([$usuario_id, $dados['nome'], $dados['email'], $dados['cpf'], $dados['telefone'], $dados['data_nascimento'], $dados['cargo'], $dados['departamento'], $dados['data_admissao'], $dados['matricula']]);
                        
                        $pdo->commit();
                        $_SESSION['sucesso'] = "Funcionário cadastrado com sucesso! Senha padrão: 123456";
                    } catch (Exception $e) {
                        $pdo->rollBack();
                        throw $e;
                    }
                }
                
                header("Location: admin_funcionarios.php");
                exit;
            }
            break;
    }
    
    // Buscar funcionários
    $sql_funcionarios = "SELECT f.*, u.ativo 
                        FROM funcionarios f 
                        JOIN usuarios u ON f.usuario_id = u.id 
                        ORDER BY f.data_criacao DESC";
    $funcionarios = $pdo->query($sql_funcionarios)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro no banco de dados: " . $e->getMessage();
    $funcionarios = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Funcionários - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <?php 
    $tituloPagina = "Gerenciar Funcionários - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            Dashboard
                        </a>
                        
                        <?php if (podeGerenciarProdutos()): ?>
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>
                            Produtos
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarEstoque()): ?>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>
                            Estoque
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeGerenciarCategorias()): ?>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>
                            Categorias & Marcas
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos
                        </a>
                        
                        <?php if (podeGerenciarUsuarios()): ?>
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>
                            Clientes
                        </a>
                        <?php endif; ?>
                        
                        <?php if (podeVerFuncionarios()): ?>
                        <a href="admin_funcionarios.php" class="nav-link active">
                            <i class="fas fa-user-tie me-2"></i>
                            Funcionários
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>
                            Suporte
                        </a>
                        
                        <?php if (podeVerRelatorios()): ?>
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>
                            Relatórios
                        </a>
                        <?php endif; ?>
                        
                        <hr class="bg-light my-3">
                        
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>
                            Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-user-tie me-2"></i>
                                Gerenciar Funcionários
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <?php if (podeGerenciarFuncionarios()): ?>
                                <a href="admin_funcionarios.php?action=add" class="btn btn-success">
                                    <i class="fas fa-plus me-2"></i>
                                    Novo Funcionário
                                </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <?php if (($action === 'add' || $action === 'edit') && podeGerenciarFuncionarios()): ?>
                        <!-- Formulário de Funcionário -->
                        <div class="card">
                            <div class="card-header bg-success text-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-<?= $action === 'add' ? 'plus' : 'edit' ?> me-2"></i>
                                    <?= $action === 'add' ? 'Adicionar' : 'Editar' ?> Funcionário
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="admin_funcionarios.php?action=save">
                                    <input type="hidden" name="id" value="<?= $funcionario['id'] ?? '' ?>">
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="nome" class="form-label">Nome Completo *</label>
                                            <input type="text" class="form-control" id="nome" name="nome" 
                                                   value="<?= htmlspecialchars($funcionario['nome'] ?? '') ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label">Email *</label>
                                            <input type="email" class="form-control" id="email" name="email" 
                                                   value="<?= htmlspecialchars($funcionario['email'] ?? '') ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label for="cpf" class="form-label">CPF</label>
                                            <input type="text" class="form-control" id="cpf" name="cpf" 
                                                   value="<?= htmlspecialchars($funcionario['cpf'] ?? '') ?>">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="telefone" class="form-label">Telefone</label>
                                            <input type="text" class="form-control" id="telefone" name="telefone" 
                                                   value="<?= htmlspecialchars($funcionario['telefone'] ?? '') ?>">
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="data_nascimento" class="form-label">Data de Nascimento</label>
                                            <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" 
                                                   value="<?= $funcionario['data_nascimento'] ?? '' ?>">
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="cargo" class="form-label">Cargo *</label>
                                            <select class="form-select" id="cargo" name="cargo" required>
                                                <option value="">Selecione...</option>
                                                <option value="administrador" <?= ($funcionario['cargo'] ?? '') == 'administrador' ? 'selected' : '' ?>>Administrador</option>
                                                <option value="estoquista" <?= ($funcionario['cargo'] ?? '') == 'estoquista' ? 'selected' : '' ?>>Estoquista</option>
                                                <option value="atendente" <?= ($funcionario['cargo'] ?? '') == 'atendente' ? 'selected' : '' ?>>Atendente</option>
                                                <option value="vendedor" <?= ($funcionario['cargo'] ?? '') == 'vendedor' ? 'selected' : '' ?>>Vendedor</option>
                                                <option value="gerente" <?= ($funcionario['cargo'] ?? '') == 'gerente' ? 'selected' : '' ?>>Gerente</option>
                                            </select>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="departamento" class="form-label">Departamento *</label>
                                            <input type="text" class="form-control" id="departamento" name="departamento" 
                                                   value="<?= htmlspecialchars($funcionario['departamento'] ?? '') ?>" required>
                                        </div>
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="data_admissao" class="form-label">Data de Admissão *</label>
                                            <input type="date" class="form-control" id="data_admissao" name="data_admissao" 
                                                   value="<?= $funcionario['data_admissao'] ?? date('Y-m-d') ?>" required>
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="matricula" class="form-label">Matrícula</label>
                                            <input type="text" class="form-control" id="matricula" name="matricula" 
                                                   value="<?= htmlspecialchars($funcionario['matricula'] ?? '') ?>">
                                        </div>
                                    </div>
                                    
                                    <?php if ($action === 'add'): ?>
                                        <div class="alert alert-info">
                                            <i class="fas fa-info-circle me-2"></i>
                                            Senha padrão: <strong>123456</strong> - O funcionário poderá alterar após o primeiro login.
                                        </div>
                                    <?php endif; ?>
                                    
                                    <div class="d-flex justify-content-between">
                                        <a href="admin_funcionarios.php" class="btn btn-secondary">
                                            <i class="fas fa-arrow-left me-2"></i>
                                            Cancelar
                                        </a>
                                        <button type="submit" class="btn btn-success">
                                            <i class="fas fa-save me-2"></i>
                                            <?= $action === 'add' ? 'Cadastrar' : 'Atualizar' ?> Funcionário
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Lista de Funcionários -->
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Funcionário</th>
                                                <th>Cargo</th>
                                                <th>Departamento</th>
                                                <th>Admissão</th>
                                                <th>Matrícula</th>
                                                <th>Status</th>
                                                <?php if (podeGerenciarFuncionarios()): ?>
                                                <th>Ações</th>
                                                <?php endif; ?>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($funcionarios)): ?>
                                                <tr>
                                                    <td colspan="<?= podeGerenciarFuncionarios() ? '8' : '7' ?>" class="text-center py-4 text-muted">
                                                        <i class="fas fa-user-tie fa-2x mb-3"></i><br>
                                                        Nenhum funcionário cadastrado.
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($funcionarios as $func): ?>
                                                <tr>
                                                    <td>#<?= $func['id'] ?></td>
                                                    <td>
                                                        <strong><?= htmlspecialchars($func['nome']) ?></strong>
                                                        <br>
                                                        <small class="text-muted"><?= htmlspecialchars($func['email']) ?></small>
                                                        <?php if ($func['cpf']): ?>
                                                            <br>
                                                            <small class="text-muted">CPF: <?= $func['cpf'] ?></small>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= getCargoBadgeColor($func['cargo']) ?>">
                                                            <?= ucfirst($func['cargo']) ?>
                                                        </span>
                                                    </td>
                                                    <td><?= htmlspecialchars($func['departamento']) ?></td>
                                                    <td>
                                                        <?= date('d/m/Y', strtotime($func['data_admissao'])) ?>
                                                        <br>
                                                        <small class="text-muted">
                                                            <?= calcularTempoAdmissao($func['data_admissao']) ?>
                                                        </small>
                                                    </td>
                                                    <td><?= $func['matricula'] ?: 'N/A' ?></td>
                                                    <td>
                                                        <span class="badge bg-<?= $func['ativo'] ? 'success' : 'secondary' ?>">
                                                            <?= $func['ativo'] ? 'Ativo' : 'Inativo' ?>
                                                        </span>
                                                    </td>
                                                    <?php if (podeGerenciarFuncionarios()): ?>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="admin_funcionarios.php?action=edit&id=<?= $func['id'] ?>" 
                                                               class="btn btn-outline-primary" title="Editar">
                                                                <i class="fas fa-edit"></i>
                                                            </a>
                                                            <a href="admin_funcionarios.php?action=delete&id=<?= $func['id'] ?>" 
                                                               class="btn btn-outline-danger" 
                                                               onclick="return confirm('Tem certeza que deseja desativar este funcionário?')"
                                                               title="Desativar">
                                                                <i class="fas fa-user-slash"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                    <?php endif; ?>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Estatísticas -->
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="card text-white bg-primary">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Total Funcionários</h6>
                                        <p class="card-text h4"><?= count($funcionarios) ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-success">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Ativos</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($funcionarios, function($f) { return $f['ativo']; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-info">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Administradores</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($funcionarios, function($f) { return $f['cargo'] == 'administrador'; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-warning">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Estoquistas</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($funcionarios, function($f) { return $f['cargo'] == 'estoquista'; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>