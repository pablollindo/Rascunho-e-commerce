<?php
require_once 'includes/cabecalho.php';

// Buscar produtos em destaque do banco
try {
    $pdo = conectarBanco();
    
    // Buscar produtos em destaque
    $sql_destaques = "SELECT p.*, m.nome as marca_nome 
                     FROM produtos p 
                     LEFT JOIN marcas m ON p.marca_id = m.id 
                     WHERE p.ativo = 1 AND p.em_destaque = 1 
                     ORDER BY p.data_cadastro DESC 
                     LIMIT 4";
    $stmt = $pdo->prepare($sql_destaques);
    $stmt->execute();
    $produtos_destaque = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar produtos em promoção para ofertas relâmpago
    $sql_ofertas = "SELECT p.*, m.nome as marca_nome 
                   FROM produtos p 
                   LEFT JOIN marcas m ON p.marca_id = m.id 
                   WHERE p.ativo = 1 AND p.em_promocao = 1 
                   ORDER BY p.data_cadastro DESC 
                   LIMIT 3";
    $stmt = $pdo->prepare($sql_ofertas);
    $stmt->execute();
    $produtos_ofertas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $produtos_destaque = [];
    $produtos_ofertas = [];
    error_log("Erro ao carregar produtos: " . $e->getMessage());
}
?>

<style>
    .product-card {
        transition: transform 0.3s, box-shadow 0.3s;
        border: 1px solid #dee2e6;
    }
    .product-card:hover {
        transform: translateY(-5px);
        box-shadow: 0 8px 25px rgba(0,0,0,0.15);
    }
    .price-original {
        text-decoration: line-through;
        color: #6c757d;
        font-size: 0.9em;
    }
    .price-promotional {
        color: #dc3545;
        font-weight: bold;
        font-size: 1.2em;
    }
    .badge-promocao {
        position: absolute;
        top: 10px;
        left: 10px;
        z-index: 1;
    }
    .wishlist-btn {
        position: absolute;
        top: 10px;
        right: 10px;
        z-index: 1;
    }
    .category-card {
        transition: transform 0.3s;
    }
    .category-card:hover {
        transform: translateY(-3px);
    }
    .offer-card {
        transition: transform 0.3s;
    }
    .offer-card:hover {
        transform: scale(1.02);
    }
    .alert-carrinho {
        position: fixed;
        top: 100px;
        right: 20px;
        z-index: 9999;
        min-width: 300px;
    }
</style>

<!-- Banner Principal -->
<section class="bg-primary text-white py-5">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-6">
                <h1 class="display-4 fw-bold">Os Melhores Periféricos Gamers</h1>
                <p class="lead">Encontre teclados, mouses, headsets e muito mais com os melhores preços do mercado!</p>
                <div class="mt-3">
                    <a href="produtos.php" class="btn btn-warning btn-lg me-3">
                        <i class="fas fa-shopping-bag me-2"></i>
                        Ver Todos os Produtos
                    </a>
                    <?php if (usuarioEstaLogado() && $_SESSION['usuario_tipo'] === 'cliente'): ?>
                        <a href="lista_desejos.php" class="btn btn-outline-light btn-lg">
                            <i class="fas fa-heart me-2"></i>
                            Minha Lista de Desejos
                        </a>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-6 text-center">
                <img src="imagens/banners/acessorios-gamers.jpg" alt="Periféricos Gamers" class="img-fluid rounded" style="max-height: 300px;">
            </div>
        </div>
    </div>
</section>

<!-- Seção Destaques -->
<section class="py-5">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="border-bottom pb-2">
                    <i class="fas fa-star text-warning me-2"></i>
                    Produtos em Destaque
                </h2>
            </div>
        </div>
        <div class="row">
            <?php if (empty($produtos_destaque)): ?>
                <div class="col-12 text-center">
                    <p class="text-muted">Nenhum produto em destaque no momento.</p>
                </div>
            <?php else: ?>
                <?php foreach ($produtos_destaque as $produto): ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100 product-card">
                        <div class="position-relative">
                            <?php if ($produto['em_promocao']): ?>
                                <span class="badge bg-danger badge-promocao">
                                    -<?= calcularDesconto($produto['preco'], $produto['preco_promocional']) ?>%
                                </span>
                            <?php endif; ?>
                            
                            <!-- FORM PARA LISTA DE DESEJOS (SUBSTITUI O BOTÃO JavaScript) -->
                            <form method="GET" action="includes/processa_wishlist.php" class="d-inline">
                                <input type="hidden" name="action" value="add">
                                <input type="hidden" name="product_id" value="<?= $produto['id'] ?>">
                                <input type="hidden" name="redirect" value="indexx">
                                <button type="submit" class="btn btn-outline-danger btn-sm wishlist-btn" title="Adicionar à lista de desejos">
                                    <i class="far fa-heart"></i>
                                </button>
                            </form>
                            
                            <img src="assets/imagens/produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                                 class="card-img-top" 
                                 alt="<?= htmlspecialchars($produto['nome']) ?>"
                                 style="height: 200px; object-fit: cover; background: #f8f9fa;"
                                 onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                            </img>
                        </div>
                        
                        <div class="card-body d-flex flex-column">
                            <div class="mb-2">
                                <span class="badge bg-secondary"><?= htmlspecialchars($produto['marca_nome']) ?></span>
                            </div>
                            
                            <h6 class="card-title"><?= htmlspecialchars($produto['nome']) ?></h6>
                            
                            <p class="card-text text-muted small flex-grow-1">
                                <?= truncateText($produto['descricao'] ?? 'Descrição não disponível', 80) ?>
                            </p>
                            
                            <div class="mt-auto">
                                <!-- Preço -->
                                <div class="mb-2">
                                    <?php if ($produto['em_promocao'] && $produto['preco_promocional']): ?>
                                        <span class="price-promotional">
                                            R$ <?= number_format($produto['preco_promocional'], 2, ',', '.') ?>
                                        </span>
                                        <br>
                                        <span class="price-original">
                                            R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                        </span>
                                    <?php else: ?>
                                        <span class="h6 text-primary">
                                            R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                        </span>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Botões -->
                                <div class="d-grid gap-2">
                                    <a href="produto.php?id=<?= $produto['id'] ?>" class="btn btn-outline-primary btn-sm">
                                        <i class="fas fa-eye me-1"></i>
                                        Ver Detalhes
                                    </a>
                                    <?php if ($produto['estoque'] > 0): ?>
                                        <form method="GET" action="includes/processa_carrinho.php" class="d-inline">
                                            <input type="hidden" name="action" value="add">
                                            <input type="hidden" name="product_id" value="<?= $produto['id'] ?>">
                                            <input type="hidden" name="quantity" value="1">
                                            <button type="submit" class="btn btn-primary btn-sm w-100">
                                                <i class="fas fa-cart-plus me-1"></i>
                                                Adicionar
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>
                                            <i class="fas fa-bell me-1"></i>
                                            Avise-me
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Banner Promocional -->
<section class="bg-light py-4">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-md-8">
                <h4 class="mb-1">Frete Grátis para Todo o Brasil</h4>
                <p class="mb-0 text-muted">Em compras acima de R$ 299,90</p>
            </div>
            <div class="col-md-4 text-end">
                <a href="produtos.php" class="btn btn-primary">Aproveitar Oferta</a>
            </div>
        </div>
    </div>
</section>

<!-- Seção Categorias -->
<section class="py-5 bg-light">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="border-bottom pb-2">
                    <i class="fas fa-th-large text-primary me-2"></i>
                    Categorias em Destaque
                </h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3 mb-3">
                <a href="produtos.php?categoria=1" class="text-decoration-none">
                    <div class="card text-center category-card">
                        <div class="card-body">
                            <i class="fas fa-keyboard fa-3x text-primary mb-3"></i>
                            <h5 class="card-title">Teclados</h5>
                            <p class="text-muted small">Mecânicos e Gaming</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 mb-3">
                <a href="produtos.php?categoria=2" class="text-decoration-none">
                    <div class="card text-center category-card">
                        <div class="card-body">
                            <i class="fas fa-mouse fa-3x text-success mb-3"></i>
                            <h5 class="card-title">Mouses</h5>
                            <p class="text-muted small">Gamer e Profissionais</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 mb-3">
                <a href="produtos.php?categoria=3" class="text-decoration-none">
                    <div class="card text-center category-card">
                        <div class="card-body">
                            <i class="fas fa-headphones fa-3x text-warning mb-3"></i>
                            <h5 class="card-title">Headsets</h5>
                            <p class="text-muted small">Áudio Profissional</p>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-md-3 mb-3">
                <a href="produtos.php?categoria=4" class="text-decoration-none">
                    <div class="card text-center category-card">
                        <div class="card-body">
                            <i class="fas fa-desktop fa-3x text-info mb-3"></i>
                            <h5 class="card-title">Monitores</h5>
                            <p class="text-muted small">Gaming e Trabalho</p>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</section>

<!-- Seção Ofertas -->
<section class="py-5">
    <div class="container">
        <div class="row mb-4">
            <div class="col-12">
                <h2 class="border-bottom pb-2">
                    <i class="fas fa-bolt text-danger me-2"></i>
                    Ofertas Relâmpago
                </h2>
            </div>
        </div>
        <div class="row">
            <?php if (empty($produtos_ofertas)): ?>
                <div class="col-12 text-center">
                    <p class="text-muted">Nenhuma oferta relâmpago no momento.</p>
                </div>
            <?php else: ?>
                <?php 
                $cores = ['danger', 'warning', 'success'];
                $i = 0;
                foreach ($produtos_ofertas as $produto): 
                    $cor = $cores[$i % count($cores)];
                    $i++;
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card offer-card border-<?= $cor ?>">
                        <div class="card-header bg-<?= $cor ?> text-white text-center">
                            <i class="fas fa-clock me-1"></i>
                            Oferta por Tempo Limitado
                        </div>
                        <div class="card-body text-center">
                            <div class="position-relative">
                                <img src="assets/imagens/produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                                     alt="<?= htmlspecialchars($produto['nome']) ?>" 
                                     class="img-fluid mb-3" 
                                     style="height: 150px; object-fit: cover;"
                                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                                
                                <!-- FORM PARA LISTA DE DESEJOS NAS OFERTAS -->
                                <form method="GET" action="includes/processa_wishlist.php" class="d-inline">
                                    <input type="hidden" name="action" value="add">
                                    <input type="hidden" name="product_id" value="<?= $produto['id'] ?>">
                                    <input type="hidden" name="redirect" value="indexx">
                                    <button type="submit" class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2" title="Adicionar à lista de desejos">
                                        <i class="far fa-heart"></i>
                                    </button>
                                </form>
                            </div>
                            <h5 class="card-title"><?= htmlspecialchars($produto['nome']) ?></h5>
                            <div class="price-section">
                                <?php if ($produto['em_promocao'] && $produto['preco_promocional']): ?>
                                    <span class="h4 text-danger">R$ <?= number_format($produto['preco_promocional'], 2, ',', '.') ?></span>
                                    <small class="text-muted d-block text-decoration-line-through">
                                        R$ <?= number_format($produto['preco'], 2, ',', '.') ?>
                                    </small>
                                <?php else: ?>
                                    <span class="h4 text-danger">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></span>
                                <?php endif; ?>
                            </div>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-<?= $cor ?>" style="width: <?= rand(30, 80) ?>%">
                                    <?= rand(30, 80) ?>% vendido
                                </div>
                            </div>
                            <form method="GET" action="includes/processa_carrinho.php" class="d-inline w-100">
                                <input type="hidden" name="action" value="add">
                                <input type="hidden" name="product_id" value="<?= $produto['id'] ?>">
                                <input type="hidden" name="quantity" value="1">
                                <button type="submit" class="btn btn-<?= $cor ?> w-100">
                                    <i class="fas fa-bolt me-1"></i>
                                    Comprar Agora
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            <?php endif; ?>
        </div>
    </div>
</section>

<!-- Footer -->
<?php include 'includes/rodape.php'; ?>

<script>
    // Função para mostrar toast messages
    function showToast(message, type = 'info') {
        // Criar elemento toast
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        // Adicionar ao container de toasts
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.appendChild(toast);
        
        // Mostrar toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remover após esconder
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }

    // Auto-remover alerta do carrinho após 3 segundos
    const alertCarrinho = document.querySelector('.alert-carrinho');
    if (alertCarrinho) {
        setTimeout(() => {
            const bsAlert = new bootstrap.Alert(alertCarrinho);
            bsAlert.close();
        }, 3000);
    }
</script>

<?php
// Funções auxiliares
function getCategoriaIcon($categoria) {
    $icons = [
        'Teclados' => 'keyboard',
        'Mouses' => 'mouse',
        'Headsets' => 'headphones',
        'Monitores' => 'desktop',
        'Mousepads' => 'mouse-pointer',
        'Webcams' => 'video',
        'Microfones' => 'microphone'
    ];
    return $icons[$categoria] ?? 'box';
}

function calcularDesconto($precoOriginal, $precoPromocional) {
    if (!$precoPromocional || $precoPromocional >= $precoOriginal) {
        return 0;
    }
    $desconto = (($precoOriginal - $precoPromocional) / $precoOriginal) * 100;
    return round($desconto);
}