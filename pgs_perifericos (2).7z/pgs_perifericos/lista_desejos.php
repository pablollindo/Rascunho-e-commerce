<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para acessar sua lista de desejos.";
    header('Location: login.php');
    exit;
}

// Buscar produtos da lista de desejos do usuário
$usuario_id = $_SESSION['usuario_id'];
$wishlist_query = "
    SELECT p.*, m.nome as marca_nome, c.nome as categoria_nome, w.data_adicao 
    FROM wishlist w 
    JOIN produtos p ON w.produto_id = p.id 
    LEFT JOIN marcas m ON p.marca_id = m.id 
    LEFT JOIN categorias c ON p.categoria_id = c.id 
    WHERE w.usuario_id = ? AND p.ativo = 1
    ORDER BY w.data_adicao DESC
";

$stmt = $conn->prepare($wishlist_query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$wishlist_items = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();

// Contar itens na wishlist para o header
$total_wishlist = count($wishlist_items);

// Contar itens no carrinho para o header (MESMA LÓGICA DO CARRINHO)
$total_itens_carrinho = 0;
if (isset($_SESSION['carrinho']) && is_array($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $item) {
        $total_itens_carrinho += $item['quantidade'];
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Desejos - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/wishlist.css">
    <style>
        .wishlist-item-image {
            max-height: 120px;
            object-fit: cover;
            width: 100%;
        }
        .wishlist-item {
            transition: background-color 0.3s ease;
        }
        .wishlist-item:hover {
            background-color: #f8f9fa;
        }
        .empty-wishlist-icon {
            opacity: 0.5;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(10px); }
            to { opacity: 1; transform: translateY(0); }
        }
        .wishlist-item {
            animation: fadeIn 0.3s ease-out;
        }
        .stock-status .badge {
            font-size: 0.75rem;
        }
        .price-info .text-decoration-line-through {
            font-size: 0.8rem;
        }
        @media (max-width: 768px) {
            .wishlist-item .row {
                text-align: center;
            }
            .wishlist-item-image {
                max-height: 100px;
                margin: 0 auto;
            }
            .wishlist-item .btn-group {
                flex-direction: column;
                gap: 0.5rem;
            }
            .wishlist-item .btn {
                width: 100%;
            }
        }
        @media (max-width: 576px) {
            .card-header .d-flex {
                flex-direction: column;
                gap: 1rem;
                text-align: center;
            }
            .wishlist-item {
                padding: 1rem 0.5rem;
            }
            .wishlist-item .col-12 {
                margin-bottom: 0.5rem;
            }
        }
    </style>
</head>
<body>
    <?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho da Lista de Desejos - ESTILO SIMILAR AO CARRINHO -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-heart text-danger me-2"></i>
                        Minha Lista de Desejos
                    </h1>
                    <div class="breadcrumb-nav">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                                <li class="breadcrumb-item active">Lista de Desejos</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Mensagens do Sistema -->
                <?php mostrarMensagem(); ?>

                <?php if (empty($wishlist_items)): ?>
                    <!-- Lista de Desejos Vazia - ESTILO SIMILAR AO CARRINHO VAZIO -->
                    <div class="text-center py-5">
                        <div class="empty-wishlist-icon mb-4">
                            <i class="fas fa-heart-broken fa-5x text-muted"></i>
                        </div>
                        <h3 class="text-muted mb-3">Sua lista de desejos está vazia</h3>
                        <p class="text-muted mb-4">Adicione produtos que você ama à sua lista de desejos!</p>
                        <a href="produtos.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Explorar Produtos
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Lista de Desejos com Itens - ESTILO SIMILAR AO CARRINHO -->
                    <div class="card shadow-sm mb-4">
                        <div class="card-header bg-light d-flex justify-content-between align-items-center">
                            <h5 class="mb-0">
                                <i class="fas fa-gift me-2"></i>
                                Seus Produtos Desejados (<?php echo count($wishlist_items); ?>)
                            </h5>
                            <div class="d-flex gap-2">
                                <!-- CORREÇÃO: Forms para ações em massa -->
                                <form method="POST" action="includes/processa_wishlist.php" class="d-inline">
                                    <input type="hidden" name="action" value="add_all_to_cart">
                                    <input type="hidden" name="redirect" value="lista_desejos.php">
                                    <button type="submit" class="btn btn-outline-primary btn-sm"
                                            onclick="return confirm('Deseja adicionar todos os produtos disponíveis ao carrinho?')">
                                        <i class="fas fa-cart-plus me-1"></i>
                                        Adicionar Todos ao Carrinho
                                    </button>
                                </form>
                                
                                <form method="POST" action="includes/processa_wishlist.php" class="d-inline">
                                    <input type="hidden" name="action" value="clear">
                                    <input type="hidden" name="redirect" value="lista_desejos.php">
                                    <button type="submit" class="btn btn-outline-danger btn-sm"
                                            onclick="return confirm('Tem certeza que deseja limpar toda a sua lista de desejos?')">
                                        <i class="fas fa-trash me-1"></i>
                                        Limpar Lista
                                    </button>
                                </form>
                            </div>
                        </div>
                        <div class="card-body p-0">
                            <?php foreach ($wishlist_items as $item): 
                                $preco_final = $item['preco_promocional'] && $item['preco_promocional'] > 0 ? $item['preco_promocional'] : $item['preco'];
                                $imagem = !empty($item['imagem']) ? $item['imagem'] : 'assets/imagens/produtos/sem-imagem.jpg';
                                $tem_estoque = $item['estoque'] > 0;
                                $data_adicao = date('d/m/Y', strtotime($item['data_adicao']));
                            ?>
                            <div class="wishlist-item border-bottom">
                                <div class="row align-items-center p-3">
                                    <!-- Imagem do Produto -->
                                    <div class="col-12 col-sm-2 mb-3 mb-sm-0">
                                        <img src="<?php echo $imagem; ?>" 
                                             alt="<?php echo htmlspecialchars($item['nome']); ?>" 
                                             class="img-fluid rounded wishlist-item-image">
                                    </div>
                                    
                                    <!-- Informações do Produto -->
                                    <div class="col-12 col-sm-4 mb-3 mb-sm-0">
                                        <h6 class="mb-1"><?php echo htmlspecialchars($item['nome']); ?></h6>
                                        <p class="text-muted small mb-1">
                                            <span class="badge bg-secondary"><?php echo htmlspecialchars($item['marca_nome']); ?></span> • 
                                            <span class="badge bg-light text-dark"><?php echo htmlspecialchars($item['categoria_nome']); ?></span>
                                        </p>
                                        <div class="stock-status mb-2">
                                            <?php if ($tem_estoque): ?>
                                                <span class="badge bg-success">
                                                    <i class="fas fa-check me-1"></i>Em estoque
                                                </span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">
                                                    <i class="fas fa-exclamation-triangle me-1"></i>Fora de estoque
                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <small class="text-muted">
                                            <i class="far fa-clock me-1"></i>
                                            Adicionado em <?php echo $data_adicao; ?>
                                        </small>
                                    </div>
                                    
                                    <!-- Preço -->
                                    <div class="col-12 col-sm-2 mb-3 mb-sm-0 text-center">
                                        <div class="price-info">
                                            <div class="h6 mb-0 text-primary fw-bold">
                                                R$ <?php echo number_format($preco_final, 2, ',', '.'); ?>
                                            </div>
                                            <?php if ($item['preco_promocional'] && $item['preco_promocional'] > 0): ?>
                                                <small class="text-muted text-decoration-line-through">
                                                    R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?>
                                                </small>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    
                                    <!-- Ações -->
                                    <div class="col-12 col-sm-4">
                                        <div class="d-flex flex-column flex-sm-row gap-2 justify-content-center align-items-center">
                                            <?php if ($tem_estoque): ?>
                                                <!-- CORREÇÃO: Form para enviar via POST -->
                                                <form method="POST" action="includes/processa_wishlist.php" class="d-inline flex-fill">
                                                    <input type="hidden" name="action" value="move_to_cart">
                                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                    <input type="hidden" name="redirect" value="lista_desejos.php">
                                                    <button type="submit" class="btn btn-primary btn-sm w-100">
                                                        <i class="fas fa-cart-plus me-1"></i>
                                                        Adicionar ao Carrinho
                                                    </button>
                                                </form>
                                            <?php else: ?>
                                                <button class="btn btn-outline-secondary btn-sm flex-fill" disabled>
                                                    <i class="fas fa-bell me-1"></i>
                                                    Avise-me
                                                </button>
                                            <?php endif; ?>
                                            
                                            <div class="d-flex gap-1">
                                                <!-- CORREÇÃO: Form para remover -->
                                                <form method="POST" action="includes/processa_wishlist.php" class="d-inline">
                                                    <input type="hidden" name="action" value="remove">
                                                    <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                                    <input type="hidden" name="redirect" value="lista_desejos.php">
                                                    <button type="submit" class="btn btn-outline-danger btn-sm" 
                                                            onclick="return confirm('Deseja remover este produto da sua lista de desejos?')">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                </form>
                                                
                                                <a href="produto.php?id=<?php echo $item['id']; ?>" 
                                                   class="btn btn-outline-info btn-sm">
                                                    <i class="fas fa-eye"></i>
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <!-- Botão Continuar Comprando - ESTILO SIMILAR AO CARRINHO -->
                    <div class="d-flex justify-content-between">
                        <a href="produtos.php" class="btn btn-outline-primary">
                            <i class="fas fa-arrow-left me-2"></i>
                            Continuar Comprando
                        </a>
                        
                        <!-- Espaço para futuras ações adicionais -->
                        <div></div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Função para mostrar toast messages (caso queira usar AJAX no futuro)
    function showToast(message, type = 'info') {
        // Criar elemento toast
        const toast = document.createElement('div');
        toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
        toast.setAttribute('role', 'alert');
        toast.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        `;
        
        // Adicionar ao container de toasts
        let toastContainer = document.getElementById('toast-container');
        if (!toastContainer) {
            toastContainer = document.createElement('div');
            toastContainer.id = 'toast-container';
            toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
            document.body.appendChild(toastContainer);
        }
        
        toastContainer.appendChild(toast);
        
        // Mostrar toast
        const bsToast = new bootstrap.Toast(toast);
        bsToast.show();
        
        // Remover após esconder
        toast.addEventListener('hidden.bs.toast', () => {
            toast.remove();
        });
    }

    // Adicionar confirmação para ações importantes
    document.addEventListener('DOMContentLoaded', function() {
        // Confirmação para limpar lista
        const clearForm = document.querySelector('form[action*="action=clear"]');
        if (clearForm) {
            clearForm.addEventListener('submit', function(e) {
                if (!confirm('Tem certeza que deseja limpar toda a sua lista de desejos? Esta ação não pode ser desfeita.')) {
                    e.preventDefault();
                }
            });
        }

        // Confirmação para adicionar todos ao carrinho
        const addAllForm = document.querySelector('form[action*="action=add_all_to_cart"]');
        if (addAllForm) {
            addAllForm.addEventListener('submit', function(e) {
                if (!confirm('Deseja adicionar todos os produtos disponíveis ao carrinho?')) {
                    e.preventDefault();
                }
            });
        }
    });
    </script>
</body>
</html>