<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para acessar sua conta.";
    redirecionar('login.php');
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];

// Buscar dados do usuário
$usuario = [];
$dados_funcionario = [];
$enderecos = [];
$pedidos = [];

try {
    // Buscar dados básicos do usuário
    if ($usuario_tipo === 'cliente') {
        $sql_usuario = "SELECT u.*, c.cpf, c.telefone, c.data_nascimento 
                        FROM usuarios u 
                        LEFT JOIN clientes c ON u.id = c.usuario_id 
                        WHERE u.id = ?";
    } else {
        // Para funcionários e admin, buscar da tabela usuarios
        $sql_usuario = "SELECT u.*, f.cpf, f.telefone, f.data_nascimento 
                        FROM usuarios u 
                        LEFT JOIN funcionarios f ON u.id = f.usuario_id 
                        WHERE u.id = ?";
    }
    
    $stmt = $conn->prepare($sql_usuario);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    // Se for funcionário, buscar dados profissionais
    if ($usuario_tipo === 'funcionario' || $usuario_tipo === 'admin') {
        $sql_funcionario = "SELECT * FROM funcionarios WHERE usuario_id = ?";
        $stmt = $conn->prepare($sql_funcionario);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $dados_funcionario = $result->fetch_assoc();
        
        // Se não encontrou dados na tabela funcionarios, usar dados da tabela usuarios
        if (!$dados_funcionario) {
            $dados_funcionario = [
                'cargo' => $usuario_tipo === 'admin' ? 'administrador' : 'gerente',
                'departamento' => 'Administração',
                'data_admissao' => $usuario['data_cadastro'] ?? date('Y-m-d'),
                'matricula' => 'PG001'
            ];
        }
    }

    // Buscar endereços (apenas para clientes)
    if ($usuario_tipo === 'cliente') {
        $sql_enderecos = "SELECT * FROM enderecos WHERE usuario_id = ? ORDER BY principal DESC, id ASC";
        $stmt = $conn->prepare($sql_enderecos);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $enderecos = $result->fetch_all(MYSQLI_ASSOC);
    }

    // Buscar pedidos do usuário (APENAS PARA CLIENTES)
    if ($usuario_tipo === 'cliente') {
        $sql_pedidos = "SELECT p.*, 
                        COUNT(ip.id) as total_itens,
                        SUM(ip.quantidade) as total_produtos
                        FROM pedidos p 
                        LEFT JOIN itens_pedido ip ON p.id = ip.pedido_id 
                        WHERE p.cliente_id = ? 
                        GROUP BY p.id 
                        ORDER BY p.data_pedido DESC 
                        LIMIT 5";
        $stmt = $conn->prepare($sql_pedidos);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $pedidos = $result->fetch_all(MYSQLI_ASSOC);
    }

} catch (Exception $e) {
    $_SESSION['erro'] = "Erro ao carregar dados: " . $e->getMessage();
}

// Processar alteração de senha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['alterar_senha'])) {
    $senha_atual = $_POST['senha_atual'] ?? '';
    $nova_senha = $_POST['nova_senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';

    if (empty($senha_atual) || empty($nova_senha) || empty($confirmar_senha)) {
        $_SESSION['erro'] = "Todos os campos são obrigatórios.";
    } elseif ($nova_senha !== $confirmar_senha) {
        $_SESSION['erro'] = "As novas senhas não coincidem.";
    } elseif (strlen($nova_senha) < 6) {
        $_SESSION['erro'] = "A nova senha deve ter pelo menos 6 caracteres.";
    } else {
        // Verificar senha atual
        $sql_verificar = "SELECT senha FROM usuarios WHERE id = ?";
        $stmt = $conn->prepare($sql_verificar);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario_db = $result->fetch_assoc();

        if (password_verify($senha_atual, $usuario_db['senha'])) {
            // Atualizar senha
            $nova_senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
            $sql_atualizar = "UPDATE usuarios SET senha = ? WHERE id = ?";
            $stmt = $conn->prepare($sql_atualizar);
            $stmt->bind_param("si", $nova_senha_hash, $usuario_id);

            if ($stmt->execute()) {
                $_SESSION['sucesso'] = "Senha alterada com sucesso!";
            } else {
                $_SESSION['erro'] = "Erro ao alterar senha. Tente novamente.";
            }
        } else {
            $_SESSION['erro'] = "Senha atual incorreta.";
        }
    }
    
    // Recarregar a página para mostrar mensagem
    redirecionar('minha_conta.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Conta - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/formularios.css">
    <style>
        .pedido-card {
            transition: transform 0.2s;
            border: 1px solid #dee2e6;
        }
        .pedido-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .pedido-id {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            font-weight: bold;
            font-size: 1.1em;
            text-align: center;
        }
    </style>
</head>
<body>
    <?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-user-circle text-primary me-2"></i>
                        Minha Conta
                    </h1>
                    <div class="badge bg-<?php echo $usuario_tipo === 'admin' ? 'danger' : ($usuario_tipo === 'funcionario' ? 'success' : 'primary'); ?>">
                        <i class="fas fa-<?php echo $usuario_tipo === 'admin' ? 'crown' : ($usuario_tipo === 'funcionario' ? 'user-tie' : 'user'); ?> me-1"></i>
                        <?php echo ucfirst($usuario_tipo); ?>
                    </div>
                </div>

                <!-- Mensagens -->
                <?php mostrarMensagem(); ?>

                <div class="row">
                    <!-- Menu Lateral -->
                    <div class="col-md-3 mb-4">
                        <div class="card shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0">
                                    <i class="fas fa-cog me-2"></i>
                                    Menu
                                </h6>
                            </div>
                            <div class="list-group list-group-flush">
                                <a href="#dados-pessoais" class="list-group-item list-group-item-action active" data-bs-toggle="list">
                                    <i class="fas fa-user me-2"></i>Dados Pessoais
                                </a>
                                <a href="#alterar-senha" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                    <i class="fas fa-lock me-2"></i>Alterar Senha
                                </a>
                                <?php if ($usuario_tipo === 'cliente'): ?>
                                    <a href="#enderecos" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                        <i class="fas fa-map-marker-alt me-2"></i>Meus Endereços
                                    </a>
                                    <a href="#pedidos" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                        <i class="fas fa-shopping-bag me-2"></i>Meus Pedidos
                                    </a>
                                <?php endif; ?>
                                <a href="#tickets" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                    <i class="fas fa-ticket-alt me-2"></i>Meus Tickets
                                </a>
                                <?php if (isFuncionario()): ?>
                                    <a href="admin/admin.php" class="list-group-item list-group-item-action">
                                        <i class="fas fa-cog me-2"></i>Painel Admin
                                    </a>
                                <?php endif; ?>
                                <a href="includes/logout.php" class="list-group-item list-group-item-action text-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Sair
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Conteúdo -->
                    <div class="col-md-9">
                        <div class="tab-content">
                            <!-- Dados Pessoais -->
                            <div class="tab-pane fade show active" id="dados-pessoais">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-user me-2"></i>
                                            Dados Pessoais
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Nome Completo</label>
                                                <p class="form-control-plaintext"><?php echo htmlspecialchars($usuario['nome'] ?? 'Não informado'); ?></p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Email</label>
                                                <p class="form-control-plaintext"><?php echo htmlspecialchars($usuario['email'] ?? 'Não informado'); ?></p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">CPF</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['cpf'])) {
                                                        echo htmlspecialchars($usuario['cpf']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Telefone</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['telefone'])) {
                                                        echo htmlspecialchars($usuario['telefone']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Data de Nascimento</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['data_nascimento']) && $usuario['data_nascimento'] != '0000-00-00') {
                                                        echo date('d/m/Y', strtotime($usuario['data_nascimento']));
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Data de Cadastro</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['data_cadastro'])) {
                                                        echo date('d/m/Y H:i', strtotime($usuario['data_cadastro']));
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>

                                        <!-- Dados Profissionais (Funcionários) -->
                                        <?php if ($usuario_tipo === 'funcionario' || $usuario_tipo === 'admin'): ?>
                                        <hr>
                                        <h6 class="text-success mb-3">
                                            <i class="fas fa-briefcase me-2"></i>
                                            Dados Profissionais
                                        </h6>
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Cargo</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['cargo'])) {
                                                        echo ucfirst($dados_funcionario['cargo']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Departamento</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['departamento'])) {
                                                        echo ucfirst($dados_funcionario['departamento']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Data de Admissão</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['data_admissao']) && $dados_funcionario['data_admissao'] != '0000-00-00') {
                                                        echo date('d/m/Y', strtotime($dados_funcionario['data_admissao']));
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Matrícula</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['matricula'])) {
                                                        echo htmlspecialchars($dados_funcionario['matricula']);
                                                    } else {
                                                        echo 'Não informada';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Alterar Senha -->
                            <div class="tab-pane fade" id="alterar-senha">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-warning text-dark">
                                        <h5 class="mb-0">
                                            <i class="fas fa-lock me-2"></i>
                                            Alterar Senha
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST" action="">
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="senha_atual" class="form-label">
                                                        <i class="fas fa-key me-1"></i>Senha Atual *
                                                    </label>
                                                    <input type="password" class="form-control" id="senha_atual" name="senha_atual" required
                                                           placeholder="Digite sua senha atual">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="nova_senha" class="form-label">
                                                        <i class="fas fa-lock me-1"></i>Nova Senha *
                                                    </label>
                                                    <input type="password" class="form-control" id="nova_senha" name="nova_senha" required
                                                           placeholder="Mínimo 6 caracteres">
                                                    <small class="form-text text-muted">Mínimo 6 caracteres</small>
                                                </div>
                                                
                                                <div class="col-md-6 mb-3">
                                                    <label for="confirmar_senha" class="form-label">
                                                        <i class="fas fa-lock me-1"></i>Confirmar Nova Senha *
                                                    </label>
                                                    <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" required
                                                           placeholder="Digite a nova senha novamente">
                                                </div>
                                            </div>

                                            <div class="d-grid">
                                                <button type="submit" name="alterar_senha" class="btn btn-warning btn-lg">
                                                    <i class="fas fa-save me-2"></i>
                                                    Alterar Senha
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Endereços (Clientes) -->
                            <?php if ($usuario_tipo === 'cliente'): ?>
                            <div class="tab-pane fade" id="enderecos">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-info text-white d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">
                                            <i class="fas fa-map-marker-alt me-2"></i>
                                            Meus Endereços
                                        </h5>
                                        <button type="button" class="btn btn-light btn-sm" data-bs-toggle="modal" data-bs-target="#modalEndereco">
                                            <i class="fas fa-plus me-1"></i>Novo Endereço
                                        </button>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($enderecos)): ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-map-marker-alt fa-3x text-muted mb-3"></i>
                                                <h5 class="text-muted">Nenhum endereço cadastrado</h5>
                                                <p class="text-muted">Você ainda não cadastrou nenhum endereço.</p>
                                                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalEndereco">
                                                    <i class="fas fa-plus me-2"></i>Cadastrar Primeiro Endereço
                                                </button>
                                            </div>
                                        <?php else: ?>
                                            <div class="row">
                                                <?php foreach ($enderecos as $endereco): ?>
                                                <div class="col-md-6 mb-3">
                                                    <div class="card h-100 <?php echo $endereco['principal'] ? 'border-primary' : ''; ?>">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-between align-items-start mb-2">
                                                                <?php if ($endereco['principal']): ?>
                                                                    <span class="badge bg-primary">
                                                                        <i class="fas fa-star me-1"></i>Principal
                                                                    </span>
                                                                <?php else: ?>
                                                                    <span></span>
                                                                <?php endif; ?>
                                                                <div class="btn-group">
                                                                    <button type="button" class="btn btn-sm btn-outline-primary" 
                                                                            data-bs-toggle="modal" 
                                                                            data-bs-target="#modalEndereco"
                                                                            onclick="carregarEndereco(<?php echo $endereco['id']; ?>)">
                                                                        <i class="fas fa-edit"></i>
                                                                    </button>
                                                                    <button type="button" class="btn btn-sm btn-outline-danger" 
                                                                            onclick="confirmarExclusao(<?php echo $endereco['id']; ?>)">
                                                                        <i class="fas fa-trash"></i>
                                                                    </button>
                                                                </div>
                                                            </div>
                                                            <h6 class="card-title"><?php echo htmlspecialchars($endereco['titulo']); ?></h6>
                                                            <p class="card-text small mb-1">
                                                                <?php echo htmlspecialchars($endereco['logradouro']); ?>, 
                                                                <?php echo htmlspecialchars($endereco['numero']); ?>
                                                                <?php if (!empty($endereco['complemento'])): ?>
                                                                    - <?php echo htmlspecialchars($endereco['complemento']); ?>
                                                                <?php endif; ?>
                                                            </p>
                                                            <p class="card-text small mb-1">
                                                                <?php echo htmlspecialchars($endereco['bairro']); ?> - 
                                                                <?php echo htmlspecialchars($endereco['cidade']); ?>/<?php echo htmlspecialchars($endereco['estado']); ?>
                                                            </p>
                                                            <p class="card-text small text-muted">
                                                                CEP: <?php echo htmlspecialchars($endereco['cep']); ?>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Meus Pedidos (Clientes) -->
                            <?php if ($usuario_tipo === 'cliente'): ?>
                            <div class="tab-pane fade" id="pedidos">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-success text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-shopping-bag me-2"></i>
                                            Meus Pedidos
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($pedidos)): ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                                                <h5 class="text-muted">Nenhum pedido encontrado</h5>
                                                <p class="text-muted">Você ainda não realizou nenhum pedido em nossa loja.</p>
                                                <a href="produtos.php" class="btn btn-success">
                                                    <i class="fas fa-shopping-cart me-2"></i>Fazer Primeira Compra
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="d-flex justify-content-between align-items-center mb-3">
                                                <h6 class="mb-0">
                                                    <?php echo count($pedidos); ?> pedido(s) encontrado(s)
                                                </h6>
                                                <small class="text-muted">
                                                    <i class="fas fa-info-circle me-1"></i>
                                                    Últimos 5 pedidos
                                                </small>
                                            </div>

                                            <?php foreach ($pedidos as $pedido): ?>
                                            <div class="card shadow-sm mb-3 pedido-card">
                                                <div class="card-body">
                                                    <div class="row align-items-center">
                                                        <div class="col-md-3">
                                                            <div class="pedido-id">
                                                                PEDIDO #<?php echo $pedido['id']; ?>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-3">
                                                            <strong>Data:</strong><br>
                                                            <?php echo date('d/m/Y', strtotime($pedido['data_pedido'])); ?>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <strong>Total:</strong><br>
                                                            <span class="text-primary fw-bold">
                                                                R$ <?php echo number_format($pedido['total'], 2, ',', '.'); ?>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2">
                                                            <strong>Status:</strong><br>
                                                            <?php
                                                            $status_classes = [
                                                                'pendente' => 'bg-warning',
                                                                'pago' => 'bg-info',
                                                                'processando' => 'bg-primary',
                                                                'enviado' => 'bg-secondary',
                                                                'entregue' => 'bg-success',
                                                                'cancelado' => 'bg-danger'
                                                            ];
                                                            ?>
                                                            <span class="badge <?php echo $status_classes[$pedido['status']] ?? 'bg-secondary'; ?>">
                                                                <?php echo ucfirst($pedido['status']); ?>
                                                            </span>
                                                        </div>
                                                        <div class="col-md-2 text-end">
                                                            <a href="meus_pedidos.php?pedido_id=<?php echo $pedido['id']; ?>" 
                                                               class="btn btn-success btn-sm">
                                                                <i class="fas fa-eye me-1"></i>
                                                                Ver Pedido
                                                            </a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>

                                            <div class="mt-3 text-center">
                                                <a href="meus_pedidos.php" class="btn btn-success">
                                                    <i class="fas fa-list me-2"></i>
                                                    Ver Todos os Pedidos
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Meus Tickets -->
                            <div class="tab-pane fade" id="tickets">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-warning text-dark">
                                        <h5 class="mb-0">
                                            <i class="fas fa-ticket-alt me-2"></i>
                                            Meus Tickets de Suporte
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php
                                        // Buscar tickets do usuário
                                        $tickets = [];
                                        try {
                                            $sql_tickets = "SELECT ts.*, 
                                                           COUNT(ms.id) as total_mensagens,
                                                           MAX(ms.data_envio) as ultima_resposta
                                                    FROM tickets_suporte ts
                                                    LEFT JOIN mensagens_suporte ms ON ts.id = ms.ticket_id
                                                    WHERE ts.usuario_id = ?
                                                    GROUP BY ts.id
                                                    ORDER BY ts.data_abertura DESC";
                                            
                                            $stmt = $conn->prepare($sql_tickets);
                                            $stmt->bind_param("i", $usuario_id);
                                            $stmt->execute();
                                            $result = $stmt->get_result();
                                            $tickets = $result->fetch_all(MYSQLI_ASSOC);
                                            
                                        } catch (Exception $e) {
                                            echo '<div class="alert alert-danger">Erro ao carregar tickets: ' . $e->getMessage() . '</div>';
                                        }
                                        ?>
                                        
                                        <?php if (empty($tickets)): ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-ticket-alt fa-3x text-muted mb-3"></i>
                                                <h5 class="text-muted">Nenhum ticket encontrado</h5>
                                                <p class="text-muted">Você ainda não abriu nenhum ticket de suporte.</p>
                                                <a href="suporte.php" class="btn btn-warning">
                                                    <i class="fas fa-plus me-2"></i>Abrir Primeiro Ticket
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>Ticket #</th>
                                                            <th>Assunto</th>
                                                            <th>Categoria</th>
                                                            <th>Status</th>
                                                            <th>Prioridade</th>
                                                            <th>Data Abertura</th>
                                                            <th>Mensagens</th>
                                                            <th>Ações</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($tickets as $ticket): ?>
                                                        <tr>
                                                            <td><strong>#<?= $ticket['id'] ?></strong></td>
                                                            <td><?= htmlspecialchars($ticket['assunto']) ?></td>
                                                            <td>
                                                                <span class="badge bg-secondary">
                                                                    <?= ucfirst($ticket['categoria']) ?>
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <?php
                                                                $status_class = [
                                                                    'aberto' => 'bg-success',
                                                                    'em_andamento' => 'bg-warning',
                                                                    'respondido' => 'bg-info',
                                                                    'fechado' => 'bg-secondary'
                                                                ];
                                                                ?>
                                                                <span class="badge <?= $status_class[$ticket['status']] ?? 'bg-secondary' ?>">
                                                                    <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <?php
                                                                $prioridade_class = [
                                                                    'baixa' => 'bg-secondary',
                                                                    'media' => 'bg-info',
                                                                    'alta' => 'bg-warning',
                                                                    'urgente' => 'bg-danger'
                                                                ];
                                                                ?>
                                                                <span class="badge <?= $prioridade_class[$ticket['prioridade']] ?? 'bg-secondary' ?>">
                                                                    <?= ucfirst($ticket['prioridade']) ?>
                                                                </span>
                                                            </td>
                                                            <td><?= date('d/m/Y H:i', strtotime($ticket['data_abertura'])) ?></td>
                                                            <td><?= $ticket['total_mensagens'] ?></td>
                                                            <td>
                                                                <a href="meus_tickets.php" class="btn btn-sm btn-outline-warning">
                                                                    <i class="fas fa-eye me-1"></i>
                                                                    Ver Detalhes
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                            
                                            <div class="mt-3 text-center">
                                                <a href="suporte.php" class="btn btn-warning">
                                                    <i class="fas fa-plus me-2"></i>
                                                    Abrir Novo Ticket
                                                </a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/rodape.php'; ?>

    <!-- Modal para Adicionar/Editar Endereço -->
    <?php if ($usuario_tipo === 'cliente'): ?>
    <div class="modal fade" id="modalEndereco" tabindex="-1" aria-labelledby="modalEnderecoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="modalEnderecoLabel">
                        <i class="fas fa-map-marker-alt me-2"></i>
                        <span id="modalTitulo">Novo Endereço</span>
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form method="POST" action="includes/processa_endereco.php" id="formEndereco">
                    <div class="modal-body">
                        <input type="hidden" name="acao" id="acao" value="adicionar">
                        <input type="hidden" name="endereco_id" id="endereco_id" value="">
                        
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="titulo" class="form-label">Título do Endereço *</label>
                                <input type="text" class="form-control" id="titulo" name="titulo" required
                                       placeholder="Ex: Casa, Trabalho, Apartamento" maxlength="50">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="cep" class="form-label">CEP *</label>
                                <input type="text" class="form-control" id="cep" name="cep" required
                                       placeholder="Digite apenas números" maxlength="8">
                                <small class="form-text text-muted">Apenas números (8 dígitos)</small>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label for="logradouro" class="form-label">Logradouro *</label>
                                <input type="text" class="form-control" id="logradouro" name="logradouro" required
                                       placeholder="Rua, Avenida, etc." maxlength="200">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="numero" class="form-label">Número *</label>
                                <input type="text" class="form-control" id="numero" name="numero" required
                                       placeholder="Nº" maxlength="6">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="complemento" class="form-label">Complemento</label>
                                <input type="text" class="form-control" id="complemento" name="complemento"
                                       placeholder="Apto, Bloco, etc." maxlength="100">
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="bairro" class="form-label">Bairro *</label>
                                <input type="text" class="form-control" id="bairro" name="bairro" required maxlength="100">
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label for="cidade" class="form-label">Cidade *</label>
                                <input type="text" class="form-control" id="cidade" name="cidade" required maxlength="100">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label for="estado" class="form-label">Estado *</label>
                                <select class="form-select" id="estado" name="estado" required>
                                    <option value="">Selecione</option>
                                    <option value="AC">Acre</option>
                                    <option value="AL">Alagoas</option>
                                    <option value="AP">Amapá</option>
                                    <option value="AM">Amazonas</option>
                                    <option value="BA">Bahia</option>
                                    <option value="CE">Ceará</option>
                                    <option value="DF">Distrito Federal</option>
                                    <option value="ES">Espírito Santo</option>
                                    <option value="GO">Goiás</option>
                                    <option value="MA">Maranhão</option>
                                    <option value="MT">Mato Grosso</option>
                                    <option value="MS">Mato Grosso do Sul</option>
                                    <option value="MG">Minas Gerais</option>
                                    <option value="PA">Pará</option>
                                    <option value="PB">Paraíba</option>
                                    <option value="PR">Paraná</option>
                                    <option value="PE">Pernambuco</option>
                                    <option value="PI">Piauí</option>
                                    <option value="RJ">Rio de Janeiro</option>
                                    <option value="RN">Rio Grande do Norte</option>
                                    <option value="RS">Rio Grande do Sul</option>
                                    <option value="RO">Rondônia</option>
                                    <option value="RR">Roraima</option>
                                    <option value="SC">Santa Catarina</option>
                                    <option value="SP">São Paulo</option>
                                    <option value="SE">Sergipe</option>
                                    <option value="TO">Tocantins</option>
                                </select>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="principal" name="principal">
                                <label class="form-check-label" for="principal">
                                    Definir como endereço principal
                                </label>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                        <button type="submit" class="btn btn-primary">
                            <i class="fas fa-save me-2"></i>
                            <span id="botaoTexto">Salvar Endereço</span>
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Ativar tabs
        document.addEventListener('DOMContentLoaded', function() {
            const triggerTabList = [].slice.call(document.querySelectorAll('a[data-bs-toggle="list"]'));
            triggerTabList.forEach(function (triggerEl) {
                const tabTrigger = new bootstrap.Tab(triggerEl);
                
                triggerEl.addEventListener('click', function (event) {
                    event.preventDefault();
                    tabTrigger.show();
                });
            });

            // Validação de senha
            const novaSenha = document.getElementById('nova_senha');
            const confirmarSenha = document.getElementById('confirmar_senha');

            function validarSenhas() {
                if (novaSenha.value !== confirmarSenha.value) {
                    confirmarSenha.classList.add('is-invalid');
                    confirmarSenha.classList.remove('is-valid');
                } else {
                    confirmarSenha.classList.remove('is-invalid');
                    confirmarSenha.classList.add('is-valid');
                }
            }

            if (novaSenha && confirmarSenha) {
                novaSenha.addEventListener('input', validarSenhas);
                confirmarSenha.addEventListener('input', validarSenhas);
            }
        });

        // ========== FUNÇÕES PARA GERENCIAMENTO DE ENDEREÇOS ==========

        // Função para carregar dados do endereço para edição
        function carregarEndereco(enderecoId) {
            console.log("Iniciando carregarEndereco com ID:", enderecoId);
            
            fetch(`includes/buscar_endereco.php?id=${enderecoId}`)
                .then(response => {
                    console.log("Status da resposta:", response.status);
                    console.log("URL da resposta:", response.url);
                    return response.text(); // Mude para text() para debug
                })
                .then(text => {
                    console.log("Resposta bruta:", text);
                    try {
                        const data = JSON.parse(text);
                        console.log("Dados parseados:", data);
                        
                        if (data.success) {
                            const endereco = data.endereco;
                            console.log("Preenchendo formulário com:", endereco);
                            
                            // Preencher formulário
                            document.getElementById('modalTitulo').textContent = 'Editar Endereço';
                            document.getElementById('botaoTexto').textContent = 'Atualizar Endereço';
                            document.getElementById('acao').value = 'editar';
                            document.getElementById('endereco_id').value = endereco.id;
                            document.getElementById('titulo').value = endereco.titulo;
                            document.getElementById('cep').value = endereco.cep;
                            document.getElementById('logradouro').value = endereco.logradouro;
                            document.getElementById('numero').value = endereco.numero;
                            document.getElementById('complemento').value = endereco.complemento || '';
                            document.getElementById('bairro').value = endereco.bairro;
                            document.getElementById('cidade').value = endereco.cidade;
                            document.getElementById('estado').value = endereco.estado;
                            document.getElementById('principal').checked = endereco.principal == 1;
                            
                            console.log("Formulário preenchido com sucesso!");
                        } else {
                            console.error("Erro do servidor:", data.message);
                            alert('Erro ao carregar endereço: ' + data.message);
                        }
                    } catch (e) {
                        console.error("Erro ao parsear JSON:", e);
                        alert('Erro ao processar resposta do servidor.');
                    }
                })
                .catch(error => {
                    console.error('Erro no fetch:', error);
                    alert('Erro ao carregar endereço. Tente novamente.');
                });
        }

        // Função para confirmar exclusão
        function confirmarExclusao(enderecoId) {
            if (confirm('Tem certeza que deseja excluir este endereço?')) {
                window.location.href = `includes/processa_endereco.php?excluir=${enderecoId}`;
            }
        }

        // Função para limpar formulário ao abrir modal para novo endereço
        document.getElementById('modalEndereco')?.addEventListener('show.bs.modal', function (event) {
            // Se não foi clicado em editar, limpa o formulário
            if (!event.relatedTarget || event.relatedTarget.textContent.includes('Novo')) {
                document.getElementById('modalTitulo').textContent = 'Novo Endereço';
                document.getElementById('botaoTexto').textContent = 'Salvar Endereço';
                document.getElementById('acao').value = 'adicionar';
                document.getElementById('formEndereco').reset();
                document.getElementById('endereco_id').value = '';
            }
        });

        // Permitir apenas números no CEP e número
        document.getElementById('cep')?.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });

        document.getElementById('numero')?.addEventListener('input', function(e) {
            e.target.value = e.target.value.replace(/\D/g, '');
        });
    </script>
</body>
</html>