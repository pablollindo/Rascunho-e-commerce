<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se é admin ou funcionário com permissão
if (!isFuncionario()) {
    $_SESSION['erro'] = "Acesso restrito à funcionários.";
    header("Location: ../indexx.php");
    exit;
}

try {
    $pdo = conectarBanco();
    
    // Processar atualização de estoque
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_estoque'])) {
        $produto_id = intval($_POST['produto_id']);
        $novo_estoque = intval($_POST['estoque']);
        
        $stmt = $pdo->prepare("UPDATE produtos SET estoque = ? WHERE id = ?");
        $stmt->execute([$novo_estoque, $produto_id]);
        
        $_SESSION['sucesso'] = "Estoque atualizado com sucesso!";
        header("Location: admin_estoque.php");
        exit;
    }
    
    // Buscar produtos para gerenciamento de estoque
    $sql_produtos = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
                    FROM produtos p 
                    LEFT JOIN categorias c ON p.categoria_id = c.id 
                    LEFT JOIN marcas m ON p.marca_id = m.id 
                    WHERE p.ativo = 1 
                    ORDER BY p.estoque ASC, p.nome ASC";
    $produtos = $pdo->query($sql_produtos)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar estoque: " . $e->getMessage();
    $produtos = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Estoque - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
        .estoque-baixo {
            background-color: #fff3cd !important;
        }
        .estoque-zero {
            background-color: #f8d7da !important;
        }
        .estoque-input {
            width: 80px;
            text-align: center;
        }
    </style>
</head>
<body>
    <!-- Cabeçalho Igual ao Indexx -->
    <?php 
    $tituloPagina = "Gerenciar Estoque - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            Dashboard
                        </a>
                        
                        <?php if (isAdmin()): ?>
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>
                            Produtos
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_estoque.php" class="nav-link active">
                            <i class="fas fa-warehouse me-2"></i>
                            Estoque
                        </a>
                        
                        <?php if (isAdmin()): ?>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>
                            Categorias & Marcas
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos
                        </a>
                        
                        <?php if (isAdmin()): ?>
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>
                            Clientes
                        </a>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>
                            Funcionários
                        </a>
                        <?php endif; ?>
                        
                        <a href="admin_suporte.php" class="nav-link">
                            <i class="fas fa-headset me-2"></i>
                            Suporte
                        </a>
                        
                        <?php if (isAdmin()): ?>
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>
                            Relatórios
                        </a>
                        <?php endif; ?>
                        
                        <hr class="bg-light my-3">
                        
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>
                            Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-warehouse me-2"></i>
                                Gerenciar Estoque
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <a href="admin_produtos.php?action=add" class="btn btn-success">
                                    <i class="fas fa-plus me-2"></i>
                                    Novo Produto
                                </a>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <!-- Filtros -->
                    <div class="row mb-4">
                        <div class="col-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-4">
                                            <div class="d-flex align-items-center">
                                                <span class="badge bg-danger me-2">●</span>
                                                <small>Estoque Zero</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="d-flex align-items-center">
                                                <span class="badge bg-warning me-2">●</span>
                                                <small>Estoque Baixo (≤ 5)</small>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="d-flex align-items-center">
                                                <span class="badge bg-success me-2">●</span>
                                                <small>Estoque Normal (> 5)</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Lista de Produtos para Estoque -->
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-hover">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Produto</th>
                                            <th>Categoria</th>
                                            <th>Marca</th>
                                            <th>Preço</th>
                                            <th>Estoque Atual</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php if (empty($produtos)): ?>
                                            <tr>
                                                <td colspan="8" class="text-center py-4 text-muted">
                                                    <i class="fas fa-box-open fa-2x mb-3"></i><br>
                                                    Nenhum produto encontrado.
                                                </td>
                                            </tr>
                                        <?php else: ?>
                                            <?php foreach ($produtos as $prod): ?>
                                            <?php
                                                $estoque_class = '';
                                                if ($prod['estoque'] == 0) {
                                                    $estoque_class = 'estoque-zero';
                                                } elseif ($prod['estoque'] <= 5) {
                                                    $estoque_class = 'estoque-baixo';
                                                }
                                            ?>
                                            <tr class="<?= $estoque_class ?>">
                                                <td>#<?= str_pad($prod['id'], 6, '0', STR_PAD_LEFT) ?></td>
                                                <td>
                                                    <strong><?= htmlspecialchars($prod['nome']) ?></strong>
                                                    <div class="small text-muted">
                                                        <?php if ($prod['em_destaque']): ?>
                                                            <span class="badge bg-warning me-1">Destaque</span>
                                                        <?php endif; ?>
                                                        <?php if ($prod['em_promocao']): ?>
                                                            <span class="badge bg-danger me-1">Promoção</span>
                                                        <?php endif; ?>
                                                    </div>
                                                </td>
                                                <td><?= htmlspecialchars($prod['categoria_nome']) ?></td>
                                                <td><?= htmlspecialchars($prod['marca_nome']) ?></td>
                                                <td>
                                                    <?php if ($prod['em_promocao'] && $prod['preco_promocional']): ?>
                                                        <span class="text-danger fw-bold">R$ <?= number_format($prod['preco_promocional'], 2, ',', '.') ?></span>
                                                    <?php else: ?>
                                                        R$ <?= number_format($prod['preco'], 2, ',', '.') ?>
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <form method="POST" class="d-inline">
                                                        <input type="hidden" name="produto_id" value="<?= $prod['id'] ?>">
                                                        <div class="input-group input-group-sm">
                                                            <input type="number" 
                                                                   class="form-control estoque-input" 
                                                                   name="estoque" 
                                                                   value="<?= $prod['estoque'] ?>" 
                                                                   min="0" 
                                                                   required>
                                                            <button type="submit" name="atualizar_estoque" class="btn btn-outline-primary">
                                                                <i class="fas fa-save"></i>
                                                            </button>
                                                        </div>
                                                    </form>
                                                </td>
                                                <td>
                                                    <span class="badge bg-<?= $prod['estoque'] > 5 ? 'success' : ($prod['estoque'] > 0 ? 'warning' : 'danger') ?>">
                                                        <?= $prod['estoque'] > 5 ? 'Normal' : ($prod['estoque'] > 0 ? 'Baixo' : 'Zero') ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <div class="btn-group btn-group-sm">
                                                        <a href="admin_produtos.php?action=edit&id=<?= $prod['id'] ?>" 
                                                           class="btn btn-outline-primary" title="Editar Produto">
                                                            <i class="fas fa-edit"></i>
                                                        </a>
                                                        <a href="../produto.php?id=<?= $prod['id'] ?>" 
                                                           target="_blank" class="btn btn-outline-info" title="Visualizar">
                                                            <i class="fas fa-eye"></i>
                                                        </a>
                                                    </div>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- Estatísticas de Estoque -->
                    <div class="row mt-4">
                        <div class="col-md-3">
                            <div class="card text-white bg-danger">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-times-circle me-2"></i>
                                        Estoque Zero
                                    </h5>
                                    <p class="card-text h4">
                                        <?= count(array_filter($produtos, function($p) { return $p['estoque'] == 0; })) ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white bg-warning">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        Estoque Baixo
                                    </h5>
                                    <p class="card-text h4">
                                        <?= count(array_filter($produtos, function($p) { return $p['estoque'] > 0 && $p['estoque'] <= 5; })) ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white bg-success">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-check-circle me-2"></i>
                                        Estoque Normal
                                    </h5>
                                    <p class="card-text h4">
                                        <?= count(array_filter($produtos, function($p) { return $p['estoque'] > 5; })) ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="card text-white bg-info">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <i class="fas fa-boxes me-2"></i>
                                        Total Produtos
                                    </h5>
                                    <p class="card-text h4">
                                        <?= count($produtos) ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>
</body>
</html>