<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    $_SESSION['erro'] = "Método não permitido.";
    header("Location: ../suporte.php");
    exit;
}

// VERIFICAR SE O USUÁRIO ESTÁ LOGADO - AGORA É OBRIGATÓRIO
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['erro'] = "Você precisa estar logado para abrir um ticket de suporte.";
    $_SESSION['dados_temporarios'] = [
        'assunto' => $_POST['assunto'] ?? '',
        'categoria' => $_POST['categoria'] ?? '',
        'prioridade' => $_POST['prioridade'] ?? '',
        'descricao' => $_POST['descricao'] ?? ''
    ];
    header("Location: ../login.php?redirect=suporte");
    exit;
}

// Coletar e validar dados
$assunto = trim($_POST['assunto'] ?? '');
$categoria = $_POST['categoria'] ?? '';
$prioridade = $_POST['prioridade'] ?? '';
$descricao = trim($_POST['descricao'] ?? '');
$usuario_id = $_SESSION['usuario_id'];

// Validações básicas
if (empty($assunto) || empty($categoria) || empty($prioridade) || empty($descricao)) {
    $_SESSION['erro'] = "Todos os campos obrigatórios devem ser preenchidos.";
    header("Location: ../suporte.php");
    exit;
}

if (strlen($assunto) < 5) {
    $_SESSION['erro'] = "O assunto deve ter pelo menos 5 caracteres.";
    header("Location: ../suporte.php");
    exit;
}

if (strlen($descricao) < 10) {
    $_SESSION['erro'] = "A descrição deve ter pelo menos 10 caracteres.";
    header("Location: ../suporte.php");
    exit;
}

try {
    $pdo = conectarBanco();
    
    // Inserir ticket na tabela tickets_suporte
    $sql = "INSERT INTO tickets_suporte (
        usuario_id, 
        assunto, 
        categoria, 
        descricao, 
        status, 
        prioridade, 
        data_abertura
    ) VALUES (?, ?, ?, ?, 'aberto', ?, NOW())";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$usuario_id, $assunto, $categoria, $descricao, $prioridade]);
    
    $ticket_id = $pdo->lastInsertId();
    
    // Inserir a primeira mensagem do ticket
    $sql_mensagem = "INSERT INTO mensagens_suporte (
        ticket_id, 
        usuario_id, 
        mensagem, 
        data_envio,
        eh_funcionario
    ) VALUES (?, ?, ?, NOW(), FALSE)";
    
    $stmt_mensagem = $pdo->prepare($sql_mensagem);
    $stmt_mensagem->execute([$ticket_id, $usuario_id, $descricao]);
    
    $_SESSION['sucesso'] = "Ticket #{$ticket_id} aberto com sucesso! Nossa equipe entrará em contato em breve.";
    
    // Redirecionar para a página de meus tickets
    header("Location: ../meus_tickets.php");
    exit;
    
} catch (PDOException $e) {
    error_log("Erro ao abrir ticket: " . $e->getMessage());
    $_SESSION['erro'] = "Erro ao abrir ticket. Tente novamente.";
    header("Location: ../suporte.php");
    exit;
}
?>