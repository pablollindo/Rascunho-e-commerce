<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para gerenciar endereços.";
    header("Location: ../login.php");
    exit;
}

$usuario_id = $_SESSION['usuario_id'];

// Processar adição/edição de endereço
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $acao = $_POST['acao'] ?? '';
    $endereco_id = $_POST['endereco_id'] ?? 0;
    
    // Sanitizar dados
    $titulo = sanitizar($_POST['titulo'] ?? '');
    $cep = $_POST['cep'] ?? '';
    $logradouro = sanitizar($_POST['logradouro'] ?? '');
    $numero = sanitizar($_POST['numero'] ?? '');
    $complemento = sanitizar($_POST['complemento'] ?? '');
    $bairro = sanitizar($_POST['bairro'] ?? '');
    $cidade = sanitizar($_POST['cidade'] ?? '');
    $estado = sanitizar($_POST['estado'] ?? '');
    $principal = isset($_POST['principal']) ? 1 : 0;
    
    // Validar dados obrigatórios
    if (empty($titulo) || empty($cep) || empty($logradouro) || empty($numero) || empty($bairro) || empty($cidade) || empty($estado)) {
        $_SESSION['erro'] = "Todos os campos obrigatórios devem ser preenchidos.";
        header("Location: ../minha_conta.php#enderecos");
        exit;
    }
    
    // Validar CEP
    if (strlen($cep) !== 8) {
        $_SESSION['erro'] = "CEP inválido. Deve conter 8 dígitos.";
        header("Location: ../minha_conta.php#enderecos");
        exit;
    }
    
    try {
        // Se for endereço principal, remover principal dos outros endereços
        if ($principal) {
            $sql_remove_principal = "UPDATE enderecos SET principal = 0 WHERE usuario_id = ?";
            $stmt = $conn->prepare($sql_remove_principal);
            $stmt->bind_param("i", $usuario_id);
            $stmt->execute();
        }
        
        if ($acao === 'editar' && $endereco_id > 0) {
            // Atualizar endereço existente
            $sql = "UPDATE enderecos SET titulo = ?, cep = ?, logradouro = ?, numero = ?, complemento = ?, bairro = ?, cidade = ?, estado = ?, principal = ? 
                    WHERE id = ? AND usuario_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssssssiii", $titulo, $cep, $logradouro, $numero, $complemento, $bairro, $cidade, $estado, $principal, $endereco_id, $usuario_id);
            
            if ($stmt->execute()) {
                $_SESSION['sucesso'] = "Endereço atualizado com sucesso!";
            } else {
                $_SESSION['erro'] = "Erro ao atualizar endereço. Tente novamente.";
            }
        } else {
            // Inserir novo endereço
            $sql = "INSERT INTO enderecos (usuario_id, titulo, cep, logradouro, numero, complemento, bairro, cidade, estado, principal) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("issssssssi", $usuario_id, $titulo, $cep, $logradouro, $numero, $complemento, $bairro, $cidade, $estado, $principal);
            
            if ($stmt->execute()) {
                $_SESSION['sucesso'] = "Endereço cadastrado com sucesso!";
            } else {
                $_SESSION['erro'] = "Erro ao cadastrar endereço. Tente novamente.";
            }
        }
        
    } catch (Exception $e) {
        $_SESSION['erro'] = "Erro no sistema: " . $e->getMessage();
    }
    
    header("Location: ../minha_conta.php#enderecos");
    exit;
}

// Processar exclusão de endereço
if (isset($_GET['excluir'])) {
    $endereco_id = intval($_GET['excluir']);
    
    try {
        // Verificar se é o último endereço
        $sql_count = "SELECT COUNT(*) as total FROM enderecos WHERE usuario_id = ?";
        $stmt = $conn->prepare($sql_count);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $total_enderecos = $result->fetch_assoc()['total'];
        
        if ($total_enderecos <= 1) {
            $_SESSION['erro'] = "Você não pode excluir seu único endereço cadastrado.";
            header("Location: ../minha_conta.php#enderecos");
            exit;
        }
        
        // Excluir endereço
        $sql = "DELETE FROM enderecos WHERE id = ? AND usuario_id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ii", $endereco_id, $usuario_id);
        
        if ($stmt->execute()) {
            $_SESSION['sucesso'] = "Endereço excluído com sucesso!";
        } else {
            $_SESSION['erro'] = "Erro ao excluir endereço. Tente novamente.";
        }
        
    } catch (Exception $e) {
        $_SESSION['erro'] = "Erro no sistema: " . $e->getMessage();
    }
    
    header("Location: ../minha_conta.php#enderecos");
    exit;
}

header("Location: ../minha_conta.php#enderecos");
exit;
?>