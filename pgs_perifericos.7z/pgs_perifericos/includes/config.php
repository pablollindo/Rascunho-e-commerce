<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Configurações do banco de dados
define('DB_HOST', 'localhost');
define('DB_PORT', '3309');
define('DB_NAME', 'pgs_perifericos');
define('DB_USER', 'root');
define('DB_PASS', '');

// Configurações do site
define('SITE_NAME', 'PGS Periféricos');
define('SITE_URL', 'http://localhost/pgs_perifericos');

// Conexão MySQLi
$conn = new mysqli(DB_HOST . ':' . DB_PORT, DB_USER, DB_PASS, DB_NAME);

// Verificar conexão
if ($conn->connect_error) {
    die("Erro de conexão com o banco de dados: " . $conn->connect_error);
}

// Definir charset para utf8
$conn->set_charset("utf8mb4");
?>