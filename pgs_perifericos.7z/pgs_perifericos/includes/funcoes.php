<?php
// Função para conectar ao banco
function conectarBanco() {
    try {
        $pdo = new PDO('mysql:host=' . DB_HOST . ';port=' . DB_PORT . ';dbname=' . DB_NAME, DB_USER, DB_PASS);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        return $pdo;
    } catch (PDOException $e) {
        die("Erro na conexão: " . $e->getMessage());
    }
}

// Função para sanitizar dados
function sanitizar($dados) {
    return htmlspecialchars(trim($dados));
}

// Função para validar email
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

// Função para validar CPF (simplificada)
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    return strlen($cpf) === 11;
}

// Função para gerar hash da senha
function gerarHashSenha($senha) {
    return password_hash($senha, PASSWORD_DEFAULT);
}

// Função para verificar se usuário está logado
function usuarioEstaLogado() {
    return isset($_SESSION['usuario_id']);
}

// Função para verificar se é admin
function isAdmin() {
    return isset($_SESSION['usuario_tipo']) && $_SESSION['usuario_tipo'] === 'admin';
}

// Função para verificar se é funcionário
function isFuncionario() {
    return isset($_SESSION['usuario_tipo']) && ($_SESSION['usuario_tipo'] === 'funcionario' || $_SESSION['usuario_tipo'] === 'admin');
}

// Função para obter cargo do funcionário
function getCargoFuncionario() {
    return $_SESSION['usuario_cargo'] ?? null;
}

// Função para redirecionar
function redirecionar($pagina) {
    header("Location: $pagina");
    exit;
}

// Função para mostrar mensagens
function mostrarMensagem() {
    if (isset($_SESSION['sucesso'])) {
        echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                <i class="fas fa-check-circle me-2"></i>
                ' . $_SESSION['sucesso'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['sucesso']);
    }
    
    if (isset($_SESSION['erro'])) {
        echo '<div class="alert alert-danger alert-dismissible fade show" role="alert">
                <i class="fas fa-exclamation-triangle me-2"></i>
                ' . $_SESSION['erro'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['erro']);
    }
    
    if (isset($_SESSION['info'])) {
        echo '<div class="alert alert-info alert-dismissible fade show" role="alert">
                <i class="fas fa-info-circle me-2"></i>
                ' . $_SESSION['info'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['info']);
    }
}

// Função para verificar permissões de admin
function requererAdmin() {
    if (!isAdmin()) {
        $_SESSION['erro'] = "Acesso restrito à administração.";
        redirecionar('../indexx.php');
    }
}

// Função para verificar permissões de funcionário
function requererFuncionario() {
    if (!isFuncionario()) {
        $_SESSION['erro'] = "Acesso restrito à funcionários.";
        redirecionar('../indexx.php');
    }
}

// Função para fazer logout
function logout() {
    session_destroy();
    redirecionar('../indexx.php');
}

// Função para formatar preço
function formatarPreco($preco) {
    return 'R$ ' . number_format($preco, 2, ',', '.');
}
?>