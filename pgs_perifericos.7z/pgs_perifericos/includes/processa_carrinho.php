<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// VERIFICAÇÃO: Bloquear funcionários/admin de usar carrinho
if (usuarioEstaLogado() && (isAdmin() || isFuncionario())) {
    $response = ['success' => false, 'message' => 'Funcionários e administradores não podem adicionar produtos ao carrinho.'];
    
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        $_SESSION['erro'] = $response['message'];
        header('Location: ../indexx.php');
    }
    exit;
}

// Verificar se é uma requisição AJAX
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

// Inicializar carrinho na sessão se não existir
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$action = $_POST['action'] ?? $_GET['action'] ?? '';
$product_id = intval($_POST['product_id'] ?? $_GET['product_id'] ?? 0);
$quantity = intval($_POST['quantity'] ?? $_GET['quantity'] ?? 1);

$response = ['success' => false, 'message' => '', 'cart_count' => 0];

// Limpar mensagens de cupom da sessão quando atualizar carrinho
if ($action === 'update' || $action === 'add' || $action === 'remove') {
    unset($_SESSION['erro']);
    unset($_SESSION['sucesso']);
}

try {
    switch ($action) {
        case 'add':
            // Verificar se o produto existe e está ativo
            $sql = "SELECT p.*, m.nome as marca_nome, c.nome as categoria_nome 
                    FROM produtos p 
                    LEFT JOIN marcas m ON p.marca_id = m.id 
                    LEFT JOIN categorias c ON p.categoria_id = c.id 
                    WHERE p.id = ? AND p.ativo = 1";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $produto = $result->fetch_assoc();
            
            if (!$produto) {
                throw new Exception("Produto não encontrado ou indisponível.");
            }
            
            // Verificar estoque
            if ($produto['estoque'] < $quantity) {
                throw new Exception("Quantidade solicitada indisponível em estoque. Disponível: " . $produto['estoque']);
            }
            
            // Adicionar ou atualizar item no carrinho
            if (isset($_SESSION['carrinho'][$product_id])) {
                $_SESSION['carrinho'][$product_id]['quantidade'] += $quantity;
            } else {
                $_SESSION['carrinho'][$product_id] = [
                    'id' => $produto['id'],
                    'nome' => $produto['nome'],
                    'preco' => floatval($produto['preco']),
                    'preco_promocional' => $produto['preco_promocional'] ? floatval($produto['preco_promocional']) : null,
                    'quantidade' => $quantity,
                    'imagem' => $produto['imagem'],
                    'estoque' => intval($produto['estoque']),
                    'marca_nome' => $produto['marca_nome'],
                    'categoria_nome' => $produto['categoria_nome'],
                    'garantia_meses' => $produto['garantia_meses']
                ];
            }
            
            $response['success'] = true;
            $response['message'] = "Produto adicionado ao carrinho!";
            break;
            
        case 'update':
            if (isset($_SESSION['carrinho'][$product_id])) {
                // Verificar estoque atual no banco
                $sql = "SELECT estoque FROM produtos WHERE id = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $product_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $produto = $result->fetch_assoc();
                
                if ($quantity > $produto['estoque']) {
                    throw new Exception("Quantidade solicitada indisponível em estoque. Disponível: " . $produto['estoque']);
                }
                
                $_SESSION['carrinho'][$product_id]['quantidade'] = $quantity;
                $response['success'] = true;
                $response['message'] = "Quantidade atualizada!";
            } else {
                throw new Exception("Produto não encontrado no carrinho.");
            }
            break;
            
        case 'remove':
            if (isset($_SESSION['carrinho'][$product_id])) {
                $produto_nome = $_SESSION['carrinho'][$product_id]['nome'];
                unset($_SESSION['carrinho'][$product_id]);
                $response['success'] = true;
                $response['message'] = "$produto_nome removido do carrinho!";
            } else {
                throw new Exception("Produto não encontrado no carrinho.");
            }
            break;
            
        case 'clear':
            $_SESSION['carrinho'] = [];
            $response['success'] = true;
            $response['message'] = "Carrinho limpo!";
            break;
            
        case 'get_count':
            $response['success'] = true;
            break;
            
        default:
            throw new Exception("Ação inválida.");
    }
    
    // Calcular total de itens no carrinho
    $total_itens = 0;
    foreach ($_SESSION['carrinho'] as $item) {
        $total_itens += $item['quantidade'];
    }
    $response['cart_count'] = $total_itens;
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

if ($is_ajax) {
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
} else {
    if ($response['success']) {
        $_SESSION['sucesso'] = $response['message'];
    } else {
        $_SESSION['erro'] = $response['message'];
    }
    
    // Redirecionar de volta
    $redirect = $_POST['redirect'] ?? $_GET['redirect'] ?? $_SERVER['HTTP_REFERER'] ?? 'carrinho.php';
    header("Location: $redirect");
    exit;
}
?>