<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// Limpar TODAS as mensagens da sessão
unset($_SESSION['erro']);
unset($_SESSION['sucesso']);

$product_id = intval($_GET['product_id'] ?? 0);
$quantity = intval($_GET['quantity'] ?? 1);

if ($product_id <= 0) {
    $_SESSION['erro'] = "Produto inválido.";
    header('Location: ../carrinho.php');
    exit;
}

if ($quantity < 1) {
    $_SESSION['erro'] = "Quantidade inválida.";
    header('Location: ../carrinho.php');
    exit;
}

try {
    // Verificar estoque
    $sql = "SELECT estoque FROM produtos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $produto = $result->fetch_assoc();
    
    if (!$produto) {
        throw new Exception("Produto não encontrado.");
    }
    
    if ($quantity > $produto['estoque']) {
        throw new Exception("Quantidade solicitada indisponível. Disponível: " . $produto['estoque']);
    }
    
    // Atualizar quantidade no carrinho
    if (isset($_SESSION['carrinho'][$product_id])) {
        $_SESSION['carrinho'][$product_id]['quantidade'] = $quantity;
        $_SESSION['sucesso'] = "Quantidade atualizada!";
    } else {
        throw new Exception("Produto não encontrado no carrinho.");
    }
    
} catch (Exception $e) {
    $_SESSION['erro'] = $e->getMessage();
}

header('Location: ../carrinho.php');
exit;
?>