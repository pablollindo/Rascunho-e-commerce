<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para ver seus tickets.";
    header("Location: login.php");
    exit;
}
?>

<?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="display-5 fw-bold text-primary">
                        <i class="fas fa-ticket-alt me-3"></i>
                        Meus Tickets de Suporte
                    </h1>
                    <a href="suporte.php" class="btn btn-primary btn-lg">
                        <i class="fas fa-plus me-2"></i>
                        Novo Ticket
                    </a>
                </div>

                <?php mostrarMensagem(); ?>

                <div class="card">
                    <div class="card-header bg-light">
                        <h5 class="mb-0">
                            <i class="fas fa-list me-2"></i>
                            Histórico de Tickets
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php
                        try {
                            $pdo = conectarBanco();
                            $usuario_id = $_SESSION['usuario_id'];
                            
                            $sql = "SELECT ts.*, 
                                   COUNT(ms.id) as total_mensagens,
                                   MAX(ms.data_envio) as ultima_resposta
                            FROM tickets_suporte ts
                            LEFT JOIN mensagens_suporte ms ON ts.id = ms.ticket_id
                            WHERE ts.usuario_id = ?
                            GROUP BY ts.id
                            ORDER BY ts.data_abertura DESC";
                            
                            $stmt = $pdo->prepare($sql);
                            $stmt->execute([$usuario_id]);
                            $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
                            
                            if (count($tickets) > 0): ?>
                                <div class="table-responsive">
                                    <table class="table table-hover">
                                        <thead>
                                            <tr>
                                                <th>Ticket #</th>
                                                <th>Assunto</th>
                                                <th>Categoria</th>
                                                <th>Status</th>
                                                <th>Prioridade</th>
                                                <th>Data Abertura</th>
                                                <th>Mensagens</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($tickets as $ticket): ?>
                                            <tr>
                                                <td><strong>#<?= $ticket['id'] ?></strong></td>
                                                <td><?= htmlspecialchars($ticket['assunto']) ?></td>
                                                <td>
                                                    <span class="badge bg-secondary">
                                                        <?= ucfirst($ticket['categoria']) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php
                                                    $status_class = [
                                                        'aberto' => 'bg-success',
                                                        'em_andamento' => 'bg-warning',
                                                        'respondido' => 'bg-info',
                                                        'fechado' => 'bg-secondary'
                                                    ];
                                                    ?>
                                                    <span class="badge <?= $status_class[$ticket['status']] ?? 'bg-secondary' ?>">
                                                        <?= ucfirst(str_replace('_', ' ', $ticket['status'])) ?>
                                                    </span>
                                                </td>
                                                <td>
                                                    <?php
                                                    $prioridade_class = [
                                                        'baixa' => 'bg-secondary',
                                                        'media' => 'bg-info',
                                                        'alta' => 'bg-warning',
                                                        'urgente' => 'bg-danger'
                                                    ];
                                                    ?>
                                                    <span class="badge <?= $prioridade_class[$ticket['prioridade']] ?? 'bg-secondary' ?>">
                                                        <?= ucfirst($ticket['prioridade']) ?>
                                                    </span>
                                                </td>
                                                <td><?= date('d/m/Y H:i', strtotime($ticket['data_abertura'])) ?></td>
                                                <td><?= $ticket['total_mensagens'] ?></td>
                                                <td>
                                                    <a href="ver_ticket.php?id=<?= $ticket['id'] ?>" class="btn btn-sm btn-outline-primary">
                                                        <i class="fas fa-eye me-1"></i>
                                                        Ver
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                            <?php else: ?>
                                <div class="text-center py-5">
                                    <i class="fas fa-inbox fa-4x text-muted mb-3"></i>
                                    <h4 class="text-muted">Nenhum ticket encontrado</h4>
                                    <p class="text-muted">Você ainda não abriu nenhum ticket de suporte.</p>
                                    <a href="suporte.php" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>
                                        Abrir Primeiro Ticket
                                    </a>
                                </div>
                            <?php endif;
                            
                        } catch (PDOException $e) {
                            echo '<div class="alert alert-danger">Erro ao carregar tickets: ' . $e->getMessage() . '</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

<?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>