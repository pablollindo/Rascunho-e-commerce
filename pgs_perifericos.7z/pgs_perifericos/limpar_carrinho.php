<?php
session_start();
$_SESSION['carrinho'] = [];
echo "Carrinho limpo!";
header("Location: indexx.php");
exit;
?>