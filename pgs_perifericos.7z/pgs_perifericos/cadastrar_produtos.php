<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se é admin/funcionário
if (!isFuncionario()) {
    $_SESSION['erro'] = "Acesso restrito à administração.";
    header("Location: ../indexx.php");
    exit;
}

// Dados dos produtos para cadastrar
$produtos = [
    // TECLADOS (2 produtos)
    [
        'categoria_id' => 1,
        'marca_id' => 1,
        'nome' => 'Teclado Mecânico Gamer Redragon Kumara RGB',
        'descricao' => 'Teclado mecânico gamer com switches Outemu Brown, iluminação RGB personalizável e design robusto. Ideal para jogos e trabalho.',
        'especificacoes' => "Switches Outemu Brown\nLayout ABNT2\nAnti-ghosting N-Key Rollover\nIluminação RGB\nConstrução em ABS",
        'preco' => 249.90,
        'preco_promocional' => 199.90,
        'estoque' => 15,
        'garantia_meses' => 12,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 1,
        'marca_id' => 3,
        'nome' => 'Teclado Mecânico Gamer HyperX Alloy Origins Core',
        'descricao' => 'Teclado mecânico compacto com switches HyperX Red, estrutura em alumínio e iluminação RGB vibrante.',
        'especificacoes' => "Switches HyperX Red\nLayout Tenkeyless\nEstrutura em alumínio\nIluminação RGB dinâmica",
        'preco' => 499.90,
        'preco_promocional' => 449.90,
        'estoque' => 8,
        'garantia_meses' => 24,
        'em_destaque' => 1,
        'em_promocao' => 0
    ],
    
    // MOUSES (2 produtos)
    [
        'categoria_id' => 2,
        'marca_id' => 2,
        'nome' => 'Mouse Gamer Logitech G502 HERO',
        'descricao' => 'Mouse gamer de alto desempenho com sensor HERO 25K DPI e 11 botões programáveis.',
        'especificacoes' => "Sensor HERO 25K DPI\n11 botões programáveis\nPesos ajustáveis\nIluminação RGB",
        'preco' => 349.90,
        'preco_promocional' => 299.90,
        'estoque' => 12,
        'garantia_meses' => 24,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 2,
        'marca_id' => 5,
        'nome' => 'Mouse Gamer Razer DeathAdder V2',
        'descricao' => 'Mouse gamer ergonômico com sensor óptico Focus+ 20K DPI e switches ópticos Razer.',
        'especificacoes' => "Sensor Focus+ 20K DPI\nSwitches ópticos Razer\n8 botões programáveis\nDesign ergonômico",
        'preco' => 299.90,
        'preco_promocional' => 259.90,
        'estoque' => 10,
        'garantia_meses' => 24,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    
    // HEADSETS (2 produtos)
    [
        'categoria_id' => 3,
        'marca_id' => 3,
        'nome' => 'Headset Gamer HyperX Cloud Stinger',
        'descricao' => 'Headset gamer leve e confortável com drivers de 50mm e microfone com cancelamento de ruído.',
        'especificacoes' => "Drivers 50mm\nMicrofone giratório\nControles de áudio no fone\nPeso: 275g",
        'preco' => 199.90,
        'preco_promocional' => 169.90,
        'estoque' => 20,
        'garantia_meses' => 12,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 3,
        'marca_id' => 2,
        'nome' => 'Headset Gamer Logitech G432 7.1',
        'descricao' => 'Headset com som surround DTS 7.1 e drivers de 50mm para imersão total em jogos.',
        'especificacoes' => "Som DTS 7.1\nDrivers 50mm\nMicrofone flip-to-mute\nCompatível multiplataforma",
        'preco' => 299.90,
        'preco_promocional' => 249.90,
        'estoque' => 15,
        'garantia_meses' => 24,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    
    // MONITORES (2 produtos)
    [
        'categoria_id' => 4,
        'marca_id' => 8, // ASUS
        'nome' => 'Monitor Gamer AOC 24G2SE 24"',
        'descricao' => 'Monitor gamer 24" Full HD com 144Hz e 1ms para jogos competitivos.',
        'especificacoes' => "24\" Full HD\n144Hz\n1ms\nFreeSync\nPainel VA",
        'preco' => 899.90,
        'preco_promocional' => 799.90,
        'estoque' => 6,
        'garantia_meses' => 36,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 4,
        'marca_id' => 8,
        'nome' => 'Monitor Gamer ASUS TUF VG279Q 27"',
        'descricao' => 'Monitor IPS 27" com 144Hz e tecnologia Adaptive-Sync para jogos fluidos.',
        'especificacoes' => "27\" Full HD\n144Hz\n1ms\nIPS\nAdaptive-Sync",
        'preco' => 1499.90,
        'preco_promocional' => 1299.90,
        'estoque' => 4,
        'garantia_meses' => 36,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    
    // MOUSEPADS (2 produtos)
    [
        'categoria_id' => 5,
        'marca_id' => 1,
        'nome' => 'Mousepad Gamer Redragon Flick P027',
        'descricao' => 'Mousepad gamer de tecido com base antiderrapante e bordas costuradas.',
        'especificacoes' => "800x300mm\nEspessura 3mm\nBase de borracha\nBordas costuradas",
        'preco' => 49.90,
        'preco_promocional' => 39.90,
        'estoque' => 30,
        'garantia_meses' => 6,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 5,
        'marca_id' => 2,
        'nome' => 'Mousepad Gamer Logitech G240',
        'descricao' => 'Mousepad de alto desempenho com superfície otimizada para sensores ópticos.',
        'especificacoes' => "340x280mm\nSuperfície de tecido\nBase de borracha\nFino e portátil",
        'preco' => 79.90,
        'preco_promocional' => 69.90,
        'estoque' => 25,
        'garantia_meses' => 12,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    
    // WEBCAMS (2 produtos)
    [
        'categoria_id' => 6,
        'marca_id' => 2,
        'nome' => 'Webcam Logitech C920x HD Pro',
        'descricao' => 'Webcam Full HD 1080p com autofoco e microfone stereo integrado.',
        'especificacoes' => "Full HD 1080p\nAutofoco\nMicrofone stereo\nCompatível com Skype, Zoom",
        'preco' => 399.90,
        'preco_promocional' => 349.90,
        'estoque' => 8,
        'garantia_meses' => 24,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 6,
        'marca_id' => 1,
        'nome' => 'Webcam Gamer Redragon Fobos GW800',
        'descricao' => 'Webcam gamer 1080p com microfone com redução de ruído e iluminação ajustável.',
        'especificacoes' => "Full HD 1080p\nMicrofone com noise reduction\nIluminação ajustável\nClip universal",
        'preco' => 199.90,
        'preco_promocional' => 169.90,
        'estoque' => 12,
        'garantia_meses' => 12,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    
    // MICROFONES (2 produtos)
    [
        'categoria_id' => 7,
        'marca_id' => 3,
        'nome' => 'Microfone HyperX QuadCast',
        'descricao' => 'Microfone condenser USB com quatro padrões polares e anti-vibração integrado.',
        'especificacoes' => "Condenser USB\n4 padrões polares\nAnti-vibração\nLED personalizável",
        'preco' => 699.90,
        'preco_promocional' => 599.90,
        'estoque' => 5,
        'garantia_meses' => 24,
        'em_destaque' => 1,
        'em_promocao' => 1
    ],
    [
        'categoria_id' => 7,
        'marca_id' => 1,
        'nome' => 'Microfone Gamer Redragon Blazar GM300',
        'descricao' => 'Microfone USB plug-and-play com padrão cardioide e controle de ganho.',
        'especificacoes' => "Padrão cardioide\nControle de ganho\nBase ajustável\nPlug-and-play",
        'preco' => 299.90,
        'preco_promocional' => 249.90,
        'estoque' => 10,
        'garantia_meses' => 12,
        'em_destaque' => 1,
        'em_promocao' => 1
    ]
];

try {
    $pdo = conectarBanco();
    $pdo->beginTransaction();
    
    $produtos_cadastrados = 0;
    $errors = [];
    
    foreach ($produtos as $produto) {
        // Verificar se produto já existe (pelo nome)
        $sql_check = "SELECT id FROM produtos WHERE nome = ?";
        $stmt_check = $pdo->prepare($sql_check);
        $stmt_check->execute([$produto['nome']]);
        
        if ($stmt_check->fetch()) {
            $errors[] = "Produto '{$produto['nome']}' já existe";
            continue;
        }
        
        // Inserir produto
        $sql = "INSERT INTO produtos (categoria_id, marca_id, nome, descricao, especificacoes, preco, preco_promocional, estoque, garantia_meses, em_destaque, em_promocao, ativo) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
        
        $stmt = $pdo->prepare($sql);
        $success = $stmt->execute([
            $produto['categoria_id'],
            $produto['marca_id'],
            $produto['nome'],
            $produto['descricao'],
            $produto['especificacoes'],
            $produto['preco'],
            $produto['preco_promocional'],
            $produto['estoque'],
            $produto['garantia_meses'],
            $produto['em_destaque'],
            $produto['em_promocao']
        ]);
        
        if ($success) {
            $produtos_cadastrados++;
        } else {
            $errors[] = "Erro ao cadastrar: {$produto['nome']}";
        }
    }
    
    $pdo->commit();
    
    // Mensagem de resultado
    if ($produtos_cadastrados > 0) {
        $_SESSION['sucesso'] = "$produtos_cadastrados produtos cadastrados com sucesso!";
    }
    if (!empty($errors)) {
        $_SESSION['erro'] = "Alguns erros ocorreram: " . implode(', ', $errors);
    }
    
} catch (PDOException $e) {
    $pdo->rollBack();
    $_SESSION['erro'] = "Erro ao cadastrar produtos: " . $e->getMessage();
}

header("Location: admin/admin_produtos.php");
exit;
?>