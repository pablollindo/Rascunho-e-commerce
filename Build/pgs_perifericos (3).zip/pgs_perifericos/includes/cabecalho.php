<?php
// Iniciar sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Funções auxiliares (certifique-se que existem no seu código)
function usuarioEstaLogado() {
    return isset($_SESSION['usuario_id']);
}

function isFuncionario() {
    return isset($_SESSION['usuario_tipo']) && ($_SESSION['usuario_tipo'] === 'admin' || $_SESSION['usuario_tipo'] === 'funcionario');
}

function mostrarMensagem() {
    if (isset($_SESSION['mensagem'])) {
        echo '<div class="alert alert-' . $_SESSION['mensagem_tipo'] . ' alert-dismissible fade show" role="alert">
                ' . $_SESSION['mensagem'] . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
              </div>';
        unset($_SESSION['mensagem']);
        unset($_SESSION['mensagem_tipo']);
    }
}
?>

<!-- Header -->
<header class="bg-dark text-white sticky-top">
    <div class="container">
        <div class="row align-items-center py-2">
            <!-- Logo -->
            <div class="col-md-3">
                <a href="index.php" class="text-decoration-none">
                    <h3 class="text-warning mb-0">
                        <i class="fas fa-gamepad me-2"></i>
                        PGS Periféricos
                    </h3>
                </a>
            </div>

            <!-- Barra de Pesquisa -->
            <div class="col-md-4">
                <form action="produtos.php" method="GET" class="d-flex">
                    <div class="input-group">
                        <input type="text" class="form-control" name="busca" placeholder="Buscar produtos..." 
                               value="<?php echo isset($_GET['busca']) ? htmlspecialchars($_GET['busca']) : ''; ?>">
                        <button class="btn btn-warning" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </form>
            </div>

            <!-- Menu Usuário -->
            <div class="col-md-5">
                <div class="d-flex justify-content-end align-items-center gap-3">
                    <!-- Lista de Desejos -->
                    <?php if (usuarioEstaLogado() && $_SESSION['usuario_tipo'] === 'cliente'): ?>
                        <a href="lista_desejos.php" class="text-white text-decoration-none" title="Lista de Desejos">
                            <i class="fas fa-heart me-1"></i>
                            <span class="d-none d-md-inline">Desejos</span>
                        </a>
                    <?php endif; ?>

                    <!-- Botão Admin para funcionários -->
                    <?php if (isFuncionario()): ?>
                        <a href="admin/admin.php" class="text-white text-decoration-none" title="Painel Administrativo">
                            <i class="fas fa-cog me-1"></i>
                            <span class="d-none d-md-inline">Admin</span>
                        </a>
                    <?php endif; ?>

                    <!-- Carrinho -->
                    <a href="carrinho.php" class="text-white text-decoration-none position-relative" title="Carrinho de Compras">
                        <i class="fas fa-shopping-cart me-1"></i>
                        <span class="d-none d-md-inline">Carrinho</span>
                        <?php 
                        $carrinhoCount = 0;
                        if (isset($_SESSION['carrinho']) && is_array($_SESSION['carrinho'])) {
                            $carrinhoCount = count($_SESSION['carrinho']);
                        }
                        if ($carrinhoCount > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark">
                                <?php echo $carrinhoCount; ?>
                            </span>
                        <?php endif; ?>
                    </a>

                    <!-- Menu do Usuário -->
                    <?php if (usuarioEstaLogado()): ?>
                        <div class="dropdown">
                            <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i>
                                <?php echo explode(' ', $_SESSION['usuario_nome'])[0]; ?>
                            </button>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <li>
                                    <a class="dropdown-item" href="minha_conta.php">
                                        <i class="fas fa-user-circle me-2"></i>Meu Perfil
                                    </a>
                                </li>
                                
                                <?php if ($_SESSION['usuario_tipo'] === 'cliente'): ?>
                                    <li>
                                        <a class="dropdown-item" href="meus_pedidos.php">
                                            <i class="fas fa-shopping-bag me-2"></i>Meus Pedidos
                                        </a>
                                    </li>
                                    <li>
                                        <a class="dropdown-item" href="lista_desejos.php">
                                            <i class="fas fa-heart me-2"></i>Lista de Desejos
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <?php if (isFuncionario()): ?>
                                    <li>
                                        <a class="dropdown-item" href="admin/admin.php">
                                            <i class="fas fa-cog me-2"></i>Painel Admin
                                        </a>
                                    </li>
                                <?php endif; ?>

                                <li><hr class="dropdown-divider"></li>
                                
                                <li>
                                    <a class="dropdown-item" href="suporte.php">
                                        <i class="fas fa-headset me-2"></i>Suporte
                                    </a>
                                </li>
                                
                                <li>
                                    <a class="dropdown-item text-danger" href="includes/logout.php">
                                        <i class="fas fa-sign-out-alt me-2"></i>Sair
                                    </a>
                                </li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <!-- Usuário não logado -->
                        <a href="login.php" class="btn btn-outline-light">
                            <i class="fas fa-sign-in-alt me-1"></i>
                            Entrar
                        </a>
                        <a href="cadastro.php" class="btn btn-warning">
                            <i class="fas fa-user-plus me-1"></i>
                            Cadastrar
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu de Navegação -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home me-1"></i>Início
                        </a>
                    </li>
                    
                    <!-- Categorias sem dropdown -->
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=1">
                            <i class="fas fa-keyboard me-1"></i>Teclados
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=2">
                            <i class="fas fa-mouse me-1"></i>Mouses
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=3">
                            <i class="fas fa-headphones me-1"></i>Headsets
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=4">
                            <i class="fas fa-desktop me-1"></i>Monitores
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=5">
                            <i class="fas fa-mouse-pointer me-1"></i>Mousepads
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=6">
                            <i class="fas fa-video me-1"></i>Webcams
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=7">
                            <i class="fas fa-microphone me-1"></i>Microfones
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?promocao=1">
                            <i class="fas fa-tag me-1"></i>Promoções
                        </a>
                    </li>
                    
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?destaque=1">
                            <i class="fas fa-star me-1"></i>Destaques
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<?php mostrarMensagem(); ?>