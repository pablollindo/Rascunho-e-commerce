<!-- Footer -->
<footer class="bg-dark text-white py-5">
    <div class="container">
        <div class="row">
            <div class="col-md-4 mb-4">
                <h5 class="text-warning">
                    <i class="fas fa-gamepad me-2"></i>
                    PGS Periféricos
                </h5>
                <p class="text-light">Sua loja de confiança para periféricos gamers de alta qualidade.</p>
                <div class="social-links">
                    <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                    <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                    <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                    <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                </div>
            </div>
            <div class="col-md-2 mb-4">
                <h6 class="text-warning">INSTITUCIONAL</h6>
                <ul class="list-unstyled">
                    <li><a href="#" class="text-light text-decoration-none">Sobre Nós</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Nossas Lojas</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Trabalhe Conosco</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Política de Privacidade</a></li>
                </ul>
            </div>
            <div class="col-md-2 mb-4">
                <h6 class="text-warning">ATENDIMENTO</h6>
                <ul class="list-unstyled">
                    <li><a href="faq.php" class="text-light text-decoration-none">FAQ</a></li>
                    <li><a href="suporte.php" class="text-light text-decoration-none">Fale Conosco</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Troca e Devolução</a></li>
                    <li><a href="#" class="text-light text-decoration-none">Formas de Pagamento</a></li>
                </ul>
            </div>
            <div class="col-md-4 mb-4">
                <h6 class="text-warning">NEWSLETTER</h6>
                <p class="text-light">Cadastre-se e receba ofertas exclusivas!</p>
                <div class="input-group">
                    <input type="email" class="form-control" placeholder="Seu e-mail">
                    <button class="btn btn-warning">Cadastrar</button>
                </div>
            </div>
        </div>
        <hr class="bg-secondary">
        <div class="row">
            <div class="col-md-6">
                <p class="mb-0 text-light">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
            </div>
            <div class="col-md-6 text-end">
                <span class="text-light me-2">Formas de pagamento:</span>
                <i class="fab fa-cc-visa text-light me-2 fa-lg"></i>
                <i class="fab fa-cc-mastercard text-light me-2 fa-lg"></i>
                <i class="fab fa-cc-paypal text-light me-2 fa-lg"></i>
            </div>
        </div>
    </div>
</footer>