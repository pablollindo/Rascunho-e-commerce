<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Simples Teste - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <h2>🎯 CADASTRO TESTE SIMPLES</h2>
                <p class="text-muted">Versão sem validações - só para testar envio</p>
                
                <?php mostrarMensagem(); ?>
                
                <form method="POST" action="processa_simples.php">
                    <div class="mb-3">
                        <label class="form-label">Nome *</label>
                        <input type="text" class="form-control" name="nome" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Email *</label>
                        <input type="email" class="form-control" name="email" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Senha *</label>
                        <input type="password" class="form-control" name="senha" required>
                    </div>
                    
                    <div class="mb-3">
                        <label class="form-label">Tipo</label>
                        <select class="form-select" name="tipo_cadastro">
                            <option value="cliente">Cliente</option>
                            <option value="funcionario">Funcionário</option>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn btn-success w-100">
                        📨 TESTAR ENVIO
                    </button>
                </form>
                
                <div class="mt-3 text-center">
                    <a href="cadastro.php" class="btn btn-outline-secondary btn-sm">
                        ← Voltar para cadastro normal
                    </a>
                </div>
            </div>
        </div>
    </div>
</body>
</html>