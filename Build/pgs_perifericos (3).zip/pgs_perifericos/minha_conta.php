<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para acessar sua conta.";
    redirecionar('login.php');
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];

// Buscar dados do usuário
$usuario = [];
$dados_funcionario = [];
$enderecos = [];
$pedidos = [];

try {
    // Buscar dados básicos do usuário
    if ($usuario_tipo === 'cliente') {
        $sql_usuario = "SELECT u.*, c.cpf, c.telefone, c.data_nascimento 
                        FROM usuarios u 
                        LEFT JOIN clientes c ON u.id = c.usuario_id 
                        WHERE u.id = ?";
    } else {
        // Para funcionários e admin, buscar da tabela usuarios
        $sql_usuario = "SELECT u.*, f.cpf, f.telefone, f.data_nascimento 
                        FROM usuarios u 
                        LEFT JOIN funcionarios f ON u.id = f.usuario_id 
                        WHERE u.id = ?";
    }
    
    $stmt = $conn->prepare($sql_usuario);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    // Se for funcionário, buscar dados profissionais
    if ($usuario_tipo === 'funcionario' || $usuario_tipo === 'admin') {
        $sql_funcionario = "SELECT * FROM funcionarios WHERE usuario_id = ?";
        $stmt = $conn->prepare($sql_funcionario);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $dados_funcionario = $result->fetch_assoc();
        
        // Se não encontrou dados na tabela funcionarios, usar dados da tabela usuarios
        if (!$dados_funcionario) {
            $dados_funcionario = [
                'cargo' => $usuario_tipo === 'admin' ? 'administrador' : 'gerente',
                'departamento' => 'Administração',
                'data_admissao' => $usuario['data_cadastro'] ?? date('Y-m-d'),
                'matricula' => 'PG001'
            ];
        }
    }

    // Buscar endereços (apenas para clientes)
    if ($usuario_tipo === 'cliente') {
        $sql_enderecos = "SELECT * FROM enderecos WHERE usuario_id = ? ORDER BY principal DESC, id ASC";
        $stmt = $conn->prepare($sql_enderecos);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $enderecos = $result->fetch_all(MYSQLI_ASSOC);
    }

    // Buscar pedidos do usuário
    $sql_pedidos = "SELECT p.*, COUNT(i.id) as total_itens 
                    FROM pedidos p 
                    LEFT JOIN itens_pedido i ON p.id = i.pedido_id 
                    WHERE p.cliente_id = ? 
                    GROUP BY p.id 
                    ORDER BY p.data_pedido DESC 
                    LIMIT 10";
    $stmt = $conn->prepare($sql_pedidos);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $pedidos = $result->fetch_all(MYSQLI_ASSOC);

} catch (Exception $e) {
    $_SESSION['erro'] = "Erro ao carregar dados: " . $e->getMessage();
}

// Processar alteração de senha
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['alterar_senha'])) {
    $senha_atual = $_POST['senha_atual'] ?? '';
    $nova_senha = $_POST['nova_senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';

    if (empty($senha_atual) || empty($nova_senha) || empty($confirmar_senha)) {
        $_SESSION['erro'] = "Todos os campos são obrigatórios.";
    } elseif ($nova_senha !== $confirmar_senha) {
        $_SESSION['erro'] = "As novas senhas não coincidem.";
    } elseif (strlen($nova_senha) < 6) {
        $_SESSION['erro'] = "A nova senha deve ter pelo menos 6 caracteres.";
    } else {
        // Verificar senha atual
        $sql_verificar = "SELECT senha FROM usuarios WHERE id = ?";
        $stmt = $conn->prepare($sql_verificar);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $usuario_db = $result->fetch_assoc();

        if (password_verify($senha_atual, $usuario_db['senha'])) {
            // Atualizar senha
            $nova_senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
            $sql_atualizar = "UPDATE usuarios SET senha = ? WHERE id = ?";
            $stmt = $conn->prepare($sql_atualizar);
            $stmt->bind_param("si", $nova_senha_hash, $usuario_id);

            if ($stmt->execute()) {
                $_SESSION['sucesso'] = "Senha alterada com sucesso!";
            } else {
                $_SESSION['erro'] = "Erro ao alterar senha. Tente novamente.";
            }
        } else {
            $_SESSION['erro'] = "Senha atual incorreta.";
        }
    }
    
    // Recarregar a página para mostrar mensagem
    redirecionar('minha_conta.php');
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Conta - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/formularios.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>
                <div class="col-md-8 text-center">
                    <h5 class="mb-0">Minha Conta</h5>
                </div>
                <div class="col-md-2 text-end">
                    <a href="indexx.php" class="btn btn-outline-warning btn-sm">
                        <i class="fas fa-home me-1"></i>Voltar
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-user-circle text-primary me-2"></i>
                        Minha Conta
                    </h1>
                    <div class="badge bg-<?php echo $usuario_tipo === 'admin' ? 'danger' : ($usuario_tipo === 'funcionario' ? 'success' : 'primary'); ?>">
                        <i class="fas fa-<?php echo $usuario_tipo === 'admin' ? 'crown' : ($usuario_tipo === 'funcionario' ? 'user-tie' : 'user'); ?> me-1"></i>
                        <?php echo ucfirst($usuario_tipo); ?>
                    </div>
                </div>

                <!-- Mensagens -->
                <?php mostrarMensagem(); ?>

                <div class="row">
                    <!-- Menu Lateral -->
                    <div class="col-md-3 mb-4">
                        <div class="card shadow-sm">
                            <div class="card-header bg-primary text-white">
                                <h6 class="mb-0">
                                    <i class="fas fa-cog me-2"></i>
                                    Menu
                                </h6>
                            </div>
                            <div class="list-group list-group-flush">
                                <a href="#dados-pessoais" class="list-group-item list-group-item-action active" data-bs-toggle="list">
                                    <i class="fas fa-user me-2"></i>Dados Pessoais
                                </a>
                                <a href="#alterar-senha" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                    <i class="fas fa-lock me-2"></i>Alterar Senha
                                </a>
                                <?php if ($usuario_tipo === 'cliente'): ?>
                                    <a href="#enderecos" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                        <i class="fas fa-map-marker-alt me-2"></i>Meus Endereços
                                    </a>
                                    <a href="#pedidos" class="list-group-item list-group-item-action" data-bs-toggle="list">
                                        <i class="fas fa-shopping-bag me-2"></i>Meus Pedidos
                                    </a>
                                <?php endif; ?>
                                <?php if (isFuncionario()): ?>
                                    <a href="admin/admin.php" class="list-group-item list-group-item-action">
                                        <i class="fas fa-cog me-2"></i>Painel Admin
                                    </a>
                                <?php endif; ?>
                                <a href="includes/logout.php" class="list-group-item list-group-item-action text-danger">
                                    <i class="fas fa-sign-out-alt me-2"></i>Sair
                                </a>
                            </div>
                        </div>
                    </div>

                    <!-- Conteúdo -->
                    <div class="col-md-9">
                        <div class="tab-content">
                            <!-- Dados Pessoais -->
                            <div class="tab-pane fade show active" id="dados-pessoais">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-primary text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-user me-2"></i>
                                            Dados Pessoais
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Nome Completo</label>
                                                <p class="form-control-plaintext"><?php echo htmlspecialchars($usuario['nome'] ?? 'Não informado'); ?></p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Email</label>
                                                <p class="form-control-plaintext"><?php echo htmlspecialchars($usuario['email'] ?? 'Não informado'); ?></p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">CPF</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['cpf'])) {
                                                        echo htmlspecialchars($usuario['cpf']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Telefone</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['telefone'])) {
                                                        echo htmlspecialchars($usuario['telefone']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>

                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Data de Nascimento</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['data_nascimento']) && $usuario['data_nascimento'] != '0000-00-00') {
                                                        echo date('d/m/Y', strtotime($usuario['data_nascimento']));
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Data de Cadastro</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($usuario['data_cadastro'])) {
                                                        echo date('d/m/Y H:i', strtotime($usuario['data_cadastro']));
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>

                                        <!-- Dados Profissionais (Funcionários) -->
                                        <?php if ($usuario_tipo === 'funcionario' || $usuario_tipo === 'admin'): ?>
                                        <hr>
                                        <h6 class="text-success mb-3">
                                            <i class="fas fa-briefcase me-2"></i>
                                            Dados Profissionais
                                        </h6>
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Cargo</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['cargo'])) {
                                                        echo ucfirst($dados_funcionario['cargo']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Departamento</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['departamento'])) {
                                                        echo ucfirst($dados_funcionario['departamento']);
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Data de Admissão</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['data_admissao']) && $dados_funcionario['data_admissao'] != '0000-00-00') {
                                                        echo date('d/m/Y', strtotime($dados_funcionario['data_admissao']));
                                                    } else {
                                                        echo 'Não informado';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label class="form-label fw-bold">Matrícula</label>
                                                <p class="form-control-plaintext">
                                                    <?php 
                                                    if (!empty($dados_funcionario['matricula'])) {
                                                        echo htmlspecialchars($dados_funcionario['matricula']);
                                                    } else {
                                                        echo 'Não informada';
                                                    }
                                                    ?>
                                                </p>
                                            </div>
                                        </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Alterar Senha -->
                            <div class="tab-pane fade" id="alterar-senha">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-warning text-dark">
                                        <h5 class="mb-0">
                                            <i class="fas fa-lock me-2"></i>
                                            Alterar Senha
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST" action="">
                                            <div class="row">
                                                <div class="col-md-12 mb-3">
                                                    <label for="senha_atual" class="form-label">
                                                        <i class="fas fa-key me-1"></i>Senha Atual *
                                                    </label>
                                                    <input type="password" class="form-control" id="senha_atual" name="senha_atual" required
                                                           placeholder="Digite sua senha atual">
                                                </div>
                                            </div>

                                            <div class="row">
                                                <div class="col-md-6 mb-3">
                                                    <label for="nova_senha" class="form-label">
                                                        <i class="fas fa-lock me-1"></i>Nova Senha *
                                                    </label>
                                                    <input type="password" class="form-control" id="nova_senha" name="nova_senha" required
                                                           placeholder="Mínimo 6 caracteres">
                                                    <small class="form-text text-muted">Mínimo 6 caracteres</small>
                                                </div>
                                                
                                                <div class="col-md-6 mb-3">
                                                    <label for="confirmar_senha" class="form-label">
                                                        <i class="fas fa-lock me-1"></i>Confirmar Nova Senha *
                                                    </label>
                                                    <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" required
                                                           placeholder="Digite a nova senha novamente">
                                                </div>
                                            </div>

                                            <div class="d-grid">
                                                <button type="submit" name="alterar_senha" class="btn btn-warning btn-lg">
                                                    <i class="fas fa-save me-2"></i>
                                                    Alterar Senha
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <!-- Endereços (Clientes) -->
                            <?php if ($usuario_tipo === 'cliente'): ?>
                            <div class="tab-pane fade" id="enderecos">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-info text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-map-marker-alt me-2"></i>
                                            Meus Endereços
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($enderecos)): ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-map-marker-alt fa-3x text-muted mb-3"></i>
                                                <h5 class="text-muted">Nenhum endereço cadastrado</h5>
                                                <p class="text-muted">Você ainda não cadastrou nenhum endereço.</p>
                                                <a href="cadastro.php?editar=endereco" class="btn btn-primary">
                                                    <i class="fas fa-plus me-2"></i>Cadastrar Endereço
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="row">
                                                <?php foreach ($enderecos as $endereco): ?>
                                                <div class="col-md-6 mb-3">
                                                    <div class="card h-100 <?php echo $endereco['principal'] ? 'border-primary' : ''; ?>">
                                                        <div class="card-body">
                                                            <?php if ($endereco['principal']): ?>
                                                                <span class="badge bg-primary mb-2">
                                                                    <i class="fas fa-star me-1"></i>Principal
                                                                </span>
                                                            <?php endif; ?>
                                                            <h6 class="card-title"><?php echo htmlspecialchars($endereco['titulo']); ?></h6>
                                                            <p class="card-text small mb-1">
                                                                <?php echo htmlspecialchars($endereco['logradouro']); ?>, 
                                                                <?php echo htmlspecialchars($endereco['numero']); ?>
                                                                <?php if (!empty($endereco['complemento'])): ?>
                                                                    - <?php echo htmlspecialchars($endereco['complemento']); ?>
                                                                <?php endif; ?>
                                                            </p>
                                                            <p class="card-text small mb-1">
                                                                <?php echo htmlspecialchars($endereco['bairro']); ?> - 
                                                                <?php echo htmlspecialchars($endereco['cidade']); ?>/<?php echo htmlspecialchars($endereco['estado']); ?>
                                                            </p>
                                                            <p class="card-text small text-muted">
                                                                CEP: <?php echo htmlspecialchars($endereco['cep']); ?>
                                                            </p>
                                                        </div>
                                                    </div>
                                                </div>
                                                <?php endforeach; ?>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>

                            <!-- Pedidos (Clientes) -->
                            <div class="tab-pane fade" id="pedidos">
                                <div class="card shadow-sm">
                                    <div class="card-header bg-success text-white">
                                        <h5 class="mb-0">
                                            <i class="fas fa-shopping-bag me-2"></i>
                                            Meus Pedidos
                                        </h5>
                                    </div>
                                    <div class="card-body">
                                        <?php if (empty($pedidos)): ?>
                                            <div class="text-center py-4">
                                                <i class="fas fa-shopping-bag fa-3x text-muted mb-3"></i>
                                                <h5 class="text-muted">Nenhum pedido realizado</h5>
                                                <p class="text-muted">Você ainda não fez nenhum pedido em nossa loja.</p>
                                                <a href="produtos.php" class="btn btn-success">
                                                    <i class="fas fa-shopping-cart me-2"></i>Fazer Compras
                                                </a>
                                            </div>
                                        <?php else: ?>
                                            <div class="table-responsive">
                                                <table class="table table-striped">
                                                    <thead>
                                                        <tr>
                                                            <th>Nº Pedido</th>
                                                            <th>Data</th>
                                                            <th>Total</th>
                                                            <th>Status</th>
                                                            <th>Ações</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php foreach ($pedidos as $pedido): ?>
                                                        <tr>
                                                            <td>#<?php echo str_pad($pedido['id'], 6, '0', STR_PAD_LEFT); ?></td>
                                                            <td><?php echo date('d/m/Y H:i', strtotime($pedido['data_pedido'])); ?></td>
                                                            <td>R$ <?php echo number_format($pedido['total'], 2, ',', '.'); ?></td>
                                                            <td>
                                                                <span class="badge bg-<?php 
                                                                    switch($pedido['status']) {
                                                                        case 'pendente': echo 'warning'; break;
                                                                        case 'pago': echo 'info'; break;
                                                                        case 'processando': echo 'primary'; break;
                                                                        case 'enviado': echo 'success'; break;
                                                                        case 'entregue': echo 'success'; break;
                                                                        case 'cancelado': echo 'danger'; break;
                                                                        default: echo 'secondary';
                                                                    }
                                                                ?>">
                                                                    <?php echo ucfirst($pedido['status']); ?>
                                                                </span>
                                                            </td>
                                                            <td>
                                                                <a href="detalhes_pedido.php?id=<?php echo $pedido['id']; ?>" class="btn btn-sm btn-outline-primary">
                                                                    <i class="fas fa-eye me-1"></i>Ver
                                                                </a>
                                                            </td>
                                                        </tr>
                                                        <?php endforeach; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="suporte.php" class="text-white text-decoration-none me-3">
                        <i class="fas fa-headset me-1"></i>Suporte
                    </a>
                    <a href="faq.php" class="text-white text-decoration-none">
                        <i class="fas fa-question-circle me-1"></i>FAQ
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Ativar tabs
        document.addEventListener('DOMContentLoaded', function() {
            const triggerTabList = [].slice.call(document.querySelectorAll('a[data-bs-toggle="list"]'));
            triggerTabList.forEach(function (triggerEl) {
                const tabTrigger = new bootstrap.Tab(triggerEl);
                
                triggerEl.addEventListener('click', function (event) {
                    event.preventDefault();
                    tabTrigger.show();
                });
            });

            // Validação de senha
            const novaSenha = document.getElementById('nova_senha');
            const confirmarSenha = document.getElementById('confirmar_senha');

            function validarSenhas() {
                if (novaSenha.value !== confirmarSenha.value) {
                    confirmarSenha.classList.add('is-invalid');
                    confirmarSenha.classList.remove('is-valid');
                } else {
                    confirmarSenha.classList.remove('is-invalid');
                    confirmarSenha.classList.add('is-valid');
                }
            }

            if (novaSenha && confirmarSenha) {
                novaSenha.addEventListener('input', validarSenhas);
                confirmarSenha.addEventListener('input', validarSenhas);
            }
        });
    </script>
</body>
</html>