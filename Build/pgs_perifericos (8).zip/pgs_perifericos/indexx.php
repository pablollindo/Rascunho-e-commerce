<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Buscar produtos para as seções
try {
    $pdo = conectarBanco();
    
    // Produtos em destaque
    $sql_destaques = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
                     FROM produtos p 
                     LEFT JOIN categorias c ON p.categoria_id = c.id 
                     LEFT JOIN marcas m ON p.marca_id = m.id 
                     WHERE p.em_destaque = 1 AND p.ativo = 1 
                     ORDER BY p.data_cadastro DESC 
                     LIMIT 4";
    $produtos_destaque = $pdo->query($sql_destaques)->fetchAll(PDO::FETCH_ASSOC);
    
    // Se não houver produtos em destaque, buscar os mais recentes
    if (empty($produtos_destaque)) {
        $sql_destaques = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
                         FROM produtos p 
                         LEFT JOIN categorias c ON p.categoria_id = c.id 
                         LEFT JOIN marcas m ON p.marca_id = m.id 
                         WHERE p.ativo = 1 
                         ORDER BY p.data_cadastro DESC 
                         LIMIT 4";
        $produtos_destaque = $pdo->query($sql_destaques)->fetchAll(PDO::FETCH_ASSOC);
    }
    
    // Produtos em promoção
    $sql_promocao = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
                    FROM produtos p 
                    LEFT JOIN categorias c ON p.categoria_id = c.id 
                    LEFT JOIN marcas m ON p.marca_id = m.id 
                    WHERE p.em_promocao = 1 AND p.ativo = 1 AND p.estoque > 0
                    ORDER BY p.data_cadastro DESC 
                    LIMIT 3";
    $produtos_promocao = $pdo->query($sql_promocao)->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $produtos_destaque = [];
    $produtos_promocao = [];
    error_log("Erro ao carregar produtos: " . $e->getMessage());
}

// Função para calcular desconto
function calcularPercentualDesconto($precoOriginal, $precoPromocional) {
    if (!$precoPromocional || $precoPromocional >= $precoOriginal) {
        return 0;
    }
    $desconto = (($precoOriginal - $precoPromocional) / $precoOriginal) * 100;
    return round($desconto);
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PGS Periféricos - Loja de Periféricos Gamers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Barra de Pesquisa -->
                <div class="col-md-5">
                    <form method="GET" action="produtos.php" class="d-flex">
                        <input type="text" name="busca" class="form-control" placeholder="Buscar produtos...">
                        <button class="btn btn-warning ms-2" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>

                <!-- Menu Usuário -->
                <div class="col-md-5 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                            <a href="lista_desejos.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-heart me-1"></i>
                                Lista de Desejos
                                <span class="badge bg-danger" id="wishlist-count">0</span>
                            </a>
                            <!-- BOTÃO PAINEL ADMIN APENAS PARA FUNCIONÁRIOS -->
                            <?php if (isFuncionario()): ?>
                                <a href="admin/admin.php" class="text-white text-decoration-none me-3">
                                    <i class="fas fa-cog me-1"></i>
                                    Painel Admin
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <span class="badge bg-warning text-dark" id="cart-count">0</span>
                        </a>
                    </div>
                </div>
            </div>

            <!-- Menu de Navegação -->
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
                <div class="container">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav me-auto">
                            <li class="nav-item">
                                <a class="nav-link active" href="indexx.php">
                                    <i class="fas fa-home me-1"></i>Início
                                </a>
                            </li>
                            
                            <!-- Teclados - SEM DROPDOWN -->
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=1">
                                    <i class="fas fa-keyboard me-1"></i>Teclados
                                </a>
                            </li>
                            
                            <!-- Mouses - SEM DROPDOWN -->
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=2">
                                    <i class="fas fa-mouse me-1"></i>Mouses
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=3">
                                    <i class="fas fa-headphones me-1"></i>Headsets
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=4">
                                    <i class="fas fa-desktop me-1"></i>Monitores
                                </a>
                            </li>
                            
                            <!-- Adicionei as outras categorias que estavam no seu banco -->
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=5">
                                    <i class="fas fa-mouse-pointer me-1"></i>Mousepads
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=6">
                                    <i class="fas fa-video me-1"></i>Webcams
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?categoria=7">
                                    <i class="fas fa-microphone me-1"></i>Microfones
                                </a>
                            </li>
                            
                            <li class="nav-item">
                                <a class="nav-link" href="produtos.php?promocao=1">
                                    <i class="fas fa-tag me-1"></i>Promoções
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </div>
    </header>

    <!-- Banner Principal -->
    <section class="bg-primary text-white py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="display-4 fw-bold">Os Melhores Periféricos Gamers</h1>
                    <p class="lead">Encontre teclados, mouses, headsets e muito mais com os melhores preços do mercado!</p>
                    <div class="mt-3">
                        <a href="produtos.php" class="btn btn-warning btn-lg me-3">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Ver Todos os Produtos
                        </a>
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="lista_desejos.php" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-heart me-2"></i>
                                Minha Lista de Desejos
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                    <img src="imagens/banners/acessorios-gamers.jpg" alt="Periféricos Gamers" class="img-fluid rounded" style="max-height: 300px;" onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNTAwIiBoZWlnaHQ9IjMwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZmZmIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIyNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPkJhbm5lciBQcmluY2lwYWw8L3RleHQ+PC9zdmc+'">
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Destaques -->
    <section class="py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="border-bottom pb-2">
                        <i class="fas fa-star text-warning me-2"></i>
                        Produtos em Destaque
                    </h2>
                </div>
            </div>
            <div class="row">
                <?php foreach ($produtos_destaque as $produto): 
                    $preco_final = $produto['preco_promocional'] ?: $produto['preco'];
                    $tem_desconto = $produto['preco_promocional'] && $produto['preco_promocional'] < $produto['preco'];
                    $percentual_desconto = $tem_desconto ? calcularPercentualDesconto($produto['preco'], $produto['preco_promocional']) : 0;
                ?>
                <div class="col-md-3 mb-4">
                    <div class="card h-100 product-card">
                        <div class="card-header position-relative">
                            <?php if ($tem_desconto): ?>
                                <span class="badge bg-danger position-absolute top-0 start-0 m-2">-<?= $percentual_desconto ?>%</span>
                            <?php elseif ($produto['em_destaque']): ?>
                                <span class="badge bg-warning position-absolute top-0 start-0 m-2">Destaque</span>
                            <?php endif; ?>
                            
                            <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" 
                                    data-product="<?= $produto['id'] ?>">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                        
                        <img src="assets/imagens/produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                             class="card-img-top" 
                             alt="<?= htmlspecialchars($produto['nome']) ?>"
                             style="height: 200px; object-fit: cover;"
                             onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                        </img>
                        
                        <div class="card-body d-flex flex-column">
                            <h6 class="card-title"><?= htmlspecialchars($produto['nome']) ?></h6>
                            <p class="card-text text-muted small"><?= htmlspecialchars($produto['marca_nome']) ?></p>
                            
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="h5 text-primary mb-0">R$ <?= number_format($preco_final, 2, ',', '.') ?></span>
                                    <?php if ($tem_desconto): ?>
                                        <small class="text-muted text-decoration-line-through">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></small>
                                    <?php endif; ?>
                                </div>
                                
                                <div class="d-grid gap-2">
                                    <?php if ($produto['estoque'] > 0): ?>
                                        <button class="btn btn-outline-primary btn-sm add-to-cart" 
                                                data-product="<?= $produto['id'] ?>">
                                            <i class="fas fa-cart-plus me-1"></i>
                                            Adicionar ao Carrinho
                                        </button>
                                        <a href="produto.php?id=<?= $produto['id'] ?>" class="btn btn-outline-secondary btn-sm">
                                            <i class="fas fa-eye me-1"></i>
                                            Ver Detalhes
                                        </a>
                                    <?php else: ?>
                                        <button class="btn btn-secondary btn-sm" disabled>
                                            <i class="fas fa-bell me-1"></i>
                                            Avise-me
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Banner Promocional -->
    <section class="bg-light py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4 class="mb-1">Frete Grátis para Todo o Brasil</h4>
                    <p class="mb-0 text-muted">Em compras acima de R$ 299,90</p>
                </div>
                <div class="col-md-4 text-end">
                    <a href="produtos.php" class="btn btn-primary">Aproveitar Oferta</a>
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Categorias -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="border-bottom pb-2">
                        <i class="fas fa-th-large text-primary me-2"></i>
                        Categorias em Destaque
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=1" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-keyboard fa-3x text-primary mb-3"></i>
                                <h5 class="card-title">Teclados</h5>
                                <p class="text-muted small">Mecânicos e Gaming</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=2" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-mouse fa-3x text-success mb-3"></i>
                                <h5 class="card-title">Mouses</h5>
                                <p class="text-muted small">Gamer e Profissionais</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=3" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-headphones fa-3x text-warning mb-3"></i>
                                <h5 class="card-title">Headsets</h5>
                                <p class="text-muted small">Áudio Profissional</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=4" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-desktop fa-3x text-info mb-3"></i>
                                <h5 class="card-title">Monitores</h5>
                                <p class="text-muted small">Gaming e Trabalho</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Ofertas -->
    <section class="py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="border-bottom pb-2">
                        <i class="fas fa-bolt text-danger me-2"></i>
                        Ofertas Relâmpago
                    </h2>
                </div>
            </div>
            <div class="row">
                <?php 
                $cores = ['danger', 'warning', 'success'];
                $i = 0;
                
                foreach ($produtos_promocao as $produto):
                    $cor = $cores[$i % count($cores)];
                    $percentual_desconto = calcularPercentualDesconto($produto['preco'], $produto['preco_promocional']);
                    $i++;
                ?>
                <div class="col-md-4 mb-4">
                    <div class="card offer-card border-<?= $cor ?>">
                        <div class="card-header bg-<?= $cor ?> text-white text-center">
                            <i class="fas fa-clock me-1"></i>
                            Oferta por Tempo Limitado
                        </div>
                        <div class="card-body text-center">
                            <div class="position-relative">
                                <img src="assets/imagens/produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                                     alt="<?= htmlspecialchars($produto['nome']) ?>" 
                                     class="img-fluid mb-3" 
                                     style="height: 150px; object-fit: cover;"
                                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                                </img>
                                <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" 
                                        data-product="<?= $produto['id'] ?>">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <h6 class="card-title"><?= htmlspecialchars($produto['nome']) ?></h6>
                            <div class="price-section">
                                <span class="h4 text-danger">R$ <?= number_format($produto['preco_promocional'], 2, ',', '.') ?></span>
                                <small class="text-muted d-block text-decoration-line-through">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></small>
                            </div>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-<?= $cor ?>" style="width: <?= rand(30, 80) ?>%">
                                    <?= rand(30, 80) ?>% vendido
                                </div>
                            </div>
                            <button class="btn btn-<?= $cor ?> w-100 add-to-cart" 
                                    data-product="<?= $produto['id'] ?>">
                                <i class="fas fa-bolt me-1"></i>
                                Comprar Agora
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="text-warning">
                        <i class="fas fa-gamepad me-2"></i>
                        PGS Periféricos
                    </h5>
                    <p class="text-light">Sua loja de confiança para periféricos gamers de alta qualidade.</p>
                    <div class="social-links">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="text-warning">INSTITUCIONAL</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light text-decoration-none">Sobre Nós</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Nossas Lojas</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Trabalhe Conosco</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Política de Privacidade</a></li>
                    </ul>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="text-warning">ATENDIMENTO</h6>
                    <ul class="list-unstyled">
                        <li><a href="faq.php" class="text-light text-decoration-none">FAQ</a></li>
                        <li><a href="suporte.php" class="text-light text-decoration-none">Abrir ticket</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Troca e Devolução</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Formas de Pagamento</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h6 class="text-warning">NEWSLETTER</h6>
                    <p class="text-light">Cadastre-se e receba ofertas exclusivas!</p>
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Seu e-mail">
                        <button class="btn btn-warning">Cadastrar</button>
                    </div>
                </div>
            </div>
            <hr class="bg-secondary">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0 text-light">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
                </div>
                <div class="col-md-6 text-end">
                    <img src="assets/imagens/icones/cartao.png" alt="Cartões" height="30" class="me-2" onerror="this.style.display='none'">
                    <img src="assets/imagens/icones/pix.png" alt="PIX" height="30" class="me-2" onerror="this.style.display='none'">
                    <img src="assets/imagens/icones/boleto.png" alt="Boleto" height="30" onerror="this.style.display='none'">
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/principal.js"></script>
    
    <script>
        // Sistema de Lista de Desejos
        document.addEventListener('DOMContentLoaded', function() {
            const wishlistBtns = document.querySelectorAll('.wishlist-btn');
            
            wishlistBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product');
                    const icon = this.querySelector('i');
                    
                    <?php if (usuarioEstaLogado()): ?>
                        // Se usuário está logado, alternar entre coração vazio e cheio
                        if (icon.classList.contains('far')) {
                            icon.classList.remove('far');
                            icon.classList.add('fas');
                            this.classList.remove('btn-outline-danger');
                            this.classList.add('btn-danger');
                            adicionarWishlist(productId);
                        } else {
                            icon.classList.remove('fas');
                            icon.classList.add('far');
                            this.classList.remove('btn-danger');
                            this.classList.add('btn-outline-danger');
                            removerWishlist(productId);
                        }
                    <?php else: ?>
                        // Se não está logado, redirecionar para login
                        window.location.href = 'login.php?redirect=indexx';
                    <?php endif; ?>
                });
            });

            // Adicionar ao carrinho
            const addToCartButtons = document.querySelectorAll('.add-to-cart');
            
            addToCartButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product');
                    addToCart(productId);
                });
            });

            function adicionarWishlist(productId) {
                fetch('includes/processa_wishlist.php?action=add&product_id=' + productId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Atualizar contador
                            const wishlistCount = document.getElementById('wishlist-count');
                            if (wishlistCount) {
                                const currentCount = parseInt(wishlistCount.textContent) || 0;
                                wishlistCount.textContent = currentCount + 1;
                            }
                            
                            // Mostrar mensagem de sucesso
                            if (data.message) {
                                showToast(data.message, 'success');
                            }
                        } else {
                            if (data.message) {
                                showToast(data.message, 'error');
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        showToast('Erro ao adicionar à lista de desejos', 'error');
                    });
            }

            function removerWishlist(productId) {
                fetch('includes/processa_wishlist.php?action=remove&product_id=' + productId)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Atualizar contador
                            const wishlistCount = document.getElementById('wishlist-count');
                            if (wishlistCount) {
                                const currentCount = parseInt(wishlistCount.textContent) || 1;
                                wishlistCount.textContent = Math.max(0, currentCount - 1);
                            }
                            
                            // Mostrar mensagem de sucesso
                            if (data.message) {
                                showToast(data.message, 'success');
                            }
                        } else {
                            if (data.message) {
                                showToast(data.message, 'error');
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        showToast('Erro ao remover da lista de desejos', 'error');
                    });
            }

            // Função global para adicionar ao carrinho
            window.addToCart = function(productId, quantity = 1) {
                fetch(`includes/processa_carrinho.php?action=add&product_id=${productId}&quantity=${quantity}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            showToast('Produto adicionado ao carrinho!', 'success');
                            // Atualizar contador do carrinho
                            const cartCount = document.getElementById('cart-count');
                            if (cartCount) {
                                cartCount.textContent = data.cart_count;
                            }
                        } else {
                            showToast(data.message || 'Erro ao adicionar ao carrinho', 'error');
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        showToast('Erro ao adicionar ao carrinho', 'error');
                    });
            };

            // Função para mostrar toast messages
            function showToast(message, type = 'info') {
                // Criar elemento toast
                const toast = document.createElement('div');
                toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
                toast.setAttribute('role', 'alert');
                toast.innerHTML = `
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                `;
                
                // Adicionar ao container de toasts
                let toastContainer = document.getElementById('toast-container');
                if (!toastContainer) {
                    toastContainer = document.createElement('div');
                    toastContainer.id = 'toast-container';
                    toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
                    document.body.appendChild(toastContainer);
                }
                
                toastContainer.appendChild(toast);
                
                // Mostrar toast
                const bsToast = new bootstrap.Toast(toast);
                bsToast.show();
                
                // Remover após esconder
                toast.addEventListener('hidden.bs.toast', () => {
                    toast.remove();
                });
            }

            // Atualizar contador do carrinho ao carregar a página
            fetch('includes/processa_carrinho.php?action=count')
                .then(response => response.json())
                .then(data => {
                    if (data.cart_count !== undefined) {
                        const cartCount = document.getElementById('cart-count');
                        if (cartCount) {
                            cartCount.textContent = data.cart_count;
                        }
                    }
                });
        });
    </script>
</body>
</html>