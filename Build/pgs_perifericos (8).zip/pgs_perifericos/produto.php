<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

$produto_id = intval($_GET['id'] ?? 0);

if ($produto_id <= 0) {
    $_SESSION['erro'] = "Produto não especificado.";
    header("Location: produtos.php");
    exit;
}

// Buscar informações do produto
try {
    $pdo = conectarBanco();
    
    // Buscar produto
    $sql_produto = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome, m.logo as marca_logo
                   FROM produtos p 
                   LEFT JOIN categorias c ON p.categoria_id = c.id 
                   LEFT JOIN marcas m ON p.marca_id = m.id 
                   WHERE p.id = ? AND p.ativo = 1";
    $stmt = $pdo->prepare($sql_produto);
    $stmt->execute([$produto_id]);
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$produto) {
        $_SESSION['erro'] = "Produto não encontrado.";
        header("Location: produtos.php");
        exit;
    }
    
    // Buscar avaliações do produto
    $sql_avaliacoes = "SELECT a.*, u.nome as usuario_nome 
                      FROM avaliacoes a 
                      JOIN usuarios u ON a.usuario_id = u.id 
                      WHERE a.produto_id = ? AND a.aprovado = 1 
                      ORDER BY a.data_avaliacao DESC 
                      LIMIT 5";
    $stmt = $pdo->prepare($sql_avaliacoes);
    $stmt->execute([$produto_id]);
    $avaliacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar produtos relacionados (mesma categoria)
    $sql_relacionados = "SELECT p.*, m.nome as marca_nome 
                        FROM produtos p 
                        LEFT JOIN marcas m ON p.marca_id = m.id 
                        WHERE p.categoria_id = ? AND p.id != ? AND p.ativo = 1 
                        ORDER BY p.em_destaque DESC, p.data_cadastro DESC 
                        LIMIT 4";
    $stmt = $pdo->prepare($sql_relacionados);
    $stmt->execute([$produto['categoria_id'], $produto_id]);
    $produtos_relacionados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar produto: " . $e->getMessage();
    header("Location: produtos.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($produto['nome']) ?> - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <style>
        .product-image {
            border-radius: 8px;
            background: #f8f9fa;
        }
        .price-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
        }
        .specs-list {
            list-style: none;
            padding: 0;
        }
        .specs-list li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .specs-list li:last-child {
            border-bottom: none;
        }
        .rating-stars {
            color: #ffc107;
        }
        .related-product {
            transition: transform 0.3s;
        }
        .related-product:hover {
            transform: translateY(-3px);
        }
        .breadcrumb {
            background: transparent;
            padding: 0;
        }
        .guarantee-badge {
            background: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8em;
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>
                <div class="col-md-5">
                    <form method="GET" action="produtos.php" class="d-flex">
                        <input type="text" name="busca" class="form-control" placeholder="Buscar produtos...">
                        <button class="btn btn-warning ms-2" type="submit">
                            <i class="fas fa-search"></i>
                        </button>
                    </form>
                </div>
                <div class="col-md-5 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                            <a href="lista_desejos.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-heart me-1"></i>
                                Lista de Desejos
                            </a>
                            <?php if (isFuncionario()): ?>
                                <a href="admin/admin.php" class="text-white text-decoration-none me-3">
                                    <i class="fas fa-cog me-1"></i>
                                    Painel Admin
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <span class="badge bg-warning text-dark">0</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                <li class="breadcrumb-item"><a href="produtos.php">Produtos</a></li>
                <li class="breadcrumb-item"><a href="produtos.php?categoria=<?= $produto['categoria_id'] ?>"><?= htmlspecialchars($produto['categoria_nome']) ?></a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($produto['nome']) ?></li>
            </ol>
        </nav>

        <?php mostrarMensagem(); ?>

        <div class="row">
            <!-- Imagens do Produto -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-body text-center">
                        <img src="assets/imagens/produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                             alt="<?= htmlspecialchars($produto['nome']) ?>" 
                             class="img-fluid product-image"
                             style="max-height: 400px; object-fit: contain;"
                             onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                        </img>
                        
                        <!-- Badges -->
                        <div class="mt-3">
                            <?php if ($produto['em_promocao']): ?>
                                <span class="badge bg-danger me-2">PROMOÇÃO</span>
                            <?php endif; ?>
                            <?php if ($produto['em_destaque']): ?>
                                <span class="badge bg-warning me-2">DESTAQUE</span>
                            <?php endif; ?>
                            <span class="guarantee-badge">
                                <i class="fas fa-shield-alt me-1"></i>
                                <?= $produto['garantia_meses'] ?> meses de garantia
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Informações do Produto -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-body">
                        <!-- Marca -->
                        <div class="mb-3">
                            <span class="badge bg-secondary"><?= htmlspecialchars($produto['marca_nome']) ?></span>
                        </div>
                        
                        <!-- Nome -->
                        <h1 class="h3 mb-3"><?= htmlspecialchars($produto['nome']) ?></h1>
                        
                        <!-- Avaliação -->
                        <?php if ($produto['media_avaliacoes'] > 0): ?>
                        <div class="mb-3">
                            <span class="rating-stars">
                                <?= str_repeat('★', round($produto['media_avaliacoes'])) ?><?= str_repeat('☆', 5 - round($produto['media_avaliacoes'])) ?>
                            </span>
                            <span class="text-muted ms-2">
                                (<?= $produto['total_avaliacoes'] ?> avaliações)
                            </span>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Descrição -->
                        <p class="text-muted mb-4"><?= nl2br(htmlspecialchars($produto['descricao'])) ?></p>
                        
                        <!-- Preço -->
                        <div class="price-section mb-4">
                            <?php if ($produto['em_promocao'] && $produto['preco_promocional']): ?>
                                <div class="h4 mb-1">R$ <?= number_format($produto['preco_promocional'], 2, ',', '.') ?></div>
                                <div class="h6 text-light">
                                    <s>R$ <?= number_format($produto['preco'], 2, ',', '.') ?></s>
                                    <span class="badge bg-warning text-dark ms-2">
                                        <?= calcularDesconto($produto['preco'], $produto['preco_promocional']) ?>% OFF
                                    </span>
                                </div>
                            <?php else: ?>
                                <div class="h3">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Estoque -->
                        <div class="mb-4">
                            <?php if ($produto['estoque'] > 0): ?>
                                <span class="text-success">
                                    <i class="fas fa-check-circle me-1"></i>
                                    Em estoque (<?= $produto['estoque'] ?> unidades)
                                </span>
                            <?php else: ?>
                                <span class="text-danger">
                                    <i class="fas fa-times-circle me-1"></i>
                                    Fora de estoque
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Formulário de Compra -->
                        <div class="mb-4">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <label for="quantidade" class="form-label">Quantidade:</label>
                                </div>
                                <div class="col-auto">
                                    <input type="number" 
                                           id="quantidade" 
                                           name="quantidade" 
                                           class="form-control" 
                                           value="1" 
                                           min="1" 
                                           max="<?= $produto['estoque'] ?>"
                                           style="width: 80px;"
                                           <?= $produto['estoque'] <= 0 ? 'disabled' : '' ?>>
                                </div>
                                <div class="col">
                                    <?php if ($produto['estoque'] > 0): ?>
                                        <button type="button" 
                                                class="btn btn-primary btn-lg w-100" 
                                                onclick="addToCart(<?= $produto['id'] ?>, document.getElementById('quantidade').value)">
                                            <i class="fas fa-cart-plus me-2"></i>
                                            Adicionar ao Carrinho
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-secondary btn-lg w-100" disabled>
                                            <i class="fas fa-bell me-2"></i>
                                            Avise-me quando chegar
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                        
                        <!-- Wishlist -->
                        <div class="text-center">
                            <?php if (usuarioEstaLogado()): ?>
                                <button class="btn btn-outline-danger" onclick="toggleWishlist(<?= $produto_id ?>)">
                                    <i class="far fa-heart me-2"></i>
                                    Adicionar à Lista de Desejos
                                </button>
                            <?php else: ?>
                                <a href="login.php?redirect=produto.php?id=<?= $produto_id ?>" class="btn btn-outline-danger">
                                    <i class="far fa-heart me-2"></i>
                                    Favoritar Produto
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Resto do código permanece igual -->
        <!-- ... -->
    </main>

    <!-- Footer e scripts -->
    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="js/carrinho.js"></script>
</body>
</html>

<?php
// Função auxiliar para calcular desconto
function calcularDesconto($precoOriginal, $precoPromocional) {
    if (!$precoPromocional || $precoPromocional >= $precoOriginal) {
        return 0;
    }
    $desconto = (($precoOriginal - $precoPromocional) / $precoOriginal) * 100;
    return round($desconto);
}
?>