<?php
// REMOVA estas linhas:
// error_reporting(E_ALL);
// ini_set('display_errors', 1);
// session_start(); // REMOVER ESTA LINHA

require_once 'config.php';
require_once 'funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    echo json_encode(['success' => false, 'message' => 'Usuário não logado']);
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$endereco_id = intval($_GET['id'] ?? 0);

if ($endereco_id <= 0) {
    echo json_encode(['success' => false, 'message' => 'ID inválido']);
    exit;
}

try {
    // Buscar endereço específico do usuário
    $sql = "SELECT * FROM enderecos WHERE id = ? AND usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $endereco_id, $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    if ($result->num_rows > 0) {
        $endereco = $result->fetch_assoc();
        echo json_encode(['success' => true, 'endereco' => $endereco]);
    } else {
        echo json_encode(['success' => false, 'message' => 'Endereço não encontrado']);
    }
    
} catch (Exception $e) {
    echo json_encode(['success' => false, 'message' => 'Erro no sistema: ' . $e->getMessage()]);
}
?>