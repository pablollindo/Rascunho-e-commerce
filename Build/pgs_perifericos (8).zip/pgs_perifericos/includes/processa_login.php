<?php
require_once 'config.php';
require_once 'funcoes.php';

// Ativar exibição de erros para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = sanitizar($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $lembrar = isset($_POST['lembrar']) ? true : false;
    
    // Validar dados
    if (empty($email) || empty($senha)) {
        $_SESSION['erro'] = "Por favor, preencha email e senha.";
        header("Location: ../login.php");
        exit;
    }

    if (!validarEmail($email)) {
        $_SESSION['erro'] = "Por favor, insira um email válido.";
        header("Location: ../login.php");
        exit;
    }

    try {
        // Buscar usuário na tabela USUARIOS
        $sql = "SELECT u.id, u.nome, u.email, u.senha, u.tipo, f.cargo 
                FROM usuarios u 
                LEFT JOIN funcionarios f ON u.id = f.usuario_id 
                WHERE u.email = ? AND u.ativo = 1";
        $stmt = $conn->prepare($sql);
        
        if ($stmt) {
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows === 1) {
                $usuario = $result->fetch_assoc();
                
                // Verificar senha
                if (password_verify($senha, $usuario['senha'])) {
                    // Login bem-sucedido
                    $_SESSION['usuario_id'] = $usuario['id'];
                    $_SESSION['usuario_nome'] = $usuario['nome'];
                    $_SESSION['usuario_email'] = $usuario['email'];
                    $_SESSION['usuario_tipo'] = $usuario['tipo'];
                    
                    // Se for funcionário, salvar cargo
                    if ($usuario['tipo'] === 'funcionario' || $usuario['tipo'] === 'admin') {
                        $_SESSION['usuario_cargo'] = $usuario['cargo'];
                    }
                    
                    $_SESSION['sucesso'] = "Login realizado com sucesso! Bem-vindo, " . $usuario['nome'] . "!";
                    
                    // Redirecionar baseado no tipo
                    if ($usuario['tipo'] === 'cliente') {
                        header("Location: ../indexx.php");
                    } else {
                        header("Location: ../admin/admin.php");
                    }
                    exit;
                    
                } else {
                    $_SESSION['erro'] = "Senha incorreta.";
                    header("Location: ../login.php");
                    exit;
                }
            } else {
                $_SESSION['erro'] = "Usuário não encontrado ou conta desativada.";
                header("Location: ../login.php");
                exit;
            }
            
            $stmt->close();
        } else {
            $_SESSION['erro'] = "Erro no sistema. Tente novamente.";
            header("Location: ../login.php");
            exit;
        }
        
    } catch (Exception $e) {
        $_SESSION['erro'] = "Erro ao processar login: " . $e->getMessage();
        header("Location: ../login.php");
        exit;
    }
} else {
    // Se não for POST, redirecionar
    header("Location: ../login.php");
    exit;
}
?>