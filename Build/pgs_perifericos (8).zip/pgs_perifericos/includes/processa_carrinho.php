<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// Inicializar carrinho se não existir
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

$response = ['success' => false, 'message' => '', 'cart_count' => 0];

try {
    $pdo = conectarBanco();
    
    $action = $_POST['action'] ?? ($_GET['action'] ?? '');
    $product_id = intval($_POST['product_id'] ?? ($_GET['product_id'] ?? 0));
    $quantity = intval($_POST['quantity'] ?? ($_GET['quantity'] ?? 1));

    switch ($action) {
        case 'add':
            $response = adicionarAoCarrinho($pdo, $product_id, $quantity);
            break;
            
        case 'update':
            $response = atualizarCarrinho($pdo, $product_id, $quantity);
            break;
            
        case 'remove':
            $response = removerDoCarrinho($product_id);
            break;
            
        case 'clear':
            $response = limparCarrinho();
            break;
            
        case 'count':
            $response = ['success' => true, 'cart_count' => calcularTotalItensCarrinho()];
            break;
            
        default:
            $response['message'] = 'Ação inválida.';
    }
    
    // Atualizar contador do carrinho
    $response['cart_count'] = calcularTotalItensCarrinho();
    
} catch (Exception $e) {
    $response['message'] = 'Erro: ' . $e->getMessage();
}

// Retornar resposta JSON
header('Content-Type: application/json');
echo json_encode($response);
exit;

// ===== FUNÇÕES DO CARRINHO =====

function adicionarAoCarrinho($pdo, $product_id, $quantity = 1) {
    if ($product_id <= 0 || $quantity <= 0) {
        return ['success' => false, 'message' => 'Produto ou quantidade inválida.'];
    }
    
    // Buscar informações do produto
    $produto = buscarProduto($pdo, $product_id);
    if (!$produto) {
        return ['success' => false, 'message' => 'Produto não encontrado.'];
    }
    
    // Verificar estoque
    if ($produto['estoque'] < $quantity) {
        return ['success' => false, 'message' => 'Estoque insuficiente. Disponível: ' . $produto['estoque']];
    }
    
    // Adicionar ou atualizar no carrinho
    if (isset($_SESSION['carrinho'][$product_id])) {
        $nova_quantidade = $_SESSION['carrinho'][$product_id]['quantidade'] + $quantity;
        
        // Verificar estoque novamente
        if ($produto['estoque'] < $nova_quantidade) {
            return ['success' => false, 'message' => 'Estoque insuficiente. Disponível: ' . $produto['estoque']];
        }
        
        $_SESSION['carrinho'][$product_id]['quantidade'] = $nova_quantidade;
        $message = 'Quantidade atualizada no carrinho!';
    } else {
        $_SESSION['carrinho'][$product_id] = [
            'id' => $produto['id'],
            'nome' => $produto['nome'],
            'preco' => floatval($produto['preco']),
            'preco_promocional' => $produto['preco_promocional'] ? floatval($produto['preco_promocional']) : null,
            'quantidade' => $quantity,
            'estoque' => $produto['estoque'],
            'imagem' => $produto['imagem'],
            'marca' => $produto['marca_nome'],
            'categoria' => $produto['categoria_nome']
        ];
        $message = 'Produto adicionado ao carrinho!';
    }
    
    return ['success' => true, 'message' => $message];
}

function atualizarCarrinho($pdo, $product_id, $quantity) {
    if ($product_id <= 0) {
        return ['success' => false, 'message' => 'Produto inválido.'];
    }
    
    if (!isset($_SESSION['carrinho'][$product_id])) {
        return ['success' => false, 'message' => 'Produto não encontrado no carrinho.'];
    }
    
    if ($quantity <= 0) {
        return removerDoCarrinho($product_id);
    }
    
    // Buscar informações atualizadas do produto
    $produto = buscarProduto($pdo, $product_id);
    if (!$produto) {
        return ['success' => false, 'message' => 'Produto não encontrado.'];
    }
    
    // Verificar estoque
    if ($produto['estoque'] < $quantity) {
        return ['success' => false, 'message' => 'Estoque insuficiente. Disponível: ' . $produto['estoque']];
    }
    
    $_SESSION['carrinho'][$product_id]['quantidade'] = $quantity;
    $_SESSION['carrinho'][$product_id]['estoque'] = $produto['estoque']; // Atualizar estoque
    
    return ['success' => true, 'message' => 'Quantidade atualizada!'];
}

function removerDoCarrinho($product_id) {
    if ($product_id <= 0) {
        return ['success' => false, 'message' => 'Produto inválido.'];
    }
    
    if (!isset($_SESSION['carrinho'][$product_id])) {
        return ['success' => false, 'message' => 'Produto não encontrado no carrinho.'];
    }
    
    unset($_SESSION['carrinho'][$product_id]);
    return ['success' => true, 'message' => 'Produto removido do carrinho!'];
}

function limparCarrinho() {
    $_SESSION['carrinho'] = [];
    return ['success' => true, 'message' => 'Carrinho limpo!'];
}

function buscarProduto($pdo, $product_id) {
    $sql = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome 
            FROM produtos p 
            LEFT JOIN categorias c ON p.categoria_id = c.id 
            LEFT JOIN marcas m ON p.marca_id = m.id 
            WHERE p.id = ? AND p.ativo = 1";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$product_id]);
    
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function calcularTotalItensCarrinho() {
    $total = 0;
    if (isset($_SESSION['carrinho']) && is_array($_SESSION['carrinho'])) {
        foreach ($_SESSION['carrinho'] as $item) {
            $total += $item['quantidade'];
        }
    }
    return $total;
}
?>