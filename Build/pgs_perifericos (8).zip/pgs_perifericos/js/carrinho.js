// Sistema de Gerenciamento do Carrinho
class CarrinhoManager {
    constructor() {
        this.init();
    }

    init() {
        this.bindEvents();
        this.atualizarContadorCarrinho();
    }

    bindEvents() {
        // Botões de quantidade
        document.addEventListener('click', (e) => {
            if (e.target.closest('.quantity-btn')) {
                this.alterarQuantidade(e);
            }
        });

        // Input de quantidade
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('quantity-input')) {
                this.atualizarQuantidade(e.target);
            }
        });

        // Remover item
        document.addEventListener('click', (e) => {
            if (e.target.closest('.remove-item')) {
                this.removerItem(e);
            }
        });

        // Limpar carrinho
        const limparBtn = document.getElementById('limpar-carrinho');
        if (limparBtn) {
            limparBtn.addEventListener('click', () => this.limparCarrinho());
        }

        // Aplicar cupom
        const aplicarCupomBtn = document.getElementById('aplicar-cupom');
        if (aplicarCupomBtn) {
            aplicarCupomBtn.addEventListener('click', () => this.aplicarCupom());
        }
    }

    async alterarQuantidade(e) {
        e.preventDefault();
        const btn = e.target.closest('.quantity-btn');
        const action = btn.dataset.action;
        const productId = btn.dataset.productId;
        const input = btn.closest('.quantity-controls').querySelector('.quantity-input');
        let quantity = parseInt(input.value);

        if (action === 'increase') {
            quantity++;
        } else {
            quantity = Math.max(1, quantity - 1);
        }

        input.value = quantity;
        await this.atualizarQuantidadeNoServidor(productId, quantity);
    }

    async atualizarQuantidade(input) {
        const productId = input.dataset.productId;
        const quantity = parseInt(input.value);
        
        if (quantity < 1) {
            input.value = 1;
            return;
        }

        await this.atualizarQuantidadeNoServidor(productId, quantity);
    }

    async atualizarQuantidadeNoServidor(productId, quantity) {
        try {
            const response = await this.fazerRequisicao('update', productId, quantity);
            
            if (response.success) {
                this.atualizarInterface();
                this.mostrarMensagem('success', response.message);
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.mostrarMensagem('error', error.message);
            // Recarregar a página para sincronizar com o servidor
            location.reload();
        }
    }

    async removerItem(e) {
        e.preventDefault();
        const btn = e.target.closest('.remove-item');
        const productId = btn.dataset.productId;

        if (!confirm('Deseja remover este item do carrinho?')) {
            return;
        }

        try {
            const response = await this.fazerRequisicao('remove', productId);
            
            if (response.success) {
                // Remover item da interface
                const itemElement = document.getElementById(`cart-item-${productId}`);
                if (itemElement) {
                    itemElement.remove();
                }
                
                this.atualizarInterface();
                this.mostrarMensagem('success', response.message);
                
                // Verificar se o carrinho ficou vazio
                if (response.cart_count === 0) {
                    location.reload();
                }
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.mostrarMensagem('error', error.message);
        }
    }

    async limparCarrinho() {
        if (!confirm('Deseja limpar todo o carrinho?')) {
            return;
        }

        try {
            const response = await this.fazerRequisicao('clear');
            
            if (response.success) {
                this.mostrarMensagem('success', response.message);
                // Recarregar a página para mostrar carrinho vazio
                location.reload();
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.mostrarMensagem('error', error.message);
        }
    }

    aplicarCupom() {
        const cupomInput = document.getElementById('cupom');
        const cupom = cupomInput.value.trim();
        
        if (!cupom) {
            this.mostrarMensagem('error', 'Digite um código de cupom.');
            return;
        }

        // Simular aplicação de cupom
        this.mostrarMensagem('success', `Cupom ${cupom} aplicado com sucesso!`);
        cupomInput.value = '';
    }

    async fazerRequisicao(action, productId = 0, quantity = 1) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('product_id', productId);
        formData.append('quantity', quantity);

        const response = await fetch('includes/processa_carrinho.php', {
            method: 'POST',
            body: formData
        });

        return await response.json();
    }

    atualizarInterface() {
        // Atualizar contador do carrinho
        this.atualizarContadorCarrinho();
        
        // Recarregar a página após um breve delay para atualizar totais
        setTimeout(() => {
            location.reload();
        }, 1500);
    }

    atualizarContadorCarrinho() {
        const cartCountElements = document.querySelectorAll('#cart-count, .badge.bg-warning');
        cartCountElements.forEach(element => {
            // Buscar contagem atual do servidor
            fetch('includes/processa_carrinho.php?action=count')
                .then(response => response.json())
                .then(data => {
                    if (data.cart_count !== undefined) {
                        element.textContent = data.cart_count;
                    }
                })
                .catch(error => console.error('Erro ao atualizar contador:', error));
        });
    }

    mostrarMensagem(tipo, mensagem) {
        // Criar elemento de mensagem
        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${tipo === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${mensagem}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        // Inserir antes do conteúdo principal
        const main = document.querySelector('main .container');
        if (main) {
            main.insertBefore(alertDiv, main.firstChild);
        }

        // Auto-remover após 5 segundos
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 5000);
    }
}

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    window.carrinhoManager = new CarrinhoManager();
});

// Função global para adicionar ao carrinho (usada nas páginas de produtos)
function addToCart(productId, quantity = 1) {
    const formData = new FormData();
    formData.append('action', 'add');
    formData.append('product_id', productId);
    formData.append('quantity', quantity);

    fetch('includes/processa_carrinho.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            // Atualizar contador do carrinho
            const cartCountElements = document.querySelectorAll('#cart-count, .badge.bg-warning');
            cartCountElements.forEach(element => {
                element.textContent = data.cart_count;
            });
            
            // Mostrar mensagem de sucesso
            showToast(data.message, 'success');
        } else {
            showToast(data.message, 'error');
        }
    })
    .catch(error => {
        console.error('Erro:', error);
        showToast('Erro ao adicionar ao carrinho', 'error');
    });
}

// Função para mostrar toast (compatível com outras páginas)
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
    toast.setAttribute('role', 'alert');
    toast.innerHTML = `
        <div class="d-flex">
            <div class="toast-body">${message}</div>
            <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
        </div>
    `;
    
    let toastContainer = document.getElementById('toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.id = 'toast-container';
        toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
        document.body.appendChild(toastContainer);
    }
    
    toastContainer.appendChild(toast);
    const bsToast = new bootstrap.Toast(toast);
    bsToast.show();
    
    toast.addEventListener('hidden.bs.toast', () => {
        toast.remove();
    });
}