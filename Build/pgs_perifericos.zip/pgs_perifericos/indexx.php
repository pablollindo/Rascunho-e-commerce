<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PGS Periféricos - Loja de Periféricos Gamers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Barra de Pesquisa -->
                <div class="col-md-5">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Buscar produtos...">
                        <button class="btn btn-warning" type="button">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>

                <!-- Menu Usuário -->
<div class="col-md-5 text-end">
    <div class="d-flex justify-content-end align-items-center">
        <?php if (usuarioEstaLogado()): ?>
            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                <i class="fas fa-user me-1"></i>
                Minha Conta
            </a>
            <a href="lista_desejos.php" class="text-white text-decoration-none me-3">
                <i class="fas fa-heart me-1"></i>
                Lista de Desejos
                <span class="badge bg-danger" id="wishlist-count">0</span>
            </a>
            <!-- BOTÃO PAINEL ADMIN APENAS PARA FUNCIONÁRIOS -->
            <?php if (isFuncionario()): ?>
                <a href="admin/admin.php" class="text-white text-decoration-none me-3">
                    <i class="fas fa-cog me-1"></i>
                    Painel Admin
                </a>
            <?php endif; ?>
        <?php else: ?>
            <a href="login.php" class="text-white text-decoration-none me-3">
                <i class="fas fa-user me-1"></i>
                Entrar
            </a>
        <?php endif; ?>
        <a href="carrinho.php" class="text-white text-decoration-none">
            <i class="fas fa-shopping-cart me-1"></i>
            Carrinho
            <span class="badge bg-warning text-dark">0</span>
        </a>
    </div>
</div>
        <!-- Menu de Navegação -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link active" href="indexx.php">
                                <i class="fas fa-home me-1"></i>Início
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-keyboard me-1"></i>Teclados
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Mecânicos</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Membrana</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Gaming</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-mouse me-1"></i>Mouses
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Gaming</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Sem Fio</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Ópticos</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=3">
                                <i class="fas fa-headphones me-1"></i>Headsets
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=4">
                                <i class="fas fa-desktop me-1"></i>Monitores
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="promocoes.php">
                                <i class="fas fa-tag me-1"></i>Promoções
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Banner Principal -->
    <section class="bg-primary text-white py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <h1 class="display-4 fw-bold">Os Melhores Periféricos Gamers</h1>
                    <p class="lead">Encontre teclados, mouses, headsets e muito mais com os melhores preços do mercado!</p>
                    <div class="mt-3">
                        <a href="produtos.php" class="btn btn-warning btn-lg me-3">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Ver Todos os Produtos
                        </a>
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="lista_desejos.php" class="btn btn-outline-light btn-lg">
                                <i class="fas fa-heart me-2"></i>
                                Minha Lista de Desejos
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
                <div class="col-md-6 text-center">
                    <img src="imagens/banners/acessorios-gamers.jpg" alt="Periféricos Gamers" class="img-fluid rounded" style="max-height: 300px;">
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Destaques -->
    <section class="py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="border-bottom pb-2">
                        <i class="fas fa-star text-warning me-2"></i>
                        Produtos em Destaque
                    </h2>
                </div>
            </div>
            <div class="row">
                <!-- Produto 1 -->
                <div class="col-md-3 mb-4">
                    <div class="card h-100 product-card">
                        <div class="card-header position-relative">
                            <span class="badge bg-danger position-absolute top-0 start-0 m-2">-15%</span>
                            <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="1">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                        <img src="assets/imagens/produtos/teclado-mecanico.jpg" class="card-img-top" alt="Teclado Mecânico" style="height: 200px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Teclado Mecânico RGB</h5>
                            <p class="card-text text-muted small">Teclado mecânico gaming com switches Blue</p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="h5 text-primary mb-0">R$ 249,90</span>
                                    <small class="text-muted text-decoration-line-through">R$ 299,90</small>
                                </div>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary">
                                        <i class="fas fa-cart-plus me-1"></i>
                                        Adicionar ao Carrinho
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Produto 2 -->
                <div class="col-md-3 mb-4">
                    <div class="card h-100 product-card">
                        <div class="card-header position-relative">
                            <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="2">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                        <img src="assets/imagens/produtos/mouse-gamer.jpg" class="card-img-top" alt="Mouse Gamer" style="height: 200px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Mouse Gamer Profissional</h5>
                            <p class="card-text text-muted small">Sensor óptico 16000 DPI, 8 botões</p>
                            <div class="mt-auto">
                                <div class="mb-2">
                                    <span class="h5 text-primary">R$ 199,90</span>
                                </div>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary">
                                        <i class="fas fa-cart-plus me-1"></i>
                                        Adicionar ao Carrinho
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Produto 3 -->
                <div class="col-md-3 mb-4">
                    <div class="card h-100 product-card">
                        <div class="card-header position-relative">
                            <span class="badge bg-success position-absolute top-0 start-0 m-2">Novo</span>
                            <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="3">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                        <img src="assets/imagens/produtos/headset.jpg" class="card-img-top" alt="Headset Gamer" style="height: 200px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Headset Gamer 7.1</h5>
                            <p class="card-text text-muted small">Som surround virtual, microfone retrátil</p>
                            <div class="mt-auto">
                                <div class="mb-2">
                                    <span class="h5 text-primary">R$ 349,90</span>
                                </div>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary">
                                        <i class="fas fa-cart-plus me-1"></i>
                                        Adicionar ao Carrinho
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Produto 4 -->
                <div class="col-md-3 mb-4">
                    <div class="card h-100 product-card">
                        <div class="card-header position-relative">
                            <span class="badge bg-danger position-absolute top-0 start-0 m-2">-20%</span>
                            <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="4">
                                <i class="far fa-heart"></i>
                            </button>
                        </div>
                        <img src="assets/imagens/produtos/monitor.jpg" class="card-img-top" alt="Monitor Gamer" style="height: 200px; object-fit: cover;">
                        <div class="card-body d-flex flex-column">
                            <h5 class="card-title">Monitor Gamer 24"</h5>
                            <p class="card-text text-muted small">144Hz, 1ms, Full HD, FreeSync</p>
                            <div class="mt-auto">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="h5 text-primary mb-0">R$ 899,90</span>
                                    <small class="text-muted text-decoration-line-through">R$ 1.099,90</small>
                                </div>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary">
                                        <i class="fas fa-cart-plus me-1"></i>
                                        Adicionar ao Carrinho
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Banner Promocional -->
    <section class="bg-light py-4">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-8">
                    <h4 class="mb-1">Frete Grátis para Todo o Brasil</h4>
                    <p class="mb-0 text-muted">Em compras acima de R$ 299,90</p>
                </div>
                <div class="col-md-4 text-end">
                    <button class="btn btn-primary">Aproveitar Oferta</button>
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Categorias -->
    <section class="py-5 bg-light">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="border-bottom pb-2">
                        <i class="fas fa-th-large text-primary me-2"></i>
                        Categorias em Destaque
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=1" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-keyboard fa-3x text-primary mb-3"></i>
                                <h5 class="card-title">Teclados</h5>
                                <p class="text-muted small">Mecânicos e Gaming</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=2" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-mouse fa-3x text-success mb-3"></i>
                                <h5 class="card-title">Mouses</h5>
                                <p class="text-muted small">Gamer e Profissionais</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=3" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-headphones fa-3x text-warning mb-3"></i>
                                <h5 class="card-title">Headsets</h5>
                                <p class="text-muted small">Áudio Profissional</p>
                            </div>
                        </div>
                    </a>
                </div>
                <div class="col-md-3 mb-3">
                    <a href="produtos.php?categoria=4" class="text-decoration-none">
                        <div class="card text-center category-card">
                            <div class="card-body">
                                <i class="fas fa-desktop fa-3x text-info mb-3"></i>
                                <h5 class="card-title">Monitores</h5>
                                <p class="text-muted small">Gaming e Trabalho</p>
                            </div>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </section>

    <!-- Seção Ofertas -->
    <section class="py-5">
        <div class="container">
            <div class="row mb-4">
                <div class="col-12">
                    <h2 class="border-bottom pb-2">
                        <i class="fas fa-bolt text-danger me-2"></i>
                        Ofertas Relâmpago
                    </h2>
                </div>
            </div>
            <div class="row">
                <!-- Produto em Oferta 1 -->
                <div class="col-md-4 mb-4">
                    <div class="card offer-card border-danger">
                        <div class="card-header bg-danger text-white text-center">
                            <i class="fas fa-clock me-1"></i>
                            Termina em: 02:15:33
                        </div>
                        <div class="card-body text-center">
                            <div class="position-relative">
                                <img src="assets/imagens/produtos/mousepad.jpg" alt="Mousepad" class="img-fluid mb-3" style="height: 150px; object-fit: cover;">
                                <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="5">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <h5 class="card-title">Mousepad Gamer XXL</h5>
                            <div class="price-section">
                                <span class="h4 text-danger">R$ 49,90</span>
                                <small class="text-muted d-block text-decoration-line-through">R$ 79,90</small>
                            </div>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-danger" style="width: 75%">75% vendido</div>
                            </div>
                            <button class="btn btn-danger w-100">
                                <i class="fas fa-bolt me-1"></i>
                                Comprar Agora
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Produto em Oferta 2 -->
                <div class="col-md-4 mb-4">
                    <div class="card offer-card border-warning">
                        <div class="card-header bg-warning text-dark text-center">
                            <i class="fas fa-clock me-1"></i>
                            Termina em: 05:42:11
                        </div>
                        <div class="card-body text-center">
                            <div class="position-relative">
                                <img src="assets/imagens/produtos/webcam.jpg" alt="Webcam" class="img-fluid mb-3" style="height: 150px; object-fit: cover;">
                                <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="6">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <h5 class="card-title">Webcam Full HD</h5>
                            <div class="price-section">
                                <span class="h4 text-danger">R$ 129,90</span>
                                <small class="text-muted d-block text-decoration-line-through">R$ 199,90</small>
                            </div>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-warning" style="width: 45%">45% vendido</div>
                            </div>
                            <button class="btn btn-warning w-100">
                                <i class="fas fa-bolt me-1"></i>
                                Comprar Agora
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Produto em Oferta 3 -->
                <div class="col-md-4 mb-4">
                    <div class="card offer-card border-success">
                        <div class="card-header bg-success text-white text-center">
                            <i class="fas fa-clock me-1"></i>
                            Termina em: 12:28:07
                        </div>
                        <div class="card-body text-center">
                            <div class="position-relative">
                                <img src="assets/imagens/produtos/microfone.jpg" alt="Microfone" class="img-fluid mb-3" style="height: 150px; object-fit: cover;">
                                <button class="btn btn-outline-danger btn-sm position-absolute top-0 end-0 m-2 wishlist-btn" data-product="7">
                                    <i class="far fa-heart"></i>
                                </button>
                            </div>
                            <h5 class="card-title">Microfone USB Streaming</h5>
                            <div class="price-section">
                                <span class="h4 text-danger">R$ 189,90</span>
                                <small class="text-muted d-block text-decoration-line-through">R$ 249,90</small>
                            </div>
                            <div class="progress mb-3">
                                <div class="progress-bar bg-success" style="width: 30%">30% vendido</div>
                            </div>
                            <button class="btn btn-success w-100">
                                <i class="fas fa-bolt me-1"></i>
                                Comprar Agora
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    
    <!-- Footer -->
    <footer class="bg-dark text-white py-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="text-warning">
                        <i class="fas fa-gamepad me-2"></i>
                        PGS Periféricos
                    </h5>
                    <p class="text-light">Sua loja de confiança para periféricos gamers de alta qualidade.</p>
                    <div class="social-links">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="text-warning">INSTITUCIONAL</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light text-decoration-none">Sobre Nós</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Nossas Lojas</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Trabalhe Conosco</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Política de Privacidade</a></li>
                    </ul>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="text-warning">ATENDIMENTO</h6>
                    <ul class="list-unstyled">
                        <li><a href="faq.php" class="text-light text-decoration-none">FAQ</a></li>
                        <li><a href="suporte.php" class="text-light text-decoration-none">Fale Conosco</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Troca e Devolução</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Formas de Pagamento</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h6 class="text-warning">NEWSLETTER</h6>
                    <p class="text-light">Cadastre-se e receba ofertas exclusivas!</p>
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Seu e-mail">
                        <button class="btn btn-warning">Cadastrar</button>
                    </div>
                </div>
            </div>
            <hr class="bg-secondary">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0 text-light">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
                </div>
                <div class="col-md-6 text-end">
                    <img src="imagens/icones/icons8-cartão-50.png" alt="Cartões" height="30" class="me-2">
                    <img src="imagens/icones/icons8-foto-50.png" alt="PIX" height="30" class="me-2">
                    <img src="imagens/icones/icons8-boleto-50.png" alt="Boleto" height="30">
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/principal.js"></script>
    
    <script>
        // Sistema de Lista de Desejos
        document.addEventListener('DOMContentLoaded', function() {
            const wishlistBtns = document.querySelectorAll('.wishlist-btn');
            
            wishlistBtns.forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product');
                    const icon = this.querySelector('i');
                    
                    <?php if (usuarioEstaLogado()): ?>
                        // Se usuário está logado, alternar entre coração vazio e cheio
                        if (icon.classList.contains('far')) {
                            icon.classList.remove('far');
                            icon.classList.add('fas');
                            this.classList.remove('btn-outline-danger');
                            this.classList.add('btn-danger');
                            adicionarWishlist(productId);
                        } else {
                            icon.classList.remove('fas');
                            icon.classList.add('far');
                            this.classList.remove('btn-danger');
                            this.classList.add('btn-outline-danger');
                            removerWishlist(productId);
                        }
                    <?php else: ?>
                        // Se não está logado, redirecionar para login
                        window.location.href = 'login.php?redirect=indexx';
                    <?php endif; ?>
                });
            });

            function adicionarWishlist(productId) {
                fetch('includes/processa_wishlist.php?action=add&product_id=' + productId + '&redirect=indexx')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Atualizar contador
                            const wishlistCount = document.getElementById('wishlist-count');
                            if (wishlistCount) {
                                const currentCount = parseInt(wishlistCount.textContent) || 0;
                                wishlistCount.textContent = currentCount + 1;
                            }
                            
                            // Mostrar mensagem de sucesso
                            if (data.message) {
                                showToast(data.message, 'success');
                            }
                        } else {
                            if (data.message) {
                                showToast(data.message, 'error');
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        showToast('Erro ao adicionar à lista de desejos', 'error');
                    });
            }

            function removerWishlist(productId) {
                fetch('includes/processa_wishlist.php?action=remove&product_id=' + productId + '&redirect=indexx')
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Atualizar contador
                            const wishlistCount = document.getElementById('wishlist-count');
                            if (wishlistCount) {
                                const currentCount = parseInt(wishlistCount.textContent) || 1;
                                wishlistCount.textContent = Math.max(0, currentCount - 1);
                            }
                            
                            // Mostrar mensagem de sucesso
                            if (data.message) {
                                showToast(data.message, 'success');
                            }
                        } else {
                            if (data.message) {
                                showToast(data.message, 'error');
                            }
                        }
                    })
                    .catch(error => {
                        console.error('Erro:', error);
                        showToast('Erro ao remover da lista de desejos', 'error');
                    });
            }

            // Função para mostrar toast messages
            function showToast(message, type = 'info') {
                // Criar elemento toast
                const toast = document.createElement('div');
                toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
                toast.setAttribute('role', 'alert');
                toast.innerHTML = `
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                    </div>
                `;
                
                // Adicionar ao container de toasts
                let toastContainer = document.getElementById('toast-container');
                if (!toastContainer) {
                    toastContainer = document.createElement('div');
                    toastContainer.id = 'toast-container';
                    toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
                    document.body.appendChild(toastContainer);
                }
                
                toastContainer.appendChild(toast);
                
                // Mostrar toast
                const bsToast = new bootstrap.Toast(toast);
                bsToast.show();
                
                // Remover após esconder
                toast.addEventListener('hidden.bs.toast', () => {
                    toast.remove();
                });
            }
        });
    </script>
</body>
</html>