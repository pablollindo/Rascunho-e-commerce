<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

$erro = '';
$sucesso = '';

// Processar cadastro se for POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once 'includes/processa_cadastro.php';
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/formularios.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>
                <div class="col-md-8 text-center">
                    <h5 class="mb-0">Criar Nova Conta</h5>
                </div>
                <div class="col-md-2 text-end">
                    <a href="indexx.php" class="btn btn-outline-warning btn-sm">
                        <i class="fas fa-home me-1"></i>Voltar
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-7">
                <div class="card cadastro-card shadow">
                    <div class="card-header bg-primary text-white text-center py-4">
                        <h3 class="mb-0">
                            <i class="fas fa-user-plus me-2"></i>
                            Criar Conta
                        </h3>
                        <p class="mb-0 mt-2">Escolha o tipo de cadastro</p>
                    </div>
                    <div class="card-body p-4">
                        <!-- Mensagens -->
                        <?php mostrarMensagem(); ?>

                        <!-- Informações sobre tipos de cadastro -->
                        <div class="alert alert-info mb-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-info-circle fa-2x me-3"></i>
                                <div>
                                    <h6 class="mb-1">Não sabe qual tipo escolher?</h6>
                                    <p class="mb-0">Cliente para compras normais | Funcionário para acesso corporativo</p>
                                    <button type="button" class="btn btn-outline-info btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#infoModal">
                                        <i class="fas fa-question-circle me-1"></i>Saiba mais sobre os tipos
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Seletor de Tipo -->
                        <div class="row mb-4">
                            <div class="col-6">
                                <div class="tipo-cadastro-btn rounded-start active" id="btn-cliente" onclick="selecionarTipo('cliente')">
                                    <i class="fas fa-user text-primary"></i>
                                    <div class="fw-bold">Cliente</div>
                                    <small class="text-muted">Compra de produtos</small>
                                </div>
                            </div>
                            <div class="col-6">
                                <div class="tipo-cadastro-btn rounded-end" id="btn-funcionario" onclick="selecionarTipo('funcionario')">
                                    <i class="fas fa-user-tie text-success"></i>
                                    <div class="fw-bold">Funcionário</div>
                                    <small class="text-muted">Acesso corporativo</small>
                                </div>
                            </div>
                        </div>

                        <form method="POST" action="includes/processa_cadastro.php">
                            <input type="hidden" name="tipo_cadastro" id="tipo_cadastro" value="cliente">
                            
                            <!-- Dados Pessoais -->
                            <div class="form-section">
                                <h5 class="border-bottom pb-2 mb-4">
                                    <i class="fas fa-user me-2 text-primary"></i>
                                    Dados Pessoais
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="nome" class="form-label">
                                            <i class="fas fa-user me-1"></i>Nome Completo *
                                        </label>
                                        <input type="text" class="form-control" id="nome" name="nome" 
                                               value="<?php echo $_POST['nome'] ?? ''; ?>" required
                                               placeholder="Digite seu nome completo">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">
                                            <i class="fas fa-envelope me-1"></i>Email *
                                        </label>
                                        <input type="email" class="form-control" id="email" name="email" 
                                               value="<?php echo $_POST['email'] ?? ''; ?>" required
                                               placeholder="seu@email.com">
                                        <div class="form-text" id="email-help">
                                            Para funcionários: nome.sobrenome@pgs.com
                                        </div>
                                        <button type="button" class="btn btn-link btn-sm p-0 text-info" data-bs-toggle="modal" data-bs-target="#emailModal">
                                            <i class="fas fa-question-circle me-1"></i>Formato de email
                                        </button>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="cpf" class="form-label">
                                            <i class="fas fa-id-card me-1"></i>CPF *
                                        </label>
                                        <input type="text" class="form-control" id="cpf" name="cpf" 
                                               value="<?php echo $_POST['cpf'] ?? ''; ?>" 
                                               placeholder="000.000.000-00" required>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="senha" class="form-label">
                                            <i class="fas fa-lock me-1"></i>Senha *
                                        </label>
                                        <input type="password" class="form-control" id="senha" name="senha" required
                                               placeholder="Mínimo 6 caracteres">
                                        <div class="password-strength" id="password-strength"></div>
                                        <small class="form-text text-muted">Mínimo 6 caracteres</small>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="confirmar_senha" class="form-label">
                                            <i class="fas fa-lock me-1"></i>Confirmar Senha *
                                        </label>
                                        <input type="password" class="form-control" id="confirmar_senha" name="confirmar_senha" required
                                               placeholder="Digite a senha novamente">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="telefone" class="form-label">
                                            <i class="fas fa-phone me-1"></i>Telefone *
                                        </label>
                                        <input type="text" class="form-control" id="telefone" name="telefone" 
                                               value="<?php echo $_POST['telefone'] ?? ''; ?>" 
                                               placeholder="(11) 99999-9999" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="data_nascimento" class="form-label">
                                            <i class="fas fa-calendar me-1"></i>Data de Nascimento *
                                        </label>
                                        <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" 
                                               value="<?php echo $_POST['data_nascimento'] ?? ''; ?>" required>
                                    </div>
                                </div>
                            </div>

                            <!-- Seção Funcionário (Dinâmica) -->
                            <div class="form-section" id="secao-funcionario" style="display: none;">
                                <h5 class="border-bottom pb-2 mb-4">
                                    <i class="fas fa-briefcase me-2 text-warning"></i>
                                    Dados Profissionais
                                </h5>
                                
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>
                                    <strong>Email Corporativo:</strong> Utilize o formato <code>nome.sobrenome@pgs.com</code>
                                    <button type="button" class="btn btn-outline-info btn-sm ms-2" data-bs-toggle="modal" data-bs-target="#emailModal">
                                        Ver exemplos
                                    </button>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="cargo" class="form-label">Cargo *</label>
                                        <select class="form-select" id="cargo" name="cargo">
                                            <option value="">Selecione o cargo</option>
                                            <option value="vendedor" <?php echo ($_POST['cargo'] ?? '') === 'vendedor' ? 'selected' : ''; ?>>Vendedor</option>
                                            <option value="atendente" <?php echo ($_POST['cargo'] ?? '') === 'atendente' ? 'selected' : ''; ?>>Atendente</option>
                                            <option value="estoquista" <?php echo ($_POST['cargo'] ?? '') === 'estoquista' ? 'selected' : ''; ?>>Estoquista</option>
                                            <option value="gerente" <?php echo ($_POST['cargo'] ?? '') === 'gerente' ? 'selected' : ''; ?>>Gerente</option>
                                            <option value="administrador" <?php echo ($_POST['cargo'] ?? '') === 'administrador' ? 'selected' : ''; ?>>Administrador</option>
                                        </select>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="departamento" class="form-label">Departamento *</label>
                                        <select class="form-select" id="departamento" name="departamento">
                                            <option value="">Selecione o departamento</option>
                                            <option value="vendas" <?php echo ($_POST['departamento'] ?? '') === 'vendas' ? 'selected' : ''; ?>>Vendas</option>
                                            <option value="atendimento" <?php echo ($_POST['departamento'] ?? '') === 'atendimento' ? 'selected' : ''; ?>>Atendimento</option>
                                            <option value="estoque" <?php echo ($_POST['departamento'] ?? '') === 'estoque' ? 'selected' : ''; ?>>Estoque</option>
                                            <option value="administrativo" <?php echo ($_POST['departamento'] ?? '') === 'administrativo' ? 'selected' : ''; ?>>Administrativo</option>
                                            <option value="ti" <?php echo ($_POST['departamento'] ?? '') === 'ti' ? 'selected' : ''; ?>>Tecnologia da Informação</option>
                                        </select>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="data_admissao" class="form-label">Data de Admissão *</label>
                                        <input type="date" class="form-control" id="data_admissao" name="data_admissao" 
                                               value="<?php echo $_POST['data_admissao'] ?? ''; ?>">
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="matricula" class="form-label">Matrícula</label>
                                        <input type="text" class="form-control" id="matricula" name="matricula" 
                                               value="<?php echo $_POST['matricula'] ?? ''; ?>" 
                                               placeholder="Opcional">
                                    </div>
                                </div>
                            </div>

                            <!-- Seção Endereço (Só para Clientes) -->
                            <div class="form-section" id="secao-endereco">
                                <h5 class="border-bottom pb-2 mb-4">
                                    <i class="fas fa-map-marker-alt me-2 text-info"></i>
                                    Endereço para Entrega
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-3 mb-3">
                                        <label for="cep" class="form-label">CEP *</label>
                                        <input type="text" class="form-control" id="cep" name="cep" 
                                               value="<?php echo $_POST['cep'] ?? ''; ?>" 
                                               placeholder="00000-000" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="logradouro" class="form-label">Logradouro *</label>
                                        <input type="text" class="form-control" id="logradouro" name="logradouro" 
                                               value="<?php echo $_POST['logradouro'] ?? ''; ?>" 
                                               placeholder="Rua, Avenida, etc." required>
                                    </div>
                                    
                                    <div class="col-md-3 mb-3">
                                        <label for="numero" class="form-label">Número *</label>
                                        <input type="text" class="form-control" id="numero" name="numero" 
                                               value="<?php echo $_POST['numero'] ?? ''; ?>" 
                                               placeholder="123" required>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="cidade" class="form-label">Cidade *</label>
                                        <input type="text" class="form-control" id="cidade" name="cidade" 
                                               value="<?php echo $_POST['cidade'] ?? ''; ?>" 
                                               placeholder="Sua cidade" required>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="estado" class="form-label">Estado *</label>
                                        <select class="form-select" id="estado" name="estado" required>
                                            <option value="">Selecione</option>
                                            <option value="AC">Acre</option>
                                            <option value="AL">Alagoas</option>
                                            <option value="AP">Amapá</option>
                                            <option value="AM">Amazonas</option>
                                            <option value="BA">Bahia</option>
                                            <option value="CE">Ceará</option>
                                            <option value="DF">Distrito Federal</option>
                                            <option value="ES">Espírito Santo</option>
                                            <option value="GO">Goiás</option>
                                            <option value="MA">Maranhão</option>
                                            <option value="MT">Mato Grosso</option>
                                            <option value="MS">Mato Grosso do Sul</option>
                                            <option value="MG">Minas Gerais</option>
                                            <option value="PA">Pará</option>
                                            <option value="PB">Paraíba</option>
                                            <option value="PR">Paraná</option>
                                            <option value="PE">Pernambuco</option>
                                            <option value="PI">Piauí</option>
                                            <option value="RJ">Rio de Janeiro</option>
                                            <option value="RN">Rio Grande do Norte</option>
                                            <option value="RS">Rio Grande do Sul</option>
                                            <option value="RO">Rondônia</option>
                                            <option value="RR">Roraima</option>
                                            <option value="SC">Santa Catarina</option>
                                            <option value="SP">São Paulo</option>
                                            <option value="SE">Sergipe</option>
                                            <option value="TO">Tocantins</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="d-grid mb-3">
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-user-plus me-2"></i>
                                    Finalizar Cadastro
                                </button>
                            </div>

                            <div class="text-center">
                                <a href="login.php" class="text-decoration-none">
                                    Já tem conta? <strong>Faça login</strong>
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="suporte.php" class="text-white text-decoration-none me-3">
                        <i class="fas fa-headset me-1"></i>Suporte
                    </a>
                    <a href="faq.php" class="text-white text-decoration-none">
                        <i class="fas fa-question-circle me-1"></i>FAQ
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <!-- Modal Informações sobre Tipos -->
    <div class="modal fade" id="infoModal" tabindex="-1" aria-labelledby="infoModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="infoModalLabel">
                        <i class="fas fa-info-circle me-2"></i>
                        Tipos de Cadastro - PGS Periféricos
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card border-primary h-100">
                                <div class="card-header bg-primary text-white">
                                    <h6 class="mb-0">
                                        <i class="fas fa-user me-2"></i>
                                        Cadastro como Cliente
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <h6 class="text-primary">✅ Para quem é:</h6>
                                    <ul class="small">
                                        <li>Pessoas que desejam comprar produtos</li>
                                        <li>Usuários comuns da loja online</li>
                                        <li>Quem quer acompanhar pedidos e histórico</li>
                                    </ul>
                                    
                                    <h6 class="text-primary">📝 O que precisa:</h6>
                                    <ul class="small">
                                        <li>Email pessoal (Gmail, Outlook, etc.)</li>
                                        <li>CPF válido</li>
                                        <li>Endereço para entrega</li>
                                        <li>Telefone para contato</li>
                                    </ul>
                                    
                                    <h6 class="text-primary">🎯 Benefícios:</h6>
                                    <ul class="small">
                                        <li>Histórico de pedidos</li>
                                        <li>Lista de desejos</li>
                                        <li>Ofertas exclusivas</li>
                                        <li>Checkout rápido</li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border-success h-100">
                                <div class="card-header bg-success text-white">
                                    <h6 class="mb-0">
                                        <i class="fas fa-user-tie me-2"></i>
                                        Cadastro como Funcionário
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <h6 class="text-success">✅ Para quem é:</h6>
                                    <ul class="small">
                                        <li>Colaboradores da PGS Periféricos</li>
                                        <li>Equipe administrativa</li>
                                        <li>Funcionários das lojas físicas</li>
                                        <li>Equipe de suporte</li>
                                    </ul>
                                    
                                    <h6 class="text-success">📝 O que precisa:</h6>
                                    <ul class="small">
                                        <li>Email corporativo (@pgs.com)</li>
                                        <li>Cargo e departamento</li>
                                        <li>Data de admissão</li>
                                        <li>Matrícula (opcional)</li>
                                    </ul>
                                    
                                    <h6 class="text-success">🎯 Benefícios:</h6>
                                    <ul class="small">
                                        <li>Acesso ao painel administrativo</li>
                                        <li>Gestão de pedidos e estoque</li>
                                        <li>Atendimento ao cliente</li>
                                        <li>Relatórios e analytics</li>
                                    </ul>
                                    
                                    <div class="alert alert-warning small mt-3">
                                        <i class="fas fa-exclamation-triangle me-1"></i>
                                        <strong>Atenção:</strong> O cadastro de funcionários precisa de aprovação da administração.
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Informações sobre Email -->
    <div class="modal fade" id="emailModal" tabindex="-1" aria-labelledby="emailModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="emailModalLabel">
                        <i class="fas fa-envelope me-2"></i>
                        Formato de Email
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-4">
                        <h6 class="text-primary">
                            <i class="fas fa-user me-1"></i>
                            Para Clientes:
                        </h6>
                        <p class="small">Use seu email pessoal normal:</p>
                        <div class="alert alert-light small">
                            <strong>Exemplos válidos:</strong><br>
                            • joao.silva@gmail.com<br>
                            • maria123@hotmail.com<br>
                            • pedro.oliveira@outlook.com
                        </div>
                    </div>
                    
                    <div>
                        <h6 class="text-success">
                            <i class="fas fa-user-tie me-1"></i>
                            Para Funcionários:
                        </h6>
                        <p class="small">Use o formato corporativo @pgs.com:</p>
                        <div class="alert alert-light small">
                            <strong>Formato correto:</strong><br>
                            • nome.sobrenome@pgs.com<br><br>
                            <strong>Exemplos válidos:</strong><br>
                            • carlos.souza@pgs.com<br>
                            • ana.rodrigues@pgs.com<br>
                            • lucas.oliveira@pgs.com
                        </div>
                        
                        <div class="alert alert-warning small">
                            <i class="fas fa-exclamation-triangle me-1"></i>
                            <strong>Importante:</strong> Funcionários devem usar obrigatoriamente email @pgs.com
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="assets/js/cadastro.js"></script>
    
    <script>
        // Validação de email em tempo real
        document.getElementById('email').addEventListener('blur', function() {
            const email = this.value;
            const tipoCadastro = document.getElementById('tipo_cadastro').value;
            const emailHelp = document.getElementById('email-help');
            
            if (email.includes('@pgs.com') && tipoCadastro === 'cliente') {
                this.classList.add('is-invalid');
                emailHelp.innerHTML = '<span class="text-danger">❌ Email corporativo não permitido para clientes. Use um email pessoal.</span>';
            } else if (!email.includes('@pgs.com') && tipoCadastro === 'funcionario') {
                this.classList.add('is-invalid');
                emailHelp.innerHTML = '<span class="text-danger">❌ Email pessoal não permitido para funcionários. Use nome.sobrenome@pgs.com</span>';
            } else {
                this.classList.remove('is-invalid');
                if (tipoCadastro === 'cliente') {
                    emailHelp.textContent = 'Digite seu email pessoal';
                } else {
                    emailHelp.textContent = 'Para funcionários: nome.sobrenome@pgs.com';
                }
            }
        });

        // Atualizar validação quando mudar o tipo
        function selecionarTipo(tipo) {
            document.getElementById('tipo_cadastro').value = tipo;
            
            const btnCliente = document.getElementById('btn-cliente');
            const btnFuncionario = document.getElementById('btn-funcionario');
            const secaoFuncionario = document.getElementById('secao-funcionario');
            const secaoEndereco = document.getElementById('secao-endereco');
            const emailHelp = document.getElementById('email-help');
            const emailInput = document.getElementById('email');
            
            if (tipo === 'cliente') {
                // Ativar cliente
                btnCliente.classList.add('active');
                btnFuncionario.classList.remove('active');
                secaoFuncionario.style.display = 'none';
                secaoEndereco.style.display = 'block';
                emailHelp.textContent = 'Digite seu email pessoal';
                
                // Validar email atual
                if (emailInput.value.includes('@pgs.com')) {
                    emailInput.classList.add('is-invalid');
                    emailHelp.innerHTML = '<span class="text-danger">❌ Email corporativo não permitido para clientes. Use um email pessoal.</span>';
                } else {
                    emailInput.classList.remove('is-invalid');
                }
                
                // Campos obrigatórios
                document.getElementById('cpf').required = true;
                document.getElementById('cep').required = true;
                document.getElementById('logradouro').required = true;
                document.getElementById('numero').required = true;
                document.getElementById('cidade').required = true;
                document.getElementById('estado').required = true;
                
            } else {
                // Ativar funcionário
                btnFuncionario.classList.add('active');
                btnCliente.classList.remove('active');
                secaoFuncionario.style.display = 'block';
                secaoEndereco.style.display = 'none';
                emailHelp.textContent = 'Para funcionários: nome.sobrenome@pgs.com';
                
                // Validar email atual
                if (!emailInput.value.includes('@pgs.com') && emailInput.value !== '') {
                    emailInput.classList.add('is-invalid');
                    emailHelp.innerHTML = '<span class="text-danger">❌ Email pessoal não permitido para funcionários. Use nome.sobrenome@pgs.com</span>';
                } else {
                    emailInput.classList.remove('is-invalid');
                }
                
                // Campos não obrigatórios para funcionário
                document.getElementById('cpf').required = false;
                document.getElementById('cep').required = false;
                document.getElementById('logradouro').required = false;
                document.getElementById('numero').required = false;
                document.getElementById('cidade').required = false;
                document.getElementById('estado').required = false;
            }
        }

        // Inicializar como cliente
        document.addEventListener('DOMContentLoaded', function() {
            selecionarTipo('cliente');
        });
    </script>
</body>
</html>