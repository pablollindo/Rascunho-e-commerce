<?php
require_once 'config.php';
require_once 'funcoes.php';

// Ativar exibição de erros para debug
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Sanitizar dados
    $nome = sanitizar($_POST['nome'] ?? '');
    $email = sanitizar($_POST['email'] ?? '');
    $senha = $_POST['senha'] ?? '';
    $confirmar_senha = $_POST['confirmar_senha'] ?? '';
    $cpf = sanitizar($_POST['cpf'] ?? '');
    $telefone = sanitizar($_POST['telefone'] ?? '');
    $data_nascimento = $_POST['data_nascimento'] ?? '';
    $tipo_cadastro = $_POST['tipo_cadastro'] ?? 'cliente';

    // Campos específicos de funcionário
    $cargo = sanitizar($_POST['cargo'] ?? '');
    $departamento = sanitizar($_POST['departamento'] ?? '');
    $data_admissao = $_POST['data_admissao'] ?? '';
    $matricula = sanitizar($_POST['matricula'] ?? '');

    // Campos de endereço (só para clientes)
    $cep = sanitizar($_POST['cep'] ?? '');
    $logradouro = sanitizar($_POST['logradouro'] ?? '');
    $numero = sanitizar($_POST['numero'] ?? '');
    $cidade = sanitizar($_POST['cidade'] ?? '');
    $estado = sanitizar($_POST['estado'] ?? '');

    // Validar dados básicos
    if (empty($nome) || empty($email) || empty($senha) || empty($confirmar_senha)) {
        $_SESSION['erro'] = "Por favor, preencha todos os campos obrigatórios.";
        $_SESSION['dados_form'] = $_POST;
        header("Location: ../cadastro.php");
        exit;
    }

    if (!validarEmail($email)) {
        $_SESSION['erro'] = "Por favor, insira um email válido.";
        $_SESSION['dados_form'] = $_POST;
        header("Location: ../cadastro.php");
        exit;
    }

    if ($senha !== $confirmar_senha) {
        $_SESSION['erro'] = "As senhas não coincidem.";
        $_SESSION['dados_form'] = $_POST;
        header("Location: ../cadastro.php");
        exit;
    }

    if (strlen($senha) < 6) {
        $_SESSION['erro'] = "A senha deve ter pelo menos 6 caracteres.";
        $_SESSION['dados_form'] = $_POST;
        header("Location: ../cadastro.php");
        exit;
    }

    // VALIDAÇÃO DE EMAIL POR TIPO DE CADASTRO
    if ($tipo_cadastro === 'cliente') {
        // Cliente NÃO pode usar email @pgs.com
        if (strpos($email, '@pgs.com') !== false) {
            $_SESSION['erro'] = "❌ Email corporativo não permitido para clientes.<br><small>Para cadastro como cliente, use um email pessoal (Gmail, Outlook, etc.).<br>Se você é funcionário, selecione 'Cadastro como Funcionário'.</small>";
            $_SESSION['dados_form'] = $_POST;
            header("Location: ../cadastro.php");
            exit;
        }

        if (empty($cpf) || !validarCPF($cpf)) {
            $_SESSION['erro'] = "CPF inválido ou não informado.";
            $_SESSION['dados_form'] = $_POST;
            header("Location: ../cadastro.php");
            exit;
        }

    } else if ($tipo_cadastro === 'funcionario') {
        // Funcionário DEVE usar email @pgs.com
        if (strpos($email, '@pgs.com') === false) {
            $_SESSION['erro'] = "❌ Email pessoal não permitido para funcionários.<br><small>Para cadastro como funcionário, use um email corporativo @pgs.com.<br>Exemplo: nome.sobrenome@pgs.com</small>";
            $_SESSION['dados_form'] = $_POST;
            header("Location: ../cadastro.php");
            exit;
        }

        if (empty($cargo) || empty($departamento) || empty($data_admissao)) {
            $_SESSION['erro'] = "Por favor, preencha todos os dados profissionais.";
            $_SESSION['dados_form'] = $_POST;
            header("Location: ../cadastro.php");
            exit;
        }
    }

    try {
        // Verificar se email já existe
        $sql = "SELECT id FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $_SESSION['erro'] = "Este email já está cadastrado.";
            $_SESSION['dados_form'] = $_POST;
            header("Location: ../cadastro.php");
            exit;
        }

        // Verificar se CPF já existe (para clientes)
        if (!empty($cpf) && $tipo_cadastro === 'cliente') {
            $sql = "SELECT id FROM usuarios WHERE cpf = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $cpf);
            $stmt->execute();
            $result = $stmt->get_result();
            
            if ($result->num_rows > 0) {
                $_SESSION['erro'] = "Este CPF já está cadastrado.";
                $_SESSION['dados_form'] = $_POST;
                header("Location: ../cadastro.php");
                exit;
            }
        }

        // Inserir na tabela USUARIOS
        $sql_usuario = "INSERT INTO usuarios (nome, email, senha, tipo, cpf, telefone, data_nascimento) 
                       VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt_usuario = $conn->prepare($sql_usuario);
        
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        $cpf_formatado = !empty($cpf) ? preg_replace('/[^0-9]/', '', $cpf) : null;
        $telefone_formatado = !empty($telefone) ? preg_replace('/[^0-9]/', '', $telefone) : null;
        $data_nascimento_formatada = !empty($data_nascimento) ? $data_nascimento : null;
        
        if ($stmt_usuario->bind_param("sssssss", $nome, $email, $senha_hash, $tipo_cadastro, $cpf_formatado, $telefone_formatado, $data_nascimento_formatada)) {
            if ($stmt_usuario->execute()) {
                $usuario_id = $stmt_usuario->insert_id;
                
                if ($tipo_cadastro === 'cliente') {
                    // Inserir na tabela CLIENTES
                    $sql_cliente = "INSERT INTO clientes (usuario_id, nome, email, cpf, telefone, data_nascimento) 
                                  VALUES (?, ?, ?, ?, ?, ?)";
                    $stmt_cliente = $conn->prepare($sql_cliente);
                    if ($stmt_cliente->bind_param("isssss", $usuario_id, $nome, $email, $cpf_formatado, $telefone_formatado, $data_nascimento_formatada)) {
                        $stmt_cliente->execute();
                    }
                    $stmt_cliente->close();
                    
                    // Inserir endereço - CORRIGIDO com bairro
                    if (!empty($cep)) {
                        $bairro = "Centro"; // Valor padrão, você pode adicionar campo no formulário depois
                        $sql_endereco = "INSERT INTO enderecos (usuario_id, titulo, cep, logradouro, numero, complemento, bairro, cidade, estado, principal) 
                                       VALUES (?, 'Principal', ?, ?, ?, '', ?, ?, ?, 1)";
                        $stmt_end = $conn->prepare($sql_endereco);
                        if ($stmt_end->bind_param("issssss", $usuario_id, $cep, $logradouro, $numero, $bairro, $cidade, $estado)) {
                            $stmt_end->execute();
                        }
                        $stmt_end->close();
                    }
                    
                } else if ($tipo_cadastro === 'funcionario') {
                    // Inserir na tabela FUNCIONARIOS
                    $sql_funcionario = "INSERT INTO funcionarios (usuario_id, nome, email, cpf, telefone, data_nascimento, cargo, departamento, data_admissao, matricula) 
                                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    $stmt_func = $conn->prepare($sql_funcionario);
                    $matricula_valor = !empty($matricula) ? $matricula : NULL;
                    if ($stmt_func->bind_param("isssssssss", $usuario_id, $nome, $email, $cpf_formatado, $telefone_formatado, $data_nascimento_formatada, $cargo, $departamento, $data_admissao, $matricula_valor)) {
                        $stmt_func->execute();
                    }
                    $stmt_func->close();
                }
                
                $_SESSION['sucesso'] = "Cadastro realizado com sucesso!";
                if ($tipo_cadastro === 'cliente') {
                    $_SESSION['sucesso'] .= " Faça login para continuar.";
                    header("Location: ../login.php");
                } else {
                    $_SESSION['sucesso'] .= " Aguarde a ativação pela administração.";
                    header("Location: ../login.php");
                }
                exit;
                
            } else {
                $_SESSION['erro'] = "Erro ao executar cadastro: " . $stmt_usuario->error;
                $_SESSION['dados_form'] = $_POST;
                header("Location: ../cadastro.php");
                exit;
            }
        } else {
            $_SESSION['erro'] = "Erro ao preparar statement: " . $stmt_usuario->error;
            $_SESSION['dados_form'] = $_POST;
            header("Location: ../cadastro.php");
            exit;
        }
        
        $stmt_usuario->close();
        
    } catch (Exception $e) {
        $_SESSION['erro'] = "Erro ao processar cadastro: " . $e->getMessage();
        $_SESSION['dados_form'] = $_POST;
        header("Location: ../cadastro.php");
        exit;
    }
} else {
    // Se não for POST, redirecionar
    header("Location: ../cadastro.php");
    exit;
}
?>