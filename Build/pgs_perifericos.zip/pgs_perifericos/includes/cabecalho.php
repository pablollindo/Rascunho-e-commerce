<?php
// Iniciar sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<!-- Header -->
<header class="bg-dark text-white sticky-top">
    <div class="container">
        <div class="row align-items-center py-2">
            <!-- Logo -->
            <div class="col-md-2">
                <a href="index.php" class="text-decoration-none">
                    <h3 class="text-warning mb-0">
                        <i class="fas fa-gamepad me-2"></i>
                        PGS Periféricos
                    </h3>
                </a>
            </div>

            <!-- Barra de Pesquisa -->
            <div class="col-md-5">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Buscar produtos...">
                    <button class="btn btn-warning" type="button">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>

            <!-- Menu Usuário -->
            <div class="col-md-5 text-end">
                <div class="d-flex justify-content-end align-items-center">
                    <?php if (usuarioEstaLogado()): ?>
                        <div class="dropdown">
                            <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                <i class="fas fa-user me-1"></i>
                                <?php echo $_SESSION['usuario_nome']; ?>
                            </button>
                            <ul class="dropdown-menu">
                                <?php if ($_SESSION['usuario_tipo'] === 'cliente'): ?>
                                    <li><a class="dropdown-item" href="minha_conta.php"><i class="fas fa-user me-2"></i>Minha Conta</a></li>
                                    <li><a class="dropdown-item" href="meus_pedidos.php"><i class="fas fa-shopping-bag me-2"></i>Meus Pedidos</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                <?php elseif (isFuncionario()): ?>
                                    <li><a class="dropdown-item" href="admin/admin.php"><i class="fas fa-cog me-2"></i>Painel Admin</a></li>
                                    <li><hr class="dropdown-divider"></li>
                                <?php endif; ?>
                                <li><a class="dropdown-item text-danger" href="includes/logout.php"><i class="fas fa-sign-out-alt me-2"></i>Sair</a></li>
                            </ul>
                        </div>
                    <?php else: ?>
                        <a href="login.php" class="text-white text-decoration-none me-3">
                            <i class="fas fa-user me-1"></i>
                            Entrar
                        </a>
                    <?php endif; ?>
                    
                    <a href="carrinho.php" class="text-white text-decoration-none">
                        <i class="fas fa-shopping-cart me-1"></i>
                        Carrinho
                        <span class="badge bg-warning text-dark">
                            <?php 
                            if (isset($_SESSION['carrinho']) && is_array($_SESSION['carrinho'])) {
                                echo count($_SESSION['carrinho']);
                            } else {
                                echo '0';
                            }
                            ?>
                        </span>
                    </a>
                </div>
            </div>
        </div>
    </div>

    <!-- Menu de Navegação -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
        <div class="container">
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php">
                            <i class="fas fa-home me-1"></i>Início
                        </a>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-keyboard me-1"></i>Teclados
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="produtos.php?categoria=1">Mecânicos</a></li>
                            <li><a class="dropdown-item" href="produtos.php?categoria=1">Membrana</a></li>
                            <li><a class="dropdown-item" href="produtos.php?categoria=1">Gaming</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                            <i class="fas fa-mouse me-1"></i>Mouses
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="produtos.php?categoria=2">Gaming</a></li>
                            <li><a class="dropdown-item" href="produtos.php?categoria=2">Sem Fio</a></li>
                            <li><a class="dropdown-item" href="produtos.php?categoria=2">Ópticos</a></li>
                        </ul>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=3">
                            <i class="fas fa-headphones me-1"></i>Headsets
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="produtos.php?categoria=4">
                            <i class="fas fa-desktop me-1"></i>Monitores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="promocoes.php">
                            <i class="fas fa-tag me-1"></i>Promoções
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<?php mostrarMensagem(); ?>