<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

echo "<h1>Teste do Carrinho</h1>";

// Testar sessão
echo "<p>Sessão iniciada: " . (isset($_SESSION) ? 'Sim' : 'Não') . "</p>";

// Testar funções
echo "<p>Usuário logado: " . (usuarioEstaLogado() ? 'Sim' : 'Não') . "</p>";
echo "<p>É admin: " . (isAdmin() ? 'Sim' : 'Não') . "</p>";

// Testar carrinho
if (isset($_SESSION['carrinho'])) {
    echo "<p>Itens no carrinho: " . count($_SESSION['carrinho']) . "</p>";
} else {
    echo "<p>Carrinho vazio</p>";
}

// Testar conexão com banco
try {
    $pdo = conectarBanco();
    echo "<p>Conexão com banco: OK</p>";
} catch (Exception $e) {
    echo "<p>Erro na conexão: " . $e->getMessage() . "</p>";
}
?>