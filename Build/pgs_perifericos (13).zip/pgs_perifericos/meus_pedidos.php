<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se o usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = 'Você precisa estar logado para ver seus pedidos.';
    header('Location: login.php?redirect=meus_pedidos');
    exit;
}

// VERIFICAÇÃO: Bloquear funcionários/admin
if (isAdmin() || isFuncionario()) {
    $_SESSION['erro'] = 'Funcionários e administradores não podem realizar compras.';
    header('Location: indexx.php');
    exit;
}

// Calcular total de itens no carrinho para o badge
$total_itens_carrinho = 0;
if (isset($_SESSION['carrinho']) && !empty($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $item) {
        $total_itens_carrinho += $item['quantidade'];
    }
}

$usuario_id = $_SESSION['usuario_id'];

// Buscar pedidos do usuário
try {
    $sql_pedidos = "SELECT p.*, 
                    COUNT(ip.id) as total_itens,
                    SUM(ip.quantidade) as total_produtos
                    FROM pedidos p 
                    LEFT JOIN itens_pedido ip ON p.id = ip.pedido_id 
                    WHERE p.cliente_id = ? 
                    GROUP BY p.id 
                    ORDER BY p.data_pedido DESC";
    
    $stmt_pedidos = $conn->prepare($sql_pedidos);
    $stmt_pedidos->bind_param("i", $usuario_id);
    $stmt_pedidos->execute();
    $result_pedidos = $stmt_pedidos->get_result();
    $pedidos = [];
    
    while ($pedido = $result_pedidos->fetch_assoc()) {
        // Buscar itens de cada pedido
        $sql_itens = "SELECT ip.*, pr.nome as produto_nome, pr.imagem as produto_imagem
                     FROM itens_pedido ip 
                     LEFT JOIN produtos pr ON ip.produto_id = pr.id 
                     WHERE ip.pedido_id = ?";
        
        $stmt_itens = $conn->prepare($sql_itens);
        $stmt_itens->bind_param("i", $pedido['id']);
        $stmt_itens->execute();
        $result_itens = $stmt_itens->get_result();
        $itens_pedido = [];
        
        while ($item = $result_itens->fetch_assoc()) {
            $itens_pedido[] = $item;
        }
        
        $pedido['itens'] = $itens_pedido;
        $pedidos[] = $pedido;
    }
    
} catch (Exception $e) {
    error_log("Erro ao buscar pedidos: " . $e->getMessage());
    $pedidos = [];
    $_SESSION['erro'] = "Erro ao carregar seus pedidos.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Meus Pedidos - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <style>
        .status-badge {
            font-size: 0.8em;
            padding: 0.5em 1em;
        }
        .pedido-card {
            transition: transform 0.2s;
            border: 1px solid #dee2e6;
        }
        .pedido-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .produto-img {
            width: 60px;
            height: 60px;
            object-fit: cover;
        }
        .expand-btn {
            background: none;
            border: none;
            color: #007bff;
            cursor: pointer;
        }
        .expand-btn:hover {
            color: #0056b3;
        }
        .itens-pedido {
            background: #f8f9fa;
            border-radius: 8px;
        }
        .pedido-id {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 0.8rem 1.5rem;
            border-radius: 12px;
            font-weight: bold;
            font-size: 1.3em;
            text-align: center;
            box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
        }
        .pedido-info {
            background: #f8f9fa;
            border-radius: 8px;
            padding: 1rem;
        }
    </style>
</head>
<body>
    <!-- Header Simplificado -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-4">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Menu Usuário Simplificado -->
                <div class="col-md-8 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <a href="indexx.php" class="text-white text-decoration-none me-3">
                            <i class="fas fa-home me-1"></i>
                            Início
                        </a>
                        <a href="produtos.php?promocao=1" class="text-white text-decoration-none me-3">
                            <i class="fas fa-tag me-1"></i>
                            Promoções
                        </a>
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none position-relative">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <?php if ($total_itens_carrinho > 0): ?>
                                <span class="badge bg-warning text-dark position-absolute top-0 start-100 translate-middle">
                                    <?php echo $total_itens_carrinho; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-shopping-bag text-primary me-2"></i>
                        Meus Pedidos
                    </h1>
                    <div class="breadcrumb-nav">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                                <li class="breadcrumb-item"><a href="minha_conta.php">Minha Conta</a></li>
                                <li class="breadcrumb-item active">Meus Pedidos</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Mensagens do Sistema -->
                <?php mostrarMensagem(); ?>

                <?php if (empty($pedidos)): ?>
                    <!-- Nenhum Pedido -->
                    <div class="text-center py-5">
                        <div class="empty-orders-icon mb-4">
                            <i class="fas fa-shopping-bag fa-5x text-muted"></i>
                        </div>
                        <h3 class="text-muted mb-3">Você ainda não fez nenhum pedido</h3>
                        <p class="text-muted mb-4">Que tal dar uma olhada em nossos produtos incríveis?</p>
                        <a href="produtos.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Começar a Comprar
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Lista de Pedidos -->
                    <div class="row">
                        <div class="col-12">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <h4 class="mb-0">
                                    <?php echo count($pedidos); ?> pedido(s) encontrado(s)
                                </h4>
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Clique em um pedido para ver os detalhes
                                </small>
                            </div>

                            <?php foreach ($pedidos as $pedido): ?>
                            <div class="card shadow-sm mb-4 pedido-card">
                                <div class="card-header bg-light">
                                    <div class="row align-items-center">
                                        <div class="col-md-5">
                                            <!-- ID REAL DO PEDIDO EM DESTAQUE -->
                                            <div class="pedido-id">
                                                <i class="fas fa-receipt me-2"></i>
                                                PEDIDO #<?php echo $pedido['id']; ?>
                                            </div>
                                        </div>
                                        <div class="col-md-4 text-center">
                                            <small class="text-muted">
                                                <i class="fas fa-calendar me-1"></i>
                                                Realizado em: <?php echo date('d/m/Y H:i', strtotime($pedido['data_pedido'])); ?>
                                            </small>
                                        </div>
                                        <div class="col-md-3 text-end">
                                            <span class="badge status-badge 
                                                <?php 
                                                switch($pedido['status']) {
                                                    case 'pendente': echo 'bg-warning'; break;
                                                    case 'pago': echo 'bg-info'; break;
                                                    case 'processando': echo 'bg-primary'; break;
                                                    case 'enviado': echo 'bg-success'; break;
                                                    case 'entregue': echo 'bg-success'; break;
                                                    case 'cancelado': echo 'bg-danger'; break;
                                                    default: echo 'bg-secondary';
                                                }
                                                ?>">
                                                <i class="fas 
                                                    <?php 
                                                    switch($pedido['status']) {
                                                        case 'pendente': echo 'fa-clock'; break;
                                                        case 'pago': echo 'fa-check-circle'; break;
                                                        case 'processando': echo 'fa-cog'; break;
                                                        case 'enviado': echo 'fa-shipping-fast'; break;
                                                        case 'entregue': echo 'fa-box-open'; break;
                                                        case 'cancelado': echo 'fa-times-circle'; break;
                                                        default: echo 'fa-question';
                                                    }
                                                    ?> me-1"></i>
                                                <?php echo ucfirst($pedido['status']); ?>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="card-body">
                                    <!-- Informações Principais -->
                                    <div class="pedido-info mb-3">
                                        <div class="row">
                                            <div class="col-md-3">
                                                <strong><i class="fas fa-credit-card me-1"></i>Pagamento:</strong><br>
                                                <span class="badge bg-secondary">
                                                    <?php 
                                                    switch($pedido['metodo_pagamento']) {
                                                        case 'cartao': echo 'Cartão de Crédito'; break;
                                                        case 'pix': echo 'PIX'; break;
                                                        case 'boleto': echo 'Boleto'; break;
                                                        default: echo $pedido['metodo_pagamento'];
                                                    }
                                                    ?>
                                                </span>
                                            </div>
                                            <div class="col-md-3">
                                                <strong><i class="fas fa-box me-1"></i>Itens:</strong><br>
                                                <?php echo $pedido['total_produtos']; ?> produto(s)
                                            </div>
                                            <div class="col-md-3">
                                                <strong><i class="fas fa-receipt me-1"></i>Subtotal:</strong><br>
                                                R$ <?php echo number_format($pedido['subtotal'], 2, ',', '.'); ?>
                                            </div>
                                            <div class="col-md-3">
                                                <strong><i class="fas fa-tag me-1"></i>Total:</strong><br>
                                                <span class="h5 text-primary">
                                                    R$ <?php echo number_format($pedido['total'], 2, ',', '.'); ?>
                                                </span>
                                            </div>
                                        </div>
                                    </div>

                                    <!-- Itens do Pedido (Expandível) -->
                                    <div class="itens-pedido p-3">
                                        <button class="expand-btn w-100 text-start" type="button" data-bs-toggle="collapse" data-bs-target="#itens-<?php echo $pedido['id']; ?>">
                                            <i class="fas fa-chevron-down me-2"></i>
                                            Ver produtos deste pedido (<?php echo count($pedido['itens']); ?> itens)
                                        </button>
                                        
                                        <div class="collapse mt-3" id="itens-<?php echo $pedido['id']; ?>">
                                            <?php foreach ($pedido['itens'] as $item): ?>
                                            <div class="d-flex align-items-center mb-3 pb-2 border-bottom">
                                                <img src="<?php echo !empty($item['produto_imagem']) ? $item['produto_imagem'] : 'assets/imagens/produtos/sem-imagem.jpg'; ?>" 
                                                     alt="<?php echo htmlspecialchars($item['produto_nome']); ?>" 
                                                     class="produto-img me-3 rounded">
                                                <div class="flex-grow-1">
                                                    <h6 class="mb-1"><?php echo htmlspecialchars($item['produto_nome']); ?></h6>
                                                    <div class="d-flex justify-content-between">
                                                        <small class="text-muted">
                                                            Quantidade: <?php echo $item['quantidade']; ?>
                                                        </small>
                                                        <small class="text-muted">
                                                            Preço unitário: R$ <?php echo number_format($item['preco_unitario'], 2, ',', '.'); ?>
                                                        </small>
                                                        <strong>
                                                            Subtotal: R$ <?php echo number_format($item['preco_unitario'] * $item['quantidade'], 2, ',', '.'); ?>
                                                        </strong>
                                                    </div>
                                                </div>
                                            </div>
                                            <?php endforeach; ?>
                                        </div>
                                    </div>

                                    <!-- Datas Importantes -->
                                    <?php if ($pedido['data_pagamento'] || $pedido['data_envio']): ?>
                                    <div class="mt-3">
                                        <small class="text-muted">
                                            <strong><i class="fas fa-history me-1"></i>Datas importantes:</strong>
                                            <?php if ($pedido['data_pagamento']): ?>
                                                • Pago em: <?php echo date('d/m/Y H:i', strtotime($pedido['data_pagamento'])); ?>
                                            <?php endif; ?>
                                            <?php if ($pedido['data_envio']): ?>
                                                • Enviado em: <?php echo date('d/m/Y H:i', strtotime($pedido['data_envio'])); ?>
                                            <?php endif; ?>
                                        </small>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Adicionar animação suave aos botões de expandir
        document.addEventListener('DOMContentLoaded', function() {
            const expandButtons = document.querySelectorAll('.expand-btn');
            
            expandButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const icon = this.querySelector('i');
                    if (icon.classList.contains('fa-chevron-down')) {
                        icon.classList.remove('fa-chevron-down');
                        icon.classList.add('fa-chevron-up');
                    } else {
                        icon.classList.remove('fa-chevron-up');
                        icon.classList.add('fa-chevron-down');
                    }
                });
            });
        });
    </script>
</body>
</html>