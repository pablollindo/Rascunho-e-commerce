<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// VERIFICAÇÃO: Bloquear funcionários/admin de finalizar compra
if (usuarioEstaLogado() && (isAdmin() || isFuncionario())) {
    $_SESSION['erro'] = 'Funcionários e administradores não podem realizar compras.';
    header('Location: indexx.php');
    exit;
}

// Verificar se o usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = 'Você precisa estar logado para finalizar a compra.';
    header('Location: login.php?redirect=finalizar_compra');
    exit;
}

// Verificar se o carrinho não está vazio
if (!isset($_SESSION['carrinho']) || empty($_SESSION['carrinho'])) {
    $_SESSION['erro'] = 'Seu carrinho está vazio.';
    header('Location: carrinho.php');
    exit;
}

// Calcular total de itens no carrinho para o badge
$total_itens_carrinho = 0;
if (isset($_SESSION['carrinho']) && !empty($_SESSION['carrinho'])) {
    foreach ($_SESSION['carrinho'] as $item) {
        $total_itens_carrinho += $item['quantidade'];
    }
}

// Buscar informações do usuário
$usuario_id = $_SESSION['usuario_id'];
$sql_usuario = "SELECT * FROM usuarios WHERE id = ?";
$stmt_usuario = $conn->prepare($sql_usuario);
$stmt_usuario->bind_param("i", $usuario_id);
$stmt_usuario->execute();
$result_usuario = $stmt_usuario->get_result();
$usuario = $result_usuario->fetch_assoc();

// Buscar endereços do usuário
$sql_enderecos = "SELECT * FROM enderecos WHERE usuario_id = ? ORDER BY principal DESC";
$stmt_enderecos = $conn->prepare($sql_enderecos);
$stmt_enderecos->bind_param("i", $usuario_id);
$stmt_enderecos->execute();
$result_enderecos = $stmt_enderecos->get_result();
$enderecos = [];
while ($endereco = $result_enderecos->fetch_assoc()) {
    $enderecos[] = $endereco;
}

// Buscar informações dos produtos no carrinho
$carrinho_detalhado = [];
$subtotal = 0;
$total_itens = 0;

$produtos_ids = array_keys($_SESSION['carrinho']);
$placeholders = str_repeat('?,', count($produtos_ids) - 1) . '?';

$sql = "SELECT p.*, m.nome as marca_nome, c.nome as categoria_nome 
        FROM produtos p 
        LEFT JOIN marcas m ON p.marca_id = m.id 
        LEFT JOIN categorias c ON p.categoria_id = c.id 
        WHERE p.id IN ($placeholders) AND p.ativo = 1";

$stmt = $conn->prepare($sql);
$types = str_repeat('i', count($produtos_ids));
$stmt->bind_param($types, ...$produtos_ids);
$stmt->execute();
$result = $stmt->get_result();

while ($produto = $result->fetch_assoc()) {
    $produto_id = $produto['id'];
    $carrinho_detalhado[$produto_id] = array_merge(
        $produto,
        $_SESSION['carrinho'][$produto_id]
    );
    
    // Calcular totais
    $preco = $produto['preco_promocional'] && $produto['preco_promocional'] > 0 ? $produto['preco_promocional'] : $produto['preco'];
    $subtotal += $preco * $_SESSION['carrinho'][$produto_id]['quantidade'];
    $total_itens += $_SESSION['carrinho'][$produto_id]['quantidade'];
}

// Calcular frete e total
$frete = $subtotal >= 299.90 ? 0 : 29.90;
$total = $subtotal + $frete;

// Processar finalização da compra
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['finalizar_compra'])) {
    try {
        // Iniciar transação
        $conn->begin_transaction();
        
        // Preparar dados do pagamento
        $metodo_pagamento = $_POST['metodo_pagamento'];
        $numero_cartao = '';
        $nome_titular = '';
        $data_vencimento = '';
        $codigo_seguranca = '';
        $codigo_pix = '';
        $codigo_boleto = '';
        
        // Se for cartão, capturar dados do cartão
        if ($metodo_pagamento === 'cartao') {
            $numero_cartao = substr($_POST['numero_cartao'], -4); // Salvar apenas últimos 4 dígitos
            $nome_titular = $_POST['nome_titular'];
            $data_vencimento = $_POST['data_vencimento'];
            $codigo_seguranca = $_POST['codigo_seguranca'];
        }
        
        // Se for PIX, gerar código PIX
        if ($metodo_pagamento === 'pix') {
            $codigo_pix = 'PIX' . date('YmdHis') . rand(1000, 9999);
        }
        
        // Se for boleto, gerar código do boleto
        if ($metodo_pagamento === 'boleto') {
            $codigo_boleto = '34191.11111 11111.111111 11111.111111 1 111100000' . rand(10000, 99999);
        }
        
        // 1. Criar o pedido - CORRIGIDO: número correto de placeholders
        $sql_pedido = "INSERT INTO pedidos (
            cliente_id, total, subtotal, desconto, status, metodo_pagamento,
            numero_cartao, nome_titular, data_vencimento, codigo_seguranca,
            codigo_pix, codigo_boleto, endereco_entrega
        ) VALUES (?, ?, ?, ?, 'pendente', ?, ?, ?, ?, ?, ?, ?, ?)";
        
        $stmt_pedido = $conn->prepare($sql_pedido);
        
        $endereco_selecionado = null;
        foreach ($enderecos as $endereco) {
            if ($endereco['id'] == $_POST['endereco_entrega']) {
                $endereco_selecionado = $endereco;
                break;
            }
        }
        
        if ($endereco_selecionado) {
            $endereco_entrega = "{$endereco_selecionado['logradouro']}, {$endereco_selecionado['numero']}";
            if (!empty($endereco_selecionado['complemento'])) {
                $endereco_entrega .= " - {$endereco_selecionado['complemento']}";
            }
            $endereco_entrega .= " - {$endereco_selecionado['bairro']} - {$endereco_selecionado['cidade']}/{$endereco_selecionado['estado']} - CEP: {$endereco_selecionado['cep']}";
        } else {
            $endereco_entrega = "Endereço não especificado";
        }
        
        // CORREÇÃO: Adicionar o parâmetro do desconto que estava faltando
        $desconto = 0; // Você pode calcular descontos se tiver cupons
        
        // CORREÇÃO: Número correto de parâmetros - 13 parâmetros no total
        $stmt_pedido->bind_param(
            "idddssssssss", // CORRIGIDO: 13 caracteres para 13 parâmetros
            $usuario_id, 
            $total, 
            $subtotal, 
            $desconto,
            $metodo_pagamento,
            $numero_cartao, 
            $nome_titular, 
            $data_vencimento, 
            $codigo_seguranca,
            $codigo_pix, 
            $codigo_boleto, 
            $endereco_entrega
        );
        
        $stmt_pedido->execute();
        $pedido_id = $conn->insert_id;
        
        // 2. Adicionar itens ao pedido
        $sql_item = "INSERT INTO itens_pedido (pedido_id, produto_id, quantidade, preco_unitario) 
                     VALUES (?, ?, ?, ?)";
        $stmt_item = $conn->prepare($sql_item);
        
        foreach ($carrinho_detalhado as $produto_id => $item) {
            $preco_unitario = $item['preco_promocional'] && $item['preco_promocional'] > 0 ? $item['preco_promocional'] : $item['preco'];
            $quantidade = $item['quantidade'];
            
            $stmt_item->bind_param("iiid", $pedido_id, $produto_id, $quantidade, $preco_unitario);
            $stmt_item->execute();
            
            // 3. Atualizar estoque
            $sql_estoque = "UPDATE produtos SET estoque = estoque - ? WHERE id = ?";
            $stmt_estoque = $conn->prepare($sql_estoque);
            $stmt_estoque->bind_param("ii", $quantidade, $produto_id);
            $stmt_estoque->execute();
        }
        
        // Confirmar transação
        $conn->commit();
        
        // Limpar carrinho
        $_SESSION['carrinho'] = [];
        
        // Redirecionar para página de sucesso
        $_SESSION['sucesso'] = "Pedido #{$pedido_id} realizado com sucesso!";
        header('Location: meus_pedidos.php');
        exit;
        
    } catch (Exception $e) {
        // Reverter transação em caso de erro
        $conn->rollback();
        $_SESSION['erro'] = "Erro ao processar pedido: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Finalizar Compra - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <style>
        .dados-cartao {
            display: none;
            background: #f8f9fa;
            border-radius: 8px;
            padding: 20px;
            margin-top: 15px;
        }
        .cartao-ativo {
            display: block;
        }
    </style>
</head>
<body>
    <!-- Header Simplificado -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-4">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Menu Usuário Simplificado -->
                <div class="col-md-8 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <a href="indexx.php" class="text-white text-decoration-none me-3">
                            <i class="fas fa-home me-1"></i>
                            Início
                        </a>
                        <a href="produtos.php?promocao=1" class="text-white text-decoration-none me-3">
                            <i class="fas fa-tag me-1"></i>
                            Promoções
                        </a>
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none position-relative">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <?php if ($total_itens_carrinho > 0): ?>
                                <span class="badge bg-warning text-dark position-absolute top-0 start-100 translate-middle">
                                    <?php echo $total_itens_carrinho; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-credit-card text-primary me-2"></i>
                        Finalizar Compra
                    </h1>
                    <div class="breadcrumb-nav">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                                <li class="breadcrumb-item"><a href="carrinho.php">Carrinho</a></li>
                                <li class="breadcrumb-item active">Finalizar Compra</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Mensagens do Sistema -->
                <?php mostrarMensagem(); ?>

                <form method="post" action="finalizar_compra.php">
                    <div class="row">
                        <!-- Dados de Entrega e Pagamento -->
                        <div class="col-lg-8">
                            <!-- Dados Pessoais -->
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-user me-2"></i>
                                        Dados Pessoais
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Nome Completo</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['nome']); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">E-mail</label>
                                                <input type="email" class="form-control" value="<?php echo htmlspecialchars($usuario['email']); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">CPF</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['cpf']); ?>" readonly>
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label class="form-label">Telefone</label>
                                                <input type="text" class="form-control" value="<?php echo htmlspecialchars($usuario['telefone']); ?>" readonly>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Endereço de Entrega -->
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-success text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-truck me-2"></i>
                                        Endereço de Entrega
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <?php if (!empty($enderecos)): ?>
                                        <?php foreach ($enderecos as $endereco): ?>
                                            <div class="form-check mb-3">
                                                <input class="form-check-input" type="radio" name="endereco_entrega" 
                                                       value="<?php echo $endereco['id']; ?>" 
                                                       <?php echo $endereco['principal'] ? 'checked' : ''; ?> required>
                                                <label class="form-check-label">
                                                    <strong><?php echo htmlspecialchars($endereco['titulo']); ?></strong><br>
                                                    <?php echo htmlspecialchars($endereco['logradouro']); ?>, 
                                                    <?php echo htmlspecialchars($endereco['numero']); ?><?php echo $endereco['complemento'] ? ' - ' . htmlspecialchars($endereco['complemento']) : ''; ?><br>
                                                    <?php echo htmlspecialchars($endereco['bairro']); ?> - 
                                                    <?php echo htmlspecialchars($endereco['cidade']); ?>/<?php echo htmlspecialchars($endereco['estado']); ?><br>
                                                    CEP: <?php echo htmlspecialchars($endereco['cep']); ?>
                                                    <?php if ($endereco['principal']): ?>
                                                        <span class="badge bg-primary">Principal</span>
                                                    <?php endif; ?>
                                                </label>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php else: ?>
                                        <div class="alert alert-warning">
                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                            Você não possui endereços cadastrados. 
                                            <a href="minha_conta.php?aba=enderecos" class="alert-link">Cadastre um endereço</a> para continuar.
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Método de Pagamento -->
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-info text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-credit-card me-2"></i>
                                        Método de Pagamento
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="radio" name="metodo_pagamento" value="cartao" id="cartao" checked>
                                        <label class="form-check-label" for="cartao">
                                            <i class="fab fa-cc-visa fa-2x me-2 text-primary"></i>
                                            <i class="fab fa-cc-mastercard fa-2x me-2 text-danger"></i>
                                            Cartão de Crédito
                                        </label>
                                    </div>
                                    
                                    <!-- Dados do Cartão (aparece apenas quando cartão é selecionado) -->
                                    <div class="dados-cartao" id="dados-cartao">
                                        <h6 class="mb-3">Dados do Cartão</h6>
                                        <div class="row">
                                            <div class="col-md-12 mb-3">
                                                <label for="numero_cartao" class="form-label">Número do Cartão *</label>
                                                <input type="text" class="form-control" id="numero_cartao" name="numero_cartao" 
                                                       placeholder="0000 0000 0000 0000" maxlength="19" 
                                                       oninput="formatarNumeroCartao(this)">
                                            </div>
                                            <div class="col-md-6 mb-3">
                                                <label for="nome_titular" class="form-label">Nome do Titular *</label>
                                                <input type="text" class="form-control" id="nome_titular" name="nome_titular" 
                                                       placeholder="Como está no cartão">
                                            </div>
                                            <div class="col-md-3 mb-3">
                                                <label for="data_vencimento" class="form-label">Vencimento *</label>
                                                <input type="text" class="form-control" id="data_vencimento" name="data_vencimento" 
                                                       placeholder="MM/AA" maxlength="5" 
                                                       oninput="formatarDataVencimento(this)">
                                            </div>
                                            <div class="col-md-3 mb-3">
                                                <label for="codigo_seguranca" class="form-label">CVV *</label>
                                                <input type="text" class="form-control" id="codigo_seguranca" name="codigo_seguranca" 
                                                       placeholder="123" maxlength="3">
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div class="form-check mb-3">
                                        <input class="form-check-input" type="radio" name="metodo_pagamento" value="pix" id="pix">
                                        <label class="form-check-label" for="pix">
                                            <i class="fas fa-qrcode fa-2x me-2 text-success"></i>
                                            PIX
                                        </label>
                                    </div>
                                    
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="metodo_pagamento" value="boleto" id="boleto">
                                        <label class="form-check-label" for="boleto">
                                            <i class="fas fa-barcode fa-2x me-2 text-success"></i>
                                            Boleto Bancário
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Resumo do Pedido -->
                        <div class="col-lg-4">
                            <div class="card shadow-sm resumo-pedido-card">
                                <div class="card-header bg-warning text-dark">
                                    <h5 class="mb-0">
                                        <i class="fas fa-receipt me-2"></i>
                                        Resumo do Pedido
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <!-- Itens do Resumo -->
                                    <div class="resumo-item d-flex justify-content-between mb-2">
                                        <span>Subtotal (<?php echo $total_itens; ?> itens):</span>
                                        <span>R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></span>
                                    </div>

                                    <div class="resumo-item d-flex justify-content-between mb-2">
                                        <span>Frete:</span>
                                        <span><?php echo $frete == 0 ? '<span class="text-success">Grátis</span>' : 'R$ ' . number_format($frete, 2, ',', '.'); ?></span>
                                    </div>
                                    <hr>
                                    <div class="resumo-total d-flex justify-content-between mb-3">
                                        <strong>Total:</strong>
                                        <strong class="h5 text-primary">R$ <?php echo number_format($total, 2, ',', '.'); ?></strong>
                                    </div>

                                    <!-- Lista de Produtos -->
                                    <div class="produtos-resumo">
                                        <h6 class="mb-3">Produtos no Pedido:</h6>
                                        <?php foreach ($carrinho_detalhado as $item): 
                                            $preco_final = $item['preco_promocional'] && $item['preco_promocional'] > 0 ? $item['preco_promocional'] : $item['preco'];
                                        ?>
                                        <div class="produto-item d-flex align-items-center mb-2 pb-2 border-bottom">
                                            <img src="<?php echo !empty($item['imagem']) ? $item['imagem'] : 'assets/imagens/produtos/sem-imagem.jpg'; ?>" 
                                                 alt="<?php echo htmlspecialchars($item['nome']); ?>" 
                                                 class="img-thumbnail me-2" style="width: 50px; height: 50px; object-fit: cover;">
                                            <div class="flex-grow-1">
                                                <small class="d-block fw-bold"><?php echo htmlspecialchars($item['nome']); ?></small>
                                                <small class="text-muted">
                                                    Qtd: <?php echo $item['quantidade']; ?> × 
                                                    R$ <?php echo number_format($preco_final, 2, ',', '.'); ?>
                                                </small>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    </div>

                                    <!-- Botão Finalizar Compra -->
                                    <?php if (!empty($enderecos)): ?>
                                        <button type="submit" name="finalizar_compra" class="btn btn-success btn-lg w-100 mt-3">
                                            <i class="fas fa-check-circle me-2"></i>
                                            Finalizar Pedido
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-secondary btn-lg w-100 mt-3" disabled>
                                            <i class="fas fa-exclamation-triangle me-2"></i>
                                            Cadastre um Endereço
                                        </button>
                                    <?php endif; ?>

                                    <div class="text-center mt-3">
                                        <small class="text-muted">
                                            <i class="fas fa-lock me-1"></i>
                                            Sua compra é 100% segura
                                        </small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Mostrar/ocultar dados do cartão
        document.addEventListener('DOMContentLoaded', function() {
            const metodoCartao = document.getElementById('cartao');
            const dadosCartao = document.getElementById('dados-cartao');
            const metodosPagamento = document.querySelectorAll('input[name="metodo_pagamento"]');
            
            function toggleDadosCartao() {
                if (metodoCartao.checked) {
                    dadosCartao.classList.add('cartao-ativo');
                } else {
                    dadosCartao.classList.remove('cartao-ativo');
                }
            }
            
            metodosPagamento.forEach(radio => {
                radio.addEventListener('change', toggleDadosCartao);
            });
            
            // Inicializar
            toggleDadosCartao();
        });
        
        // Formatar número do cartão
        function formatarNumeroCartao(input) {
            let value = input.value.replace(/\D/g, '');
            value = value.replace(/(\d{4})(?=\d)/g, '$1 ');
            input.value = value.substring(0, 19);
        }
        
        // Formatar data de vencimento
        function formatarDataVencimento(input) {
            let value = input.value.replace(/\D/g, '');
            if (value.length >= 2) {
                value = value.substring(0, 2) + '/' + value.substring(2, 4);
            }
            input.value = value.substring(0, 5);
        }
    </script>
</body>
</html>