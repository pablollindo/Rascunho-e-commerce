<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

$produto_id = intval($_GET['id'] ?? 0);

if ($produto_id <= 0) {
    $_SESSION['erro'] = "Produto não especificado.";
    header("Location: produtos.php");
    exit;
}

// Buscar informações do produto
try {
    $pdo = conectarBanco();
    
    // Buscar produto
    $sql_produto = "SELECT p.*, c.nome as categoria_nome, m.nome as marca_nome, m.logo as marca_logo
                   FROM produtos p 
                   LEFT JOIN categorias c ON p.categoria_id = c.id 
                   LEFT JOIN marcas m ON p.marca_id = m.id 
                   WHERE p.id = ? AND p.ativo = 1";
    $stmt = $pdo->prepare($sql_produto);
    $stmt->execute([$produto_id]);
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if (!$produto) {
        $_SESSION['erro'] = "Produto não encontrado.";
        header("Location: produtos.php");
        exit;
    }
    
    // Buscar avaliações do produto
    $sql_avaliacoes = "SELECT a.*, u.nome as usuario_nome 
                      FROM avaliacoes a 
                      JOIN usuarios u ON a.usuario_id = u.id 
                      WHERE a.produto_id = ? AND a.aprovado = 1 
                      ORDER BY a.data_avaliacao DESC 
                      LIMIT 5";
    $stmt = $pdo->prepare($sql_avaliacoes);
    $stmt->execute([$produto_id]);
    $avaliacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar produtos relacionados (mesma categoria)
    $sql_relacionados = "SELECT p.*, m.nome as marca_nome 
                        FROM produtos p 
                        LEFT JOIN marcas m ON p.marca_id = m.id 
                        WHERE p.categoria_id = ? AND p.id != ? AND p.ativo = 1 
                        ORDER BY p.em_destaque DESC, p.data_cadastro DESC 
                        LIMIT 4";
    $stmt = $pdo->prepare($sql_relacionados);
    $stmt->execute([$produto['categoria_id'], $produto_id]);
    $produtos_relacionados = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar produto: " . $e->getMessage();
    header("Location: produtos.php");
    exit;
}

// Processar adição ao carrinho
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['adicionar_carrinho'])) {
    $quantidade = intval($_POST['quantidade'] ?? 1);
    
    if ($quantidade < 1 || $quantidade > $produto['estoque']) {
        $_SESSION['erro'] = "Quantidade inválida.";
    } else {
        // Redirecionar para processa_carrinho.php
        header("Location: includes/processa_carrinho.php?action=add&product_id=$produto_id&quantidade=$quantidade");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= htmlspecialchars($produto['nome']) ?> - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <style>
        .product-image {
            border-radius: 8px;
            background: #f8f9fa;
        }
        .price-section {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 20px;
            border-radius: 8px;
        }
        .specs-list {
            list-style: none;
            padding: 0;
        }
        .specs-list li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }
        .specs-list li:last-child {
            border-bottom: none;
        }
        .rating-stars {
            color: #ffc107;
        }
        .related-product {
            transition: transform 0.3s;
        }
        .related-product:hover {
            transform: translateY(-3px);
        }
        .breadcrumb {
            background: transparent;
            padding: 0;
        }
        .guarantee-badge {
            background: #28a745;
            color: white;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.8em;
        }
    </style>
</head>
<body>
      <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Barra de Pesquisa -->
                <div class="col-md-5">
                    <form action="produtos.php" method="GET" class="d-flex">
                        <div class="input-group">
                            <input type="text" class="form-control" name="busca" placeholder="Buscar produtos...">
                            <button class="btn btn-warning" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Menu Usuário -->
                <div class="col-md-5 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                            <?php if (isAdmin() || isFuncionario()): ?>
                                <a href="admin/admin.php" class="text-white text-decoration-none me-3">
                                    <i class="fas fa-cog me-1"></i>
                                    Painel Admin
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none position-relative">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <?php 
                            // Calcular total de itens no carrinho para o badge
                            $total_itens_carrinho = 0;
                            if (isset($_SESSION['carrinho']) && is_array($_SESSION['carrinho'])) {
                                foreach ($_SESSION['carrinho'] as $item) {
                                    $total_itens_carrinho += $item['quantidade'];
                                }
                            }
                            ?>
                            <?php if ($total_itens_carrinho > 0): ?>
                                <span class="badge bg-warning text-dark position-absolute top-0 start-100 translate-middle">
                                    <?php echo $total_itens_carrinho; ?>
                                </span>
                            <?php endif; ?>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu de Navegação -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="indexx.php">
                                <i class="fas fa-home me-1"></i>Início
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-keyboard me-1"></i>Teclados
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Mecânicos</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Membrana</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Gaming</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-mouse me-1"></i>Mouses
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Gaming</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Sem Fio</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Ópticos</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=3">
                                <i class="fas fa-headphones me-1"></i>Headsets
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=4">
                                <i class="fas fa-desktop me-1"></i>Monitores
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?promocao=1">
                                <i class="fas fa-tag me-1"></i>Promoções
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <!-- Breadcrumb -->
        <nav aria-label="breadcrumb" class="mb-4">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                <li class="breadcrumb-item"><a href="produtos.php">Produtos</a></li>
                <li class="breadcrumb-item"><a href="produtos.php?categoria=<?= $produto['categoria_id'] ?>"><?= htmlspecialchars($produto['categoria_nome']) ?></a></li>
                <li class="breadcrumb-item active"><?= htmlspecialchars($produto['nome']) ?></li>
            </ol>
        </nav>

        <?php mostrarMensagem(); ?>

        <div class="row">
            <!-- Imagens do Produto -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-body text-center">
                        <img src="assets/imagens/produtos/<?= $produto['imagem'] ?? 'placeholder.jpg' ?>" 
                             alt="<?= htmlspecialchars($produto['nome']) ?>" 
                             class="img-fluid product-image"
                             style="max-height: 400px; object-fit: contain;"
                             onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxOCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                        </img>
                        
                        <!-- Badges -->
                        <div class="mt-3">
                            <?php if ($produto['em_promocao']): ?>
                                <span class="badge bg-danger me-2">PROMOÇÃO</span>
                            <?php endif; ?>
                            <?php if ($produto['em_destaque']): ?>
                                <span class="badge bg-warning me-2">DESTAQUE</span>
                            <?php endif; ?>
                            <span class="guarantee-badge">
                                <i class="fas fa-shield-alt me-1"></i>
                                <?= $produto['garantia_meses'] ?> meses de garantia
                            </span>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Informações do Produto -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-body">
                        <!-- Marca -->
                        <div class="mb-3">
                            <span class="badge bg-secondary"><?= htmlspecialchars($produto['marca_nome']) ?></span>
                        </div>
                        
                        <!-- Nome -->
                        <h1 class="h3 mb-3"><?= htmlspecialchars($produto['nome']) ?></h1>
                        
                        <!-- Avaliação -->
                        <?php if ($produto['media_avaliacoes'] > 0): ?>
                        <div class="mb-3">
                            <span class="rating-stars">
                                <?= str_repeat('★', round($produto['media_avaliacoes'])) ?><?= str_repeat('☆', 5 - round($produto['media_avaliacoes'])) ?>
                            </span>
                            <span class="text-muted ms-2">
                                (<?= $produto['total_avaliacoes'] ?> avaliações)
                            </span>
                        </div>
                        <?php endif; ?>
                        
                        <!-- Descrição -->
                        <p class="text-muted mb-4"><?= nl2br(htmlspecialchars($produto['descricao'])) ?></p>
                        
                        <!-- Preço -->
                        <div class="price-section mb-4">
                            <?php if ($produto['em_promocao'] && $produto['preco_promocional']): ?>
                                <div class="h4 mb-1">R$ <?= number_format($produto['preco_promocional'], 2, ',', '.') ?></div>
                                <div class="h6 text-light">
                                    <s>R$ <?= number_format($produto['preco'], 2, ',', '.') ?></s>
                                    <span class="badge bg-warning text-dark ms-2">
                                        <?= calcularDesconto($produto['preco'], $produto['preco_promocional']) ?>% OFF
                                    </span>
                                </div>
                            <?php else: ?>
                                <div class="h3">R$ <?= number_format($produto['preco'], 2, ',', '.') ?></div>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Estoque -->
                        <div class="mb-4">
                            <?php if ($produto['estoque'] > 0): ?>
                                <span class="text-success">
                                    <i class="fas fa-check-circle me-1"></i>
                                    Em estoque (<?= $produto['estoque'] ?> unidades)
                                </span>
                            <?php else: ?>
                                <span class="text-danger">
                                    <i class="fas fa-times-circle me-1"></i>
                                    Fora de estoque
                                </span>
                            <?php endif; ?>
                        </div>
                        
                        <!-- Formulário de Compra -->
                        <form method="POST" class="mb-4">
                            <div class="row align-items-center">
                                <div class="col-auto">
                                    <label for="quantidade" class="form-label">Quantidade:</label>
                                </div>
                                <div class="col-auto">
                                    <input type="number" 
                                           id="quantidade" 
                                           name="quantidade" 
                                           class="form-control" 
                                           value="1" 
                                           min="1" 
                                           max="<?= $produto['estoque'] ?>"
                                           style="width: 80px;"
                                           <?= $produto['estoque'] <= 0 ? 'disabled' : '' ?>>
                                </div>
                                <div class="col">
                                    <?php if ($produto['estoque'] > 0): ?>
                                        <button type="submit" name="adicionar_carrinho" class="btn btn-primary btn-lg w-100">
                                            <i class="fas fa-cart-plus me-2"></i>
                                            Adicionar ao Carrinho
                                        </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-secondary btn-lg w-100" disabled>
                                            <i class="fas fa-bell me-2"></i>
                                            Avise-me quando chegar
                                        </button>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                        
                        <!-- Wishlist -->
                        <div class="text-center">
                            <?php if (usuarioEstaLogado()): ?>
                                <button class="btn btn-outline-danger" onclick="toggleWishlist(<?= $produto_id ?>)">
                                    <i class="far fa-heart me-2"></i>
                                    Adicionar à Lista de Desejos
                                </button>
                            <?php else: ?>
                                <a href="login.php?redirect=produto.php?id=<?= $produto_id ?>" class="btn btn-outline-danger">
                                    <i class="far fa-heart me-2"></i>
                                    Favoritar Produto
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="row">
            <!-- Especificações -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-list-alt me-2"></i>
                            Especificações Técnicas
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php if (!empty($produto['especificacoes'])): ?>
                            <ul class="specs-list">
                                <?php
                                $especificacoes = explode("\n", $produto['especificacoes']);
                                foreach ($especificacoes as $espec):
                                    if (trim($espec)): ?>
                                        <li><i class="fas fa-check text-success me-2"></i><?= htmlspecialchars(trim($espec)) ?></li>
                                    <?php endif;
                                endforeach;
                                ?>
                            </ul>
                        <?php else: ?>
                            <p class="text-muted">Especificações não disponíveis.</p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- Informações Adicionais -->
            <div class="col-lg-6 mb-4">
                <div class="card">
                    <div class="card-header bg-info text-white">
                        <h5 class="mb-0">
                            <i class="fas fa-info-circle me-2"></i>
                            Informações do Produto
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6 mb-3">
                                <strong><i class="fas fa-tag me-2 text-muted"></i>Categoria:</strong><br>
                                <?= htmlspecialchars($produto['categoria_nome']) ?>
                            </div>
                            <div class="col-6 mb-3">
                                <strong><i class="fas fa-copyright me-2 text-muted"></i>Marca:</strong><br>
                                <?= htmlspecialchars($produto['marca_nome']) ?>
                            </div>
                            <div class="col-6 mb-3">
                                <strong><i class="fas fa-shield-alt me-2 text-muted"></i>Garantia:</strong><br>
                                <?= $produto['garantia_meses'] ?> meses
                            </div>
                            <div class="col-6 mb-3">
                                <strong><i class="fas fa-box me-2 text-muted"></i>Estoque:</strong><br>
                                <?= $produto['estoque'] ?> unidades
                            </div>
                            <div class="col-12 mb-3">
                                <strong><i class="fas fa-barcode me-2 text-muted"></i>Código do Produto:</strong><br>
                                #<?= str_pad($produto['id'], 6, '0', STR_PAD_LEFT) ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Avaliações -->
        <?php if (!empty($avaliacoes)): ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header bg-warning text-dark">
                        <h5 class="mb-0">
                            <i class="fas fa-star me-2"></i>
                            Avaliações dos Clientes
                        </h5>
                    </div>
                    <div class="card-body">
                        <?php foreach ($avaliacoes as $avaliacao): ?>
                        <div class="border-bottom pb-3 mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-2">
                                <strong><?= htmlspecialchars($avaliacao['usuario_nome']) ?></strong>
                                <small class="text-muted"><?= date('d/m/Y', strtotime($avaliacao['data_avaliacao'])) ?></small>
                            </div>
                            <div class="rating-stars mb-2">
                                <?= str_repeat('★', $avaliacao['nota']) ?><?= str_repeat('☆', 5 - $avaliacao['nota']) ?>
                            </div>
                            <?php if (!empty($avaliacao['titulo'])): ?>
                                <h6 class="mb-2"><?= htmlspecialchars($avaliacao['titulo']) ?></h6>
                            <?php endif; ?>
                            <p class="mb-0"><?= nl2br(htmlspecialchars($avaliacao['comentario'])) ?></p>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- Produtos Relacionados -->
        <?php if (!empty($produtos_relacionados)): ?>
        <div class="row mt-5">
            <div class="col-12">
                <h4 class="border-bottom pb-2 mb-4">
                    <i class="fas fa-random me-2 text-primary"></i>
                    Produtos Relacionados
                </h4>
                <div class="row">
                    <?php foreach ($produtos_relacionados as $relacionado): ?>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card h-100 related-product">
                            <a href="produto.php?id=<?= $relacionado['id'] ?>" class="text-decoration-none text-dark">
                                <img src="assets/imagens/produtos/<?= $relacionado['imagem'] ?? 'placeholder.jpg' ?>" 
                                     class="card-img-top" 
                                     alt="<?= htmlspecialchars($relacionado['nome']) ?>"
                                     style="height: 150px; object-fit: cover;"
                                     onerror="this.src='data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMjAwIiBoZWlnaHQ9IjIwMCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48cmVjdCB3aWR0aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiBmaWxsPSIjZjhmOWZhIi8+PHRleHQgeD0iNTAlIiB5PSI1MCUiIGZvbnQtZmFtaWx5PSJBcmlhbCwgc2Fucy1zZXJpZiIgZm9udC1zaXplPSIxNCIgZmlsbD0iIzZjNzU3ZCIgdGV4dC1hbmNob3I9Im1pZGRsZSIgZHk9Ii4zZW0iPk5lbmh1bWEgSW1hZ2VtPC90ZXh0Pjwvc3ZnPg=='">
                                </img>
                                <div class="card-body">
                                    <h6 class="card-title"><?= htmlspecialchars($relacionado['nome']) ?></h6>
                                    <p class="card-text">
                                        <small class="text-muted"><?= htmlspecialchars($relacionado['marca_nome']) ?></small><br>
                                        <strong class="text-primary">R$ <?= number_format($relacionado['preco'], 2, ',', '.') ?></strong>
                                    </p>
                                </div>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </main>

    <!-- Footer -->
    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Função para Wishlist
        function toggleWishlist(productId) {
            const btn = document.querySelector('.btn-outline-danger');
            const icon = btn.querySelector('i');
            
            if (icon.classList.contains('far')) {
                // Adicionar
                fetch(`includes/processa_wishlist.php?action=add&product_id=${productId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            icon.classList.remove('far');
                            icon.classList.add('fas');
                            btn.classList.remove('btn-outline-danger');
                            btn.classList.add('btn-danger');
                            btn.innerHTML = '<i class="fas fa-heart me-2"></i>Remover da Lista de Desejos';
                            showToast('Produto adicionado à lista de desejos!', 'success');
                        } else {
                            showToast(data.message || 'Erro ao adicionar', 'error');
                        }
                    });
            } else {
                // Remover
                fetch(`includes/processa_wishlist.php?action=remove&product_id=${productId}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            icon.classList.remove('fas');
                            icon.classList.add('far');
                            btn.classList.remove('btn-danger');
                            btn.classList.add('btn-outline-danger');
                            btn.innerHTML = '<i class="far fa-heart me-2"></i>Adicionar à Lista de Desejos';
                            showToast('Produto removido da lista de desejos!', 'success');
                        } else {
                            showToast(data.message || 'Erro ao remover', 'error');
                        }
                    });
            }
        }

        // Função para mostrar toast
        function showToast(message, type = 'info') {
            const toast = document.createElement('div');
            toast.className = `toast align-items-center text-white bg-${type === 'success' ? 'success' : 'danger'} border-0`;
            toast.setAttribute('role', 'alert');
            toast.innerHTML = `
                <div class="d-flex">
                    <div class="toast-body">${message}</div>
                    <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
                </div>
            `;
            
            let toastContainer = document.getElementById('toast-container');
            if (!toastContainer) {
                toastContainer = document.createElement('div');
                toastContainer.id = 'toast-container';
                toastContainer.className = 'toast-container position-fixed top-0 end-0 p-3';
                document.body.appendChild(toastContainer);
            }
            
            toastContainer.appendChild(toast);
            const bsToast = new bootstrap.Toast(toast);
            bsToast.show();
            
            toast.addEventListener('hidden.bs.toast', () => {
                toast.remove();
            });
        }
    </script>
</body>
</html>

<?php
// Função auxiliar para calcular desconto
function calcularDesconto($precoOriginal, $precoPromocional) {
    if (!$precoPromocional || $precoPromocional >= $precoOriginal) {
        return 0;
    }
    $desconto = (($precoOriginal - $precoPromocional) / $precoOriginal) * 100;
    return round($desconto);
}
?>