<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// Destruir a sessão
session_destroy();

// Redirecionar para a página de login usando a função
redirecionar('../login.php');
?>