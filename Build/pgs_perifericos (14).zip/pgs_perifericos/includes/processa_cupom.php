<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// Se for para remover cupom via GET
if (isset($_GET['acao']) && $_GET['acao'] === 'remover') {
    unset($_SESSION['cupom_aplicado']);
    $_SESSION['sucesso'] = 'Cupom removido com sucesso!';
    header('Location: ../carrinho.php');
    exit;
}

// Se for para aplicar cupom via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // Verificar se realmente veio do formulário de cupom
    if (!isset($_POST['codigo_cupom']) || empty(trim($_POST['codigo_cupom']))) {
        $_SESSION['erro'] = 'Digite um código de cupom.';
        header('Location: ../carrinho.php');
        exit;
    }
    
    $codigo = trim($_POST['codigo_cupom']);
    $subtotal = floatval($_POST['subtotal'] ?? 0);
    
    // Verificar se o código não está vazio
    if (empty($codigo)) {
        $_SESSION['erro'] = 'Digite um código de cupom.';
        header('Location: ../carrinho.php');
        exit;
    }
    
    try {
        // Buscar cupom no banco
        $sql = "SELECT * FROM cupons_desconto 
                WHERE codigo = ? 
                AND ativo = TRUE 
                AND (data_validade IS NULL OR data_validade >= CURDATE())";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $codigo);
        $stmt->execute();
        $result = $stmt->get_result();
        $cupom = $result->fetch_assoc();
        
        if (!$cupom) {
            throw new Exception("Cupom inválido ou expirado.");
        }
        
        // Verificar se atingiu o limite de usos
        if ($cupom['usos_maximos'] && $cupom['usos_atuais'] >= $cupom['usos_maximos']) {
            throw new Exception("Este cupom já foi utilizado o número máximo de vezes.");
        }
        
        // Calcular valor do desconto
        $valor_desconto = 0;
        $tipo = '';
        
        if ($cupom['desconto_percentual'] && $cupom['desconto_percentual'] > 0) {
            $valor_desconto = ($subtotal * $cupom['desconto_percentual']) / 100;
            $tipo = 'percentual';
        } elseif ($cupom['desconto_valor'] && $cupom['desconto_valor'] > 0) {
            $valor_desconto = $cupom['desconto_valor'];
            $tipo = 'valor';
            
            // Não permitir desconto maior que o subtotal
            if ($valor_desconto > $subtotal) {
                $valor_desconto = $subtotal;
            }
        }
        
        if ($valor_desconto <= 0) {
            throw new Exception("Cupom sem valor de desconto válido.");
        }
        
        // Salvar cupom na sessão
        $_SESSION['cupom_aplicado'] = [
            'id' => $cupom['id'],
            'codigo' => $cupom['codigo'],
            'desconto' => $valor_desconto,
            'tipo' => $tipo,
            'desconto_original' => $cupom['desconto_percentual'] ?: $cupom['desconto_valor']
        ];
        
        $_SESSION['sucesso'] = "Cupom '{$cupom['codigo']}' aplicado com sucesso!";
        
    } catch (Exception $e) {
        $_SESSION['erro'] = $e->getMessage();
        // Remover cupom da sessão se houver erro
        unset($_SESSION['cupom_aplicado']);
    }
    
    header('Location: ../carrinho.php');
    exit;
}

// Se chegou aqui sem ser uma requisição válida, redirecionar
header('Location: ../carrinho.php');
exit;
?>