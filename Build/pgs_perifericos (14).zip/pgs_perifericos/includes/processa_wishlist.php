<?php
session_start();
require_once 'config.php';
require_once 'funcoes.php';

// Verificar se é uma requisição AJAX
$is_ajax = !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';

$response = ['success' => false, 'message' => ''];

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $response['message'] = "Você precisa estar logado para gerenciar sua lista de desejos.";
    
    if ($is_ajax) {
        header('Content-Type: application/json');
        echo json_encode($response);
    } else {
        $_SESSION['erro'] = $response['message'];
        header('Location: ../login.php');
        exit;
    }
    exit;
}

$usuario_id = $_SESSION['usuario_id'];
$action = $_POST['action'] ?? $_GET['action'] ?? '';
$product_id = intval($_POST['product_id'] ?? $_GET['product_id'] ?? 0);

try {
    switch ($action) {
        case 'add':
            // Verificar se o produto existe e está ativo
            $sql = "SELECT p.id, p.nome, p.estoque, p.preco, p.preco_promocional, p.imagem, 
                           p.garantia_meses, m.nome as marca_nome, c.nome as categoria_nome 
                    FROM produtos p 
                    LEFT JOIN marcas m ON p.marca_id = m.id 
                    LEFT JOIN categorias c ON p.categoria_id = c.id 
                    WHERE p.id = ? AND p.ativo = 1";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $product_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $produto = $result->fetch_assoc();
            
            if (!$produto) {
                throw new Exception("Produto não encontrado ou indisponível.");
            }
            
            // Verificar se já está na wishlist
            $sql_check = "SELECT id FROM wishlist WHERE usuario_id = ? AND produto_id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("ii", $usuario_id, $product_id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            
            if ($result_check->num_rows > 0) {
                throw new Exception("Este produto já está na sua lista de desejos!");
            }
            
            // Adicionar à wishlist
            $sql_insert = "INSERT INTO wishlist (usuario_id, produto_id, data_adicao) VALUES (?, ?, NOW())";
            $stmt_insert = $conn->prepare($sql_insert);
            $stmt_insert->bind_param("ii", $usuario_id, $product_id);
            
            if ($stmt_insert->execute()) {
                $response['success'] = true;
                $response['message'] = "Produto adicionado à lista de desejos!";
                $response['wishlist_count'] = getWishlistCount($usuario_id, $conn);
            } else {
                throw new Exception("Erro ao adicionar produto à lista de desejos.");
            }
            break;
            
        case 'remove':
            // Verificar se o item existe na wishlist do usuário
            $sql_check = "SELECT w.id, p.nome 
                         FROM wishlist w 
                         JOIN produtos p ON w.produto_id = p.id 
                         WHERE w.usuario_id = ? AND w.produto_id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("ii", $usuario_id, $product_id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            $item = $result_check->fetch_assoc();
            
            if (!$item) {
                throw new Exception("Produto não encontrado na sua lista de desejos.");
            }
            
            // Remover da wishlist
            $sql_delete = "DELETE FROM wishlist WHERE usuario_id = ? AND produto_id = ?";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bind_param("ii", $usuario_id, $product_id);
            
            if ($stmt_delete->execute()) {
                $response['success'] = true;
                $response['message'] = "{$item['nome']} removido da lista de desejos!";
                $response['wishlist_count'] = getWishlistCount($usuario_id, $conn);
            } else {
                throw new Exception("Erro ao remover produto da lista de desejos.");
            }
            break;
            
        case 'move_to_cart':
            // Verificar se o item existe na wishlist com informações completas
            $sql_check = "SELECT w.id, p.*, m.nome as marca_nome, c.nome as categoria_nome 
                         FROM wishlist w 
                         JOIN produtos p ON w.produto_id = p.id 
                         LEFT JOIN marcas m ON p.marca_id = m.id 
                         LEFT JOIN categorias c ON p.categoria_id = c.id 
                         WHERE w.usuario_id = ? AND w.produto_id = ?";
            $stmt_check = $conn->prepare($sql_check);
            $stmt_check->bind_param("ii", $usuario_id, $product_id);
            $stmt_check->execute();
            $result_check = $stmt_check->get_result();
            $item = $result_check->fetch_assoc();
            
            if (!$item) {
                throw new Exception("Produto não encontrado na sua lista de desejos.");
            }
            
            // Verificar estoque
            if ($item['estoque'] < 1) {
                throw new Exception("Produto fora de estoque. Não é possível adicionar ao carrinho.");
            }
            
            // Inicializar carrinho se não existir
            if (!isset($_SESSION['carrinho'])) {
                $_SESSION['carrinho'] = [];
            }
            
            // Adicionar ao carrinho (MESMA LÓGICA DO processa_carrinho.php)
            if (isset($_SESSION['carrinho'][$product_id])) {
                $_SESSION['carrinho'][$product_id]['quantidade'] += 1;
            } else {
                $_SESSION['carrinho'][$product_id] = [
                    'id' => $item['id'],
                    'nome' => $item['nome'],
                    'preco' => floatval($item['preco']),
                    'preco_promocional' => $item['preco_promocional'] ? floatval($item['preco_promocional']) : null,
                    'quantidade' => 1,
                    'imagem' => $item['imagem'],
                    'estoque' => intval($item['estoque']),
                    'marca_nome' => $item['marca_nome'],
                    'categoria_nome' => $item['categoria_nome'],
                    'garantia_meses' => $item['garantia_meses']
                ];
            }
            
            // Remover da wishlist
            $sql_delete = "DELETE FROM wishlist WHERE usuario_id = ? AND produto_id = ?";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bind_param("ii", $usuario_id, $product_id);
            $stmt_delete->execute();
            
            $response['success'] = true;
            $response['message'] = "{$item['nome']} movido para o carrinho!";
            $response['wishlist_count'] = getWishlistCount($usuario_id, $conn);
            
            // Calcular total do carrinho
            $total_itens = 0;
            foreach ($_SESSION['carrinho'] as $cart_item) {
                $total_itens += $cart_item['quantidade'];
            }
            $response['cart_count'] = $total_itens;
            break;
            
        case 'add_all_to_cart':
            // Buscar todos os itens da wishlist com estoque
            $sql_wishlist = "SELECT p.*, m.nome as marca_nome, c.nome as categoria_nome 
                            FROM wishlist w 
                            JOIN produtos p ON w.produto_id = p.id 
                            LEFT JOIN marcas m ON p.marca_id = m.id 
                            LEFT JOIN categorias c ON p.categoria_id = c.id 
                            WHERE w.usuario_id = ? AND p.estoque > 0 AND p.ativo = 1";
            $stmt_wishlist = $conn->prepare($sql_wishlist);
            $stmt_wishlist->bind_param("i", $usuario_id);
            $stmt_wishlist->execute();
            $result_wishlist = $stmt_wishlist->get_result();
            $wishlist_items = $result_wishlist->fetch_all(MYSQLI_ASSOC);
            
            if (empty($wishlist_items)) {
                throw new Exception("Nenhum produto disponível em estoque na sua lista de desejos.");
            }
            
            // Inicializar carrinho se não existir
            if (!isset($_SESSION['carrinho'])) {
                $_SESSION['carrinho'] = [];
            }
            
            $added_count = 0;
            foreach ($wishlist_items as $item) {
                $product_id = $item['id'];
                
                if (isset($_SESSION['carrinho'][$product_id])) {
                    $_SESSION['carrinho'][$product_id]['quantidade'] += 1;
                } else {
                    $_SESSION['carrinho'][$product_id] = [
                        'id' => $item['id'],
                        'nome' => $item['nome'],
                        'preco' => floatval($item['preco']),
                        'preco_promocional' => $item['preco_promocional'] ? floatval($item['preco_promocional']) : null,
                        'quantidade' => 1,
                        'imagem' => $item['imagem'],
                        'estoque' => intval($item['estoque']),
                        'marca_nome' => $item['marca_nome'],
                        'categoria_nome' => $item['categoria_nome'],
                        'garantia_meses' => $item['garantia_meses']
                    ];
                }
                $added_count++;
            }
            
            // Limpar wishlist após adicionar todos ao carrinho
            $sql_clear = "DELETE FROM wishlist WHERE usuario_id = ?";
            $stmt_clear = $conn->prepare($sql_clear);
            $stmt_clear->bind_param("i", $usuario_id);
            $stmt_clear->execute();
            
            $response['success'] = true;
            $response['message'] = "{$added_count} produtos adicionados ao carrinho!";
            $response['wishlist_count'] = 0;
            
            // Calcular total do carrinho
            $total_itens = 0;
            foreach ($_SESSION['carrinho'] as $cart_item) {
                $total_itens += $cart_item['quantidade'];
            }
            $response['cart_count'] = $total_itens;
            break;
            
        case 'clear':
            // Limpar toda a wishlist do usuário
            $sql_clear = "DELETE FROM wishlist WHERE usuario_id = ?";
            $stmt_clear = $conn->prepare($sql_clear);
            $stmt_clear->bind_param("i", $usuario_id);
            
            if ($stmt_clear->execute()) {
                $response['success'] = true;
                $response['message'] = "Lista de desejos limpa com sucesso!";
                $response['wishlist_count'] = 0;
            } else {
                throw new Exception("Erro ao limpar lista de desejos.");
            }
            break;
            
        default:
            throw new Exception("Ação inválida.");
    }
    
} catch (Exception $e) {
    $response['message'] = $e->getMessage();
}

// Função auxiliar para contar itens na wishlist
function getWishlistCount($usuario_id, $conn) {
    $sql = "SELECT COUNT(*) as total FROM wishlist WHERE usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    return $row['total'];
}

// CORREÇÃO: Redirecionamento mais inteligente
if ($is_ajax) {
    header('Content-Type: application/json');
    echo json_encode($response);
    exit;
} else {
    if ($response['success']) {
        $_SESSION['sucesso'] = $response['message'];
    } else {
        $_SESSION['erro'] = $response['message'];
    }
    
    // Determinar para onde redirecionar
    $redirect = $_POST['redirect'] ?? $_GET['redirect'] ?? 'lista_desejos.php';
    
    // Se não especificado e veio de uma referência válida, usa ela
    if (($redirect === 'lista_desejos.php' || empty($redirect)) && isset($_SERVER['HTTP_REFERER'])) {
        $referer = $_SERVER['HTTP_REFERER'];
        // Só usa a referência se for do mesmo domínio
        if (strpos($referer, $_SERVER['HTTP_HOST']) !== false) {
            $redirect = $referer;
        }
    }
    
    // Garantir que o redirecionamento seja absoluto se necessário
    if (strpos($redirect, 'http') === false) {
        // Se começar com ../, remove
        if (strpos($redirect, '../') === 0) {
            $redirect = substr($redirect, 3);
        }
        // Se não começar com /, adiciona o caminho base
        if (strpos($redirect, '/') !== 0) {
            $base_path = dirname($_SERVER['PHP_SELF']);
            if ($base_path !== '/') {
                $redirect = $base_path . '/' . $redirect;
            } else {
                $redirect = '/' . $redirect;
            }
        }
    }
    
    header("Location: $redirect");
    exit;
}