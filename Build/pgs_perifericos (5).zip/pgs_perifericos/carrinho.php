<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Calcular totais do carrinho
$subtotal = 0;
$total_itens = 0;
$carrinho_vazio = true;

if (isset($_SESSION['carrinho']) && !empty($_SESSION['carrinho'])) {
    $carrinho_vazio = false;
    foreach ($_SESSION['carrinho'] as $item) {
        $preco = $item['preco_promocional'] ?: $item['preco'];
        $subtotal += $preco * $item['quantidade'];
        $total_itens += $item['quantidade'];
    }
}

$frete = $subtotal >= 299.90 ? 0 : 29.90;
$total = $subtotal + $frete;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/carrinho.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-2">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Barra de Pesquisa -->
                <div class="col-md-5">
                    <div class="input-group">
                        <input type="text" class="form-control" placeholder="Buscar produtos...">
                        <button class="btn btn-warning" type="button">
                            <i class="fas fa-search"></i>
                        </button>
                    </div>
                </div>

                <!-- Menu Usuário -->
                <div class="col-md-5 text-end">
                    <div class="d-flex justify-content-end align-items-center">
                        <?php if (usuarioEstaLogado()): ?>
                            <a href="minha_conta.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Minha Conta
                            </a>
                            <?php if (isAdmin() || isFuncionario()): ?>
                                <a href="admin/admin.php" class="text-white text-decoration-none me-3">
                                    <i class="fas fa-cog me-1"></i>
                                    Painel Admin
                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="login.php" class="text-white text-decoration-none me-3">
                                <i class="fas fa-user me-1"></i>
                                Entrar
                            </a>
                        <?php endif; ?>
                        <a href="carrinho.php" class="text-white text-decoration-none">
                            <i class="fas fa-shopping-cart me-1"></i>
                            Carrinho
                            <span class="badge bg-warning text-dark" id="cart-count"><?php echo $total_itens; ?></span>
                        </a>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu de Navegação -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="indexx.php">
                                <i class="fas fa-home me-1"></i>Início
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-keyboard me-1"></i>Teclados
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Mecânicos</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Membrana</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=1">Gaming</a></li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <i class="fas fa-mouse me-1"></i>Mouses
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Gaming</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Sem Fio</a></li>
                                <li><a class="dropdown-item" href="produtos.php?categoria=2">Ópticos</a></li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=3">
                                <i class="fas fa-headphones me-1"></i>Headsets
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?categoria=4">
                                <i class="fas fa-desktop me-1"></i>Monitores
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="promocoes.php">
                                <i class="fas fa-tag me-1"></i>Promoções
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho do Carrinho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-shopping-cart text-primary me-2"></i>
                        Meu Carrinho
                    </h1>
                    <div class="breadcrumb-nav">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                                <li class="breadcrumb-item active">Carrinho</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Mensagens do Sistema -->
                <?php mostrarMensagem(); ?>

                <?php if ($carrinho_vazio): ?>
                    <!-- Carrinho Vazio -->
                    <div class="text-center py-5">
                        <div class="empty-cart-icon mb-4">
                            <i class="fas fa-shopping-cart fa-5x text-muted"></i>
                        </div>
                        <h3 class="text-muted mb-3">Seu carrinho está vazio</h3>
                        <p class="text-muted mb-4">Adicione alguns produtos incríveis ao seu carrinho!</p>
                        <a href="produtos.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Continuar Comprando
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <!-- Lista de Produtos -->
                        <div class="col-lg-8">
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0">
                                        <i class="fas fa-boxes me-2"></i>
                                        Produtos no Carrinho (<?php echo $total_itens; ?>)
                                    </h5>
                                </div>
                                <div class="card-body p-0" id="cart-items-container">
                                    <?php foreach ($_SESSION['carrinho'] as $product_id => $item): 
                                        $preco_final = $item['preco_promocional'] ?: $item['preco'];
                                        $subtotal_item = $preco_final * $item['quantidade'];
                                        $imagem = !empty($item['imagem']) ? $item['imagem'] : 'assets/imagens/produtos/sem-imagem.jpg';
                                    ?>
                                    <div class="cart-item border-bottom" id="cart-item-<?php echo $product_id; ?>">
                                        <div class="row align-items-center p-3">
                                            <div class="col-2">
                                                <img src="<?php echo $imagem; ?>" 
                                                     alt="<?php echo htmlspecialchars($item['nome']); ?>" 
                                                     class="img-fluid rounded cart-item-image">
                                            </div>
                                            <div class="col-4">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($item['nome']); ?></h6>
                                                <p class="text-muted small mb-1">
                                                    <?php echo htmlspecialchars($item['marca']); ?> • 
                                                    <?php echo htmlspecialchars($item['categoria']); ?>
                                                </p>
                                                <div class="stock-status">
                                                    <?php if ($item['quantidade'] <= $item['estoque']): ?>
                                                        <span class="badge bg-success">
                                                            <i class="fas fa-check me-1"></i>Em estoque
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">
                                                            <i class="fas fa-exclamation-triangle me-1"></i>Estoque insuficiente
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="quantity-controls">
                                                    <button class="btn btn-outline-secondary btn-sm quantity-btn" 
                                                            data-action="decrease" 
                                                            data-product-id="<?php echo $product_id; ?>">
                                                        <i class="fas fa-minus"></i>
                                                    </button>
                                                    <input type="number" 
                                                           class="form-control form-control-sm quantity-input" 
                                                           value="<?php echo $item['quantidade']; ?>" 
                                                           min="1" 
                                                           max="<?php echo $item['estoque']; ?>"
                                                           data-product-id="<?php echo $product_id; ?>"
                                                           data-price="<?php echo $preco_final; ?>">
                                                    <button class="btn btn-outline-secondary btn-sm quantity-btn" 
                                                            data-action="increase" 
                                                            data-product-id="<?php echo $product_id; ?>">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="price-info">
                                                    <div class="h6 mb-0 text-primary">
                                                        R$ <?php echo number_format($preco_final, 2, ',', '.'); ?>
                                                    </div>
                                                    <?php if ($item['preco_promocional']): ?>
                                                        <small class="text-muted text-decoration-line-through">
                                                            R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?>
                                                        </small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-2 text-center">
                                                <div class="item-actions">
                                                    <button class="btn btn-outline-danger btn-sm remove-item" 
                                                            data-product-id="<?php echo $product_id; ?>">
                                                        <i class="fas fa-trash"></i>
                                                    </button>
                                                    <div class="mt-1">
                                                        <small class="text-muted">
                                                            Subtotal: <strong class="item-subtotal">R$ <?php echo number_format($subtotal_item, 2, ',', '.'); ?></strong>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Cupom de Desconto -->
                            <div class="card shadow-sm mb-4">
                                <div class="card-body">
                                    <h6 class="mb-3">
                                        <i class="fas fa-tag text-success me-2"></i>
                                        Cupom de Desconto
                                    </h6>
                                    <div class="row align-items-center">
                                        <div class="col-md-8">
                                            <input type="text" class="form-control" id="cupom" placeholder="Digite seu cupom">
                                        </div>
                                        <div class="col-md-4">
                                            <button class="btn btn-success w-100" id="aplicar-cupom">
                                                <i class="fas fa-check me-1"></i>Aplicar
                                            </button>
                                        </div>
                                    </div>
                                    <div class="mt-2">
                                        <small class="text-muted">
                                            <i class="fas fa-info-circle me-1"></i>
                                            Cupons disponíveis: <strong>PRIMEIRACOMPRA</strong> (10% off) • <strong>FRETEGRATIS</strong> (Frete grátis)
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <!-- Ações do Carrinho -->
                            <div class="d-flex justify-content-between">
                                <a href="produtos.php" class="btn btn-outline-primary">
                                    <i class="fas fa-arrow-left me-2"></i>
                                    Continuar Comprando
                                </a>
                                <button class="btn btn-outline-danger" id="limpar-carrinho">
                                    <i class="fas fa-trash me-2"></i>
                                    Limpar Carrinho
                                </button>
                            </div>
                        </div>

                        <!-- Resumo do Pedido -->
                        <div class="col-lg-4">
                            <div class="card shadow-sm sticky-top" style="top: 100px;">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-receipt me-2"></i>
                                        Resumo do Pedido
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <!-- Itens do Resumo -->
                                    <div class="resumo-item d-flex justify-content-between mb-2">
                                        <span>Subtotal (<?php echo $total_itens; ?> itens):</span>
                                        <span id="subtotal">R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></span>
                                    </div>
                                    <div class="resumo-item d-flex justify-content-between mb-2">
                                        <span>Frete:</span>
                                        <span id="frete"><?php echo $frete == 0 ? 'Grátis' : 'R$ ' . number_format($frete, 2, ',', '.'); ?></span>
                                    </div>
                                    <div class="resumo-item d-flex justify-content-between mb-2 text-success" id="cupom-desconto" style="display: none;">
                                        <span>Desconto:</span>
                                        <span>-R$ 0,00</span>
                                    </div>
                                    <hr>
                                    <div class="resumo-total d-flex justify-content-between mb-3">
                                        <strong>Total:</strong>
                                        <strong class="h5 text-primary" id="total">R$ <?php echo number_format($total, 2, ',', '.'); ?></strong>
                                    </div>

                                    <!-- Frete Grátis Progress -->
                                    <?php if ($subtotal < 299.90): ?>
                                    <div class="alert alert-info mb-3">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-shipping-fast me-2"></i>
                                            <div class="flex-grow-1">
                                                <small class="d-block">Faltam <strong id="falta-frete">R$ <?php echo number_format(299.90 - $subtotal, 2, ',', '.'); ?></strong> para frete grátis!</small>
                                                <div class="progress mt-1" style="height: 6px;">
                                                    <div class="progress-bar bg-info" style="width: <?php echo ($subtotal / 299.90) * 100; ?>%"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="alert alert-success mb-3">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <small>Parabéns! Você ganhou frete grátis!</small>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Botão Finalizar Compra -->
                                    <?php if (usuarioEstaLogado()): ?>
                                        <a href="finalizar_compra.php" class="btn btn-warning btn-lg w-100 mb-3">
                                            <i class="fas fa-credit-card me-2"></i>
                                            Finalizar Compra
                                        </a>
                                    <?php else: ?>
                                        <a href="login.php?redirect=carrinho" class="btn btn-warning btn-lg w-100 mb-3">
                                            <i class="fas fa-sign-in-alt me-2"></i>
                                            Fazer Login para Comprar
                                        </a>
                                    <?php endif; ?>

                                    <!-- Métodos de Pagamento -->
                                    <div class="text-center mb-3">
                                        <small class="text-muted">Métodos de pagamento aceitos:</small>
                                        <div class="mt-2">
                                            <img src="pgs_perifericos/imagens/icons8-cartão-50.png" alt="Cartões" height="25" class="me-2">
                                            <img src="assets/imagens/icones/pix.png" alt="PIX" height="25" class="me-2">
                                            <img src="assets/imagens/icones/boleto.png" alt="Boleto" height="25">
                                        </div>
                                    </div>

                                    <!-- Segurança -->
                                    <div class="text-center">
                                        <small class="text-muted">
                                            <i class="fas fa-lock me-1"></i>
                                            Compra 100% segura
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <!-- Benefícios -->
                            <div class="card shadow-sm mt-4">
                                <div class="card-body">
                                    <h6 class="mb-3">
                                        <i class="fas fa-shield-alt text-success me-2"></i>
                                        Sua Compra é Protegida
                                    </h6>
                                    <div class="benefit-item mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Garantia de 12 meses</small>
                                    </div>
                                    <div class="benefit-item mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Troca em 30 dias</small>
                                    </div>
                                    <div class="benefit-item mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Compra segura SSL</small>
                                    </div>
                                    <div class="benefit-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Suporte 24/7</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-5 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4 mb-4">
                    <h5 class="text-warning">
                        <i class="fas fa-gamepad me-2"></i>
                        PGS Periféricos
                    </h5>
                    <p class="text-light">Sua loja de confiança para periféricos gamers de alta qualidade.</p>
                    <div class="social-links">
                        <a href="#" class="text-white me-3"><i class="fab fa-facebook fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-instagram fa-lg"></i></a>
                        <a href="#" class="text-white me-3"><i class="fab fa-twitter fa-lg"></i></a>
                        <a href="#" class="text-white"><i class="fab fa-youtube fa-lg"></i></a>
                    </div>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="text-warning">INSTITUCIONAL</h6>
                    <ul class="list-unstyled">
                        <li><a href="#" class="text-light text-decoration-none">Sobre Nós</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Nossas Lojas</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Trabalhe Conosco</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Política de Privacidade</a></li>
                    </ul>
                </div>
                <div class="col-md-2 mb-4">
                    <h6 class="text-warning">ATENDIMENTO</h6>
                    <ul class="list-unstyled">
                        <li><a href="faq.php" class="text-light text-decoration-none">FAQ</a></li>
                        <li><a href="suporte.php" class="text-light text-decoration-none">Fale Conosco</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Troca e Devolução</a></li>
                        <li><a href="#" class="text-light text-decoration-none">Formas de Pagamento</a></li>
                    </ul>
                </div>
                <div class="col-md-4 mb-4">
                    <h6 class="text-warning">NEWSLETTER</h6>
                    <p class="text-light">Cadastre-se e receba ofertas exclusivas!</p>
                    <div class="input-group">
                        <input type="email" class="form-control" placeholder="Seu e-mail">
                        <button class="btn btn-warning">Cadastrar</button>
                    </div>
                </div>
            </div>
            <hr class="bg-secondary">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0 text-light">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
                </div>
                <div class="col-md-6 text-end">
                    <img src="imagens/icones/icons8-cartão-50.png" alt="Cartões" height="30" class="me-2">
                    <img src="imagens/icones/icons8-foto-50.png" alt="PIX" height="30" class="me-2">
                    <img src="imagens/icones/icons8-boleto-50.png" alt="Boleto" height="30">
                </div>
            </div>
        </div>
    </footer>

    <!-- Modal Confirmação Remoção -->
    <div class="modal fade" id="confirmRemoveModal" tabindex="-1" aria-labelledby="confirmRemoveModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-sm">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="confirmRemoveModalLabel">
                        <i class="fas fa-exclamation-triangle me-2"></i>
                        Confirmar
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-center">
                    <p class="mb-3">Deseja remover este item do carrinho?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-danger" id="confirm-remove">Remover</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="carrinho.js"></script>
</body>
</html>