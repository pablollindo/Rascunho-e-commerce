<?php
session_start();
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

echo "<!DOCTYPE html>
<html>
<head>
    <title>Resultado Teste</title>
    <link href='https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css' rel='stylesheet'>
</head>
<body>
    <div class='container mt-5'>
        <div class='row justify-content-center'>
            <div class='col-md-8'>
                <h2>🎯 RESULTADO DO TESTE</h2>";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    echo "<div class='alert alert-success'>
            <h4>✅ FORMULÁRIO ENVIOU COM SUCESSO!</h4>
            <p>Os dados chegaram no servidor.</p>
        </div>";
    
    echo "<h4>Dados Recebidos:</h4>
          <pre class='bg-light p-3'>";
    print_r($_POST);
    echo "</pre>";
    
    // Tentar inserir no banco
    try {
        $nome = $_POST['nome'] ?? '';
        $email = $_POST['email'] ?? '';
        $senha = $_POST['senha'] ?? '';
        $tipo = $_POST['tipo_cadastro'] ?? 'cliente';
        
        $senha_hash = password_hash($senha, PASSWORD_DEFAULT);
        
        $sql = "INSERT INTO usuarios (nome, email, senha, tipo) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        
        if ($stmt->bind_param("ssss", $nome, $email, $senha_hash, $tipo)) {
            if ($stmt->execute()) {
                echo "<div class='alert alert-success'>
                        <h4>🎉 BANCO DE DADOS FUNCIONANDO!</h4>
                        <p>Usuário inserido com ID: " . $stmt->insert_id . "</p>
                    </div>";
            } else {
                echo "<div class='alert alert-warning'>
                        <h4>⚠️ ERRO NO BANCO</h4>
                        <p>Erro: " . $stmt->error . "</p>
                    </div>";
            }
        }
        
        $stmt->close();
        
    } catch (Exception $e) {
        echo "<div class='alert alert-danger'>
                <h4>❌ ERRO NO BANCO</h4>
                <p>" . $e->getMessage() . "</p>
            </div>";
    }
    
} else {
    echo "<div class='alert alert-warning'>
            <h4>⚠️ NENHUM DADO RECEBIDO</h4>
            <p>O formulário não enviou dados via POST.</p>
        </div>";
}

echo "      <div class='text-center mt-4'>
                <a href='cadastro_simples.php' class='btn btn-primary'>Fazer outro teste</a>
                <a href='cadastro.php' class='btn btn-secondary'>Voltar ao cadastro normal</a>
            </div>
        </div>
    </div>
</body>
</html>";