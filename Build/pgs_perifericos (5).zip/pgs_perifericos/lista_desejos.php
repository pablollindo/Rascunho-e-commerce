<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para acessar sua lista de desejos.";
    redirecionar('login.php');
}

// Buscar produtos da lista de desejos do usuário
$usuario_id = $_SESSION['usuario_id'];
$wishlist_query = "
    SELECT p.*, w.data_adicao 
    FROM wishlist w 
    JOIN produtos p ON w.produto_id = p.id 
    WHERE w.usuario_id = ? 
    ORDER BY w.data_adicao DESC
";

$stmt = $conn->prepare($wishlist_query);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
$wishlist_items = $result->fetch_all(MYSQLI_ASSOC);
$stmt->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Minha Lista de Desejos - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/wishlist.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <div class="col-md-2">
                    <a href="index.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>
                <div class="col-md-8 text-center">
                    <h5 class="mb-0">
                        <i class="fas fa-heart text-danger me-2"></i>
                        Minha Lista de Desejos
                    </h5>
                </div>
                <div class="col-md-2 text-end">
                    <a href="index.php" class="btn btn-outline-warning btn-sm">
                        <i class="fas fa-home me-1"></i>Voltar
                    </a>
                </div>
            </div>
        </div>
    </header>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-heart text-danger me-2"></i>
                        Minha Lista de Desejos
                    </h1>
                    <span class="badge bg-primary fs-6">
                        <?php echo count($wishlist_items); ?> itens
                    </span>
                </div>

                <?php mostrarMensagem(); ?>

                <?php if (empty($wishlist_items)): ?>
                    <!-- Lista de Desejos Vazia -->
                    <div class="text-center py-5">
                        <div class="empty-wishlist">
                            <i class="fas fa-heart-broken fa-5x text-muted mb-4"></i>
                            <h3 class="text-muted">Sua lista de desejos está vazia</h3>
                            <p class="text-muted mb-4">Adicone produtos que você ama à sua lista de desejos!</p>
                            <a href="produtos.php" class="btn btn-primary btn-lg">
                                <i class="fas fa-shopping-bag me-2"></i>
                                Explorar Produtos
                            </a>
                        </div>
                    </div>
                <?php else: ?>
                    <!-- Lista de Desejos com Itens -->
                    <div class="row">
                        <?php foreach ($wishlist_items as $item): ?>
                            <div class="col-md-6 col-lg-4 mb-4">
                                <div class="card h-100 wishlist-card">
                                    <div class="card-header position-relative">
                                        <?php if ($item['em_promocao'] && $item['preco_promocional']): ?>
                                            <span class="badge bg-danger">-<?php echo calcularDesconto($item['preco'], $item['preco_promocional']); ?></span>
                                        <?php endif; ?>
                                        <?php if ($item['em_destaque']): ?>
                                            <span class="badge bg-warning">Destaque</span>
                                        <?php endif; ?>
                                        <button class="btn btn-danger btn-sm position-absolute top-0 end-0 m-2 remove-wishlist" 
                                                data-product="<?php echo $item['id']; ?>">
                                            <i class="fas fa-times"></i>
                                        </button>
                                    </div>
                                    <img src="assets/imagens/produtos/<?php echo $item['imagem'] ?: 'placeholder.jpg'; ?>" 
                                         class="card-img-top" 
                                         alt="<?php echo $item['nome']; ?>"
                                         style="height: 200px; object-fit: cover;">
                                    <div class="card-body d-flex flex-column">
                                        <h5 class="card-title"><?php echo $item['nome']; ?></h5>
                                        <p class="card-text text-muted small"><?php echo limitarTexto($item['descricao'], 80); ?></p>
                                        
                                        <div class="mt-auto">
                                            <!-- Preço -->
                                            <div class="price-section mb-3">
                                                <?php if ($item['em_promocao'] && $item['preco_promocional']): ?>
                                                    <div class="d-flex align-items-center">
                                                        <span class="h4 text-primary me-2">R$ <?php echo number_format($item['preco_promocional'], 2, ',', '.'); ?></span>
                                                        <small class="text-muted text-decoration-line-through">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></small>
                                                    </div>
                                                <?php else: ?>
                                                    <span class="h4 text-primary">R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></span>
                                                <?php endif; ?>
                                            </div>

                                            <!-- Estoque -->
                                            <div class="stock-info mb-3">
                                                <?php if ($item['estoque'] > 0): ?>
                                                    <span class="badge bg-success">
                                                        <i class="fas fa-check me-1"></i>
                                                        Em estoque
                                                    </span>
                                                <?php else: ?>
                                                    <span class="badge bg-secondary">
                                                        <i class="fas fa-clock me-1"></i>
                                                        Fora de estoque
                                                    </span>
                                                <?php endif; ?>
                                            </div>

                                            <!-- Ações -->
                                            <div class="d-grid gap-2">
                                                <?php if ($item['estoque'] > 0): ?>
                                                    <button class="btn btn-primary add-to-cart" data-product="<?php echo $item['id']; ?>">
                                                        <i class="fas fa-cart-plus me-2"></i>
                                                        Adicionar ao Carrinho
                                                    </button>
                                                <?php else: ?>
                                                    <button class="btn btn-outline-secondary" disabled>
                                                        <i class="fas fa-bell me-2"></i>
                                                        Avise-me quando chegar
                                                    </button>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="card-footer">
                                        <small class="text-muted">
                                            <i class="far fa-clock me-1"></i>
                                            Adicionado em <?php echo formatarData($item['data_adicao']); ?>
                                        </small>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Ações em Lote -->
                    <div class="card mt-4">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center">
                                <div>
                                    <h6 class="mb-1">Ações em Lote</h6>
                                    <p class="text-muted small mb-0">Gerencie múltiplos itens de uma vez</p>
                                </div>
                                <div class="d-flex gap-2">
                                    <button class="btn btn-outline-primary" id="add-all-to-cart">
                                        <i class="fas fa-cart-plus me-2"></i>
                                        Adicionar Todos ao Carrinho
                                    </button>
                                    <button class="btn btn-outline-danger" id="clear-wishlist">
                                        <i class="fas fa-trash me-2"></i>
                                        Limpar Lista
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <footer class="bg-dark text-white py-4 mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <p class="mb-0">&copy; 2024 PGS Periféricos. Todos os direitos reservados.</p>
                </div>
                <div class="col-md-6 text-end">
                    <a href="suporte.php" class="text-white text-decoration-none me-3">
                        <i class="fas fa-headset me-1"></i>Suporte
                    </a>
                    <a href="faq.php" class="text-white text-decoration-none">
                        <i class="fas fa-question-circle me-1"></i>FAQ
                    </a>
                </div>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Remover da lista de desejos
            const removeButtons = document.querySelectorAll('.remove-wishlist');
            removeButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product');
                    if (confirm('Deseja remover este produto da sua lista de desejos?')) {
                        // Aqui você faria uma requisição AJAX para remover
                        window.location.href = 'includes/processa_wishlist.php?action=remove&product_id=' + productId;
                    }
                });
            });

            // Adicionar ao carrinho
            const addToCartButtons = document.querySelectorAll('.add-to-cart');
            addToCartButtons.forEach(btn => {
                btn.addEventListener('click', function() {
                    const productId = this.getAttribute('data-product');
                    // Aqui você implementaria a adição ao carrinho
                    alert('Produto adicionado ao carrinho!');
                });
            });

            // Ações em lote
            document.getElementById('add-all-to-cart')?.addEventListener('click', function() {
                if (confirm('Deseja adicionar todos os produtos disponíveis ao carrinho?')) {
                    // Implementar adição em lote
                    alert('Produtos adicionados ao carrinho!');
                }
            });

            document.getElementById('clear-wishlist')?.addEventListener('click', function() {
                if (confirm('Deseja limpar toda a sua lista de desejos?')) {
                    window.location.href = 'includes/processa_wishlist.php?action=clear';
                }
            });
        });
    </script>
</body>
</html>