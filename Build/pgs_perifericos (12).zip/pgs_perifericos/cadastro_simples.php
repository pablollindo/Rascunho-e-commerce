<?php
// Iniciar sessão se não estiver iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Incluir funções (sem redeclarar)
require_once 'funcoes.php';

// Verificar se usuário está logado e obter dados
$usuarioLogado = false;
$nomeUsuario = '';
$tipoUsuario = '';
$carrinhoCount = 0;

if (isset($_SESSION['usuario_id'])) {
    $usuarioLogado = true;
    $nomeUsuario = $_SESSION['usuario_nome'] ?? '';
    $tipoUsuario = $_SESSION['usuario_tipo'] ?? '';
    
    // Contar itens no carrinho
    if (isset($_SESSION['carrinho']) && is_array($_SESSION['carrinho'])) {
        $carrinhoCount = count($_SESSION['carrinho']);
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PGS Periféricos - Loja de Periféricos Gamers</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <!-- Header -->
    <header class="bg-dark text-white sticky-top">
        <div class="container">
            <div class="row align-items-center py-2">
                <!-- Logo -->
                <div class="col-md-3">
                    <a href="indexx.php" class="text-decoration-none">
                        <h3 class="text-warning mb-0">
                            <i class="fas fa-gamepad me-2"></i>
                            PGS Periféricos
                        </h3>
                    </a>
                </div>

                <!-- Barra de Pesquisa -->
                <div class="col-md-4">
                    <form action="produtos.php" method="GET" class="d-flex">
                        <div class="input-group">
                            <input type="text" class="form-control" name="busca" placeholder="Buscar produtos..." 
                                   value="<?php echo isset($_GET['busca']) ? htmlspecialchars($_GET['busca']) : ''; ?>">
                            <button class="btn btn-warning" type="submit">
                                <i class="fas fa-search"></i>
                            </button>
                        </div>
                    </form>
                </div>

                <!-- Menu Usuário -->
                <div class="col-md-5">
                    <div class="d-flex justify-content-end align-items-center gap-3">
                        <!-- Lista de Desejos -->
                        <?php if (usuarioEstaLogado() && $_SESSION['usuario_tipo'] === 'cliente'): ?>
                            <a href="lista_desejos.php" class="text-white text-decoration-none" title="Lista de Desejos">
                                <i class="fas fa-heart me-1"></i>
                                <span class="d-none d-md-inline">Desejos</span>
                            </a>
                        <?php endif; ?>

                        <!-- Botão Admin para funcionários -->
                        <?php if (isFuncionario()): ?>
                            <a href="admin/admin.php" class="text-white text-decoration-none" title="Painel Administrativo">
                                <i class="fas fa-cog me-1"></i>
                                <span class="d-none d-md-inline">Admin</span>
                            </a>
                        <?php endif; ?>

                        <!-- Carrinho -->
                        <a href="carrinho.php" class="text-white text-decoration-none position-relative" title="Carrinho de Compras">
                            <i class="fas fa-shopping-cart me-1"></i>
                            <span class="d-none d-md-inline">Carrinho</span>
                            <?php if ($carrinhoCount > 0): ?>
                                <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-warning text-dark">
                                    <?php echo $carrinhoCount; ?>
                                </span>
                            <?php endif; ?>
                        </a>

                        <!-- Menu do Usuário -->
                        <?php if (usuarioEstaLogado()): ?>
                            <div class="dropdown">
                                <button class="btn btn-outline-light dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                    <i class="fas fa-user me-1"></i>
                                    <?php echo explode(' ', $_SESSION['usuario_nome'])[0]; ?>
                                </button>
                                <ul class="dropdown-menu dropdown-menu-end">
                                    <li>
                                        <a class="dropdown-item" href="minha_conta.php">
                                            <i class="fas fa-user-circle me-2"></i>Meu Perfil
                                        </a>
                                    </li>
                                    
                                    <?php if ($_SESSION['usuario_tipo'] === 'cliente'): ?>
                                        <li>
                                            <a class="dropdown-item" href="meus_pedidos.php">
                                                <i class="fas fa-shopping-bag me-2"></i>Meus Pedidos
                                            </a>
                                        </li>
                                        <li>
                                            <a class="dropdown-item" href="lista_desejos.php">
                                                <i class="fas fa-heart me-2"></i>Lista de Desejos
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <?php if (isFuncionario()): ?>
                                        <li>
                                            <a class="dropdown-item" href="admin/admin.php">
                                                <i class="fas fa-cog me-2"></i>Painel Admin
                                            </a>
                                        </li>
                                    <?php endif; ?>

                                    <li><hr class="dropdown-divider"></li>
                                    
                                    <li>
                                        <a class="dropdown-item" href="suporte.php">
                                            <i class="fas fa-headset me-2"></i>Suporte
                                        </a>
                                    </li>
                                    
                                    <li>
                                        <a class="dropdown-item" href="faq.php">
                                            <i class="fas fa-question-circle me-2"></i>FAQ
                                        </a>
                                    </li>

                                    <li><hr class="dropdown-divider"></li>
                                    
                                    <li>
                                        <a class="dropdown-item text-danger" href="includes/logout.php">
                                            <i class="fas fa-sign-out-alt me-2"></i>Sair
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        <?php else: ?>
                            <!-- Usuário não logado -->
                            <a href="login.php" class="btn btn-outline-light">
                                <i class="fas fa-sign-in-alt me-1"></i>
                                Entrar
                            </a>
                            <a href="cadastro.php" class="btn btn-warning">
                                <i class="fas fa-user-plus me-1"></i>
                                Cadastrar
                            </a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu de Navegação SIMPLIFICADO -->
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark border-top border-secondary">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav me-auto">
                        <li class="nav-item">
                            <a class="nav-link" href="indexx.php">
                                <i class="fas fa-home me-1"></i>Início
                            </a>
                        </li>

                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?destaque=1">
                                <i class="fas fa-star me-1"></i>Destaques
                            </a>
                        </li>
                        
                        <li class="nav-item">
                            <a class="nav-link" href="produtos.php?promocao=1">
                                <i class="fas fa-tag me-1"></i>Promoções
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </nav>
    </header>

    <?php mostrarMensagem(); ?>

    <!-- Conteúdo Principal -->
    <main>