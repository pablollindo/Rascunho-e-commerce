<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Abrir Ticket - Suporte PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <!-- Header -->
    <?php include 'includes/cabecalho_simples.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="card shadow">
                    <div class="card-header bg-primary text-white text-center py-4">
                        <h2 class="mb-0">
                            <i class="fas fa-ticket-alt me-2"></i>
                            Abrir Ticket de Suporte
                        </h2>
                        <p class="mb-0 mt-2">Preencha o formulário abaixo para receber ajuda</p>
                    </div>
                    <div class="card-body p-4">
                        
                        <!-- Informações -->
                        <div class="alert alert-info mb-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-info-circle fa-2x me-3"></i>
                                <div>
                                    <h6 class="mb-1">Como funciona o suporte?</h6>
                                    <p class="mb-0">Após abrir o ticket, nossa equipe entrará em contato em até 24 horas.</p>
                                </div>
                            </div>
                        </div>

                        <!-- Mensagens -->
                        <?php mostrarMensagem(); ?>

                        <form action="includes/processa_suporte.php" method="POST">
                            <!-- Assunto -->
                            <div class="mb-3">
                                <label for="assunto" class="form-label">
                                    <i class="fas fa-heading me-1 text-primary"></i>
                                    Assunto do Ticket *
                                </label>
                                <input type="text" class="form-control form-control-lg" id="assunto" name="assunto" 
                                       placeholder="Ex: Problema com meu pedido #12345" required
                                       value="<?php echo $_POST['assunto'] ?? ''; ?>">
                                <div class="form-text">
                                    Descreva brevemente o assunto do seu problema
                                </div>
                            </div>

                            <!-- Categoria -->
                            <div class="mb-3">
                                <label for="categoria" class="form-label">
                                    <i class="fas fa-folder me-1 text-primary"></i>
                                    Categoria *
                                </label>
                                <select class="form-select form-select-lg" id="categoria" name="categoria" required>
                                    <option value="">Selecione uma categoria</option>
                                    <option value="compra" <?php echo (isset($_POST['categoria']) && $_POST['categoria'] == 'compra') ? 'selected' : ''; ?>>Problema com Compra</option>
                                    <option value="produto" <?php echo (isset($_POST['categoria']) && $_POST['categoria'] == 'produto') ? 'selected' : ''; ?>>Problema com Produto</option>
                                    <option value="garantia" <?php echo (isset($_POST['categoria']) && $_POST['categoria'] == 'garantia') ? 'selected' : ''; ?>>Garantia</option>
                                    <option value="entrega" <?php echo (isset($_POST['categoria']) && $_POST['categoria'] == 'entrega') ? 'selected' : ''; ?>>Problema com Entrega</option>
                                    <option value="conta" <?php echo (isset($_POST['categoria']) && $_POST['categoria'] == 'conta') ? 'selected' : ''; ?>>Problema com Conta</option>
                                    <option value="outros" <?php echo (isset($_POST['categoria']) && $_POST['categoria'] == 'outros') ? 'selected' : ''; ?>>Outros</option>
                                </select>
                            </div>

                            <!-- Prioridade -->
                            <div class="mb-3">
                                <label for="prioridade" class="form-label">
                                    <i class="fas fa-exclamation-circle me-1 text-primary"></i>
                                    Prioridade *
                                </label>
                                <select class="form-select form-select-lg" id="prioridade" name="prioridade" required>
                                    <option value="">Selecione a prioridade</option>
                                    <option value="baixa" <?php echo (isset($_POST['prioridade']) && $_POST['prioridade'] == 'baixa') ? 'selected' : ''; ?>>Baixa</option>
                                    <option value="media" <?php echo (isset($_POST['prioridade']) && $_POST['prioridade'] == 'media') ? 'selected' : ''; ?>>Média</option>
                                    <option value="alta" <?php echo (isset($_POST['prioridade']) && $_POST['prioridade'] == 'alta') ? 'selected' : ''; ?>>Alta</option>
                                    <option value="urgente" <?php echo (isset($_POST['prioridade']) && $_POST['prioridade'] == 'urgente') ? 'selected' : ''; ?>>Urgente</option>
                                </select>
                                <div class="form-text">
                                    <strong>Baixa:</strong> Dúvidas gerais | 
                                    <strong>Média:</strong> Problemas com produtos | 
                                    <strong>Alta:</strong> Problemas com pedidos | 
                                    <strong>Urgente:</strong> Problemas críticos
                                </div>
                            </div>

                            <!-- Descrição -->
                            <div class="mb-4">
                                <label for="descricao" class="form-label">
                                    <i class="fas fa-file-alt me-1 text-primary"></i>
                                    Descrição Detalhada *
                                </label>
                                <textarea class="form-control" id="descricao" name="descricao" rows="6" 
                                          placeholder="Descreva seu problema com o máximo de detalhes possível. Inclua números de pedido, códigos de produto, datas, etc." 
                                          required><?php echo $_POST['descricao'] ?? ''; ?></textarea>
                                <div class="form-text">
                                    Quanto mais detalhes você fornecer, mais rápido poderemos ajudá-lo
                                </div>
                            </div>

                            <!-- Informações do Usuário -->
                            <?php if (usuarioEstaLogado()): ?>
                                <div class="alert alert-success">
                                    <h6 class="alert-heading">
                                        <i class="fas fa-user-check me-2"></i>
                                        Identificado como: <?php echo $_SESSION['usuario_nome']; ?>
                                    </h6>
                                    <p class="mb-0">Seu ticket será vinculado à sua conta.</p>
                                </div>
                            <?php else: ?>
                                <div class="alert alert-warning">
                                    <h6 class="alert-heading">
                                        <i class="fas fa-exclamation-triangle me-2"></i>
                                        Você não está logado
                                    </h6>
                                    <p class="mb-0">
                                        <a href="login.php?redirect=suporte" class="alert-link">Faça login</a> 
                                        para vincular este ticket à sua conta e acompanhar o andamento.
                                    </p>
                                </div>
                            <?php endif; ?>

                                <!-- Botões -->
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="faq.php" class="btn btn-outline-secondary btn-lg me-md-2">
                                    <i class="fas fa-arrow-left me-2"></i>
                                    Voltar para FAQ
                                </a>
                                
                                <!-- Botão Ver Meus Tickets (apenas para usuários logados) -->
                                <?php if (usuarioEstaLogado()): ?>
                                <a href="meus_tickets.php" class="btn btn-outline-primary btn-lg me-md-2">
                                    <i class="fas fa-ticket-alt me-2"></i>
                                    Ver Meus Tickets
                                </a>
                                <?php endif; ?>
                                
                                <button type="submit" class="btn btn-primary btn-lg">
                                    <i class="fas fa-paper-plane me-2"></i>
                                    Abrir Ticket
                                </button>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Informações Adicionais -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card border-info h-100">
                            <div class="card-body text-center">
                                <h6 class="text-info mb-2">
                                    <i class="fas fa-clock me-1"></i>
                                    Tempo de Resposta
                                </h6>
                                <p class="small text-muted mb-2">
                                    <strong>Urgente:</strong> Até 2 horas<br>
                                    <strong>Alta:</strong> Até 6 horas<br>
                                    <strong>Média:</strong> Até 24 horas<br>
                                    <strong>Baixa:</strong> Até 48 horas
                                </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card border-success h-100">
                            <div class="card-body text-center">
                                <h6 class="text-success mb-2">
                                    <i class="fas fa-mobile-alt me-1"></i>
                                    Outros Canais
                                </h6>
                                <p class="small text-muted mb-2">
                                    <strong>Telefone:</strong> (11) 99999-9999<br>
                                    <strong>WhatsApp:</strong> (11) 98888-8888<br>
                                    <strong>Email:</strong> suporte@pgs.com
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Contador de caracteres para a descrição
        document.addEventListener('DOMContentLoaded', function() {
            const descricaoTextarea = document.getElementById('descricao');
            const formText = descricaoTextarea.nextElementSibling;
            
            // Adicionar contador
            const counter = document.createElement('div');
            counter.className = 'form-text text-end';
            counter.innerHTML = '<span id="charCount">0</span> caracteres digitados';
            formText.parentNode.insertBefore(counter, formText.nextSibling);
            
            descricaoTextarea.addEventListener('input', function() {
                document.getElementById('charCount').textContent = this.value.length;
            });
        });
    </script>
</body>
</html>