<?php
require_once 'config.php';

if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para gerenciar sua lista de desejos.";
    redirecionar('login.php');
}

$action = $_GET['action'] ?? '';
$product_id = $_GET['product_id'] ?? 0;
$usuario_id = $_SESSION['usuario_id'];

switch ($action) {
    case 'add':
        // Verificar se já está na lista
        $check_sql = "SELECT id FROM wishlist WHERE usuario_id = ? AND produto_id = ?";
        $stmt = $conn->prepare($check_sql);
        $stmt->bind_param("ii", $usuario_id, $product_id);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 0) {
            $insert_sql = "INSERT INTO wishlist (usuario_id, produto_id) VALUES (?, ?)";
            $stmt = $conn->prepare($insert_sql);
            $stmt->bind_param("ii", $usuario_id, $product_id);
            
            if ($stmt->execute()) {
                $_SESSION['sucesso'] = "Produto adicionado à lista de desejos!";
            } else {
                $_SESSION['erro'] = "Erro ao adicionar produto à lista de desejos.";
            }
        } else {
            $_SESSION['erro'] = "Este produto já está na sua lista de desejos.";
        }
        break;
        
    case 'remove':
        $delete_sql = "DELETE FROM wishlist WHERE usuario_id = ? AND produto_id = ?";
        $stmt = $conn->prepare($delete_sql);
        $stmt->bind_param("ii", $usuario_id, $product_id);
        
        if ($stmt->execute()) {
            $_SESSION['sucesso'] = "Produto removido da lista de desejos.";
        } else {
            $_SESSION['erro'] = "Erro ao remover produto da lista de desejos.";
        }
        break;
        
    case 'clear':
        $clear_sql = "DELETE FROM wishlist WHERE usuario_id = ?";
        $stmt = $conn->prepare($clear_sql);
        $stmt->bind_param("i", $usuario_id);
        
        if ($stmt->execute()) {
            $_SESSION['sucesso'] = "Lista de desejos limpa com sucesso.";
        } else {
            $_SESSION['erro'] = "Erro ao limpar lista de desejos.";
        }
        break;
}

// Redirecionar de volta
$redirect = $_GET['redirect'] ?? 'lista_desejos.php';
redirecionar($redirect);
?>