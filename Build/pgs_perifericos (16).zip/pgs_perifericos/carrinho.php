<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// VERIFICAÇÃO: Bloquear funcionários/admin de acessar carrinho
if (usuarioEstaLogado() && (isAdmin() || isFuncionario())) {
    $_SESSION['erro'] = 'Funcionários e administradores não podem realizar compras.';
    header('Location: indexx.php');
    exit;
}

// Inicializar carrinho se não existir
if (!isset($_SESSION['carrinho'])) {
    $_SESSION['carrinho'] = [];
}

// Processar ações via GET (para remoção simples)
if (isset($_GET['acao'])) {
    switch ($_GET['acao']) {
        case 'remover':
            $produto_id = intval($_GET['id']);
            if (isset($_SESSION['carrinho'][$produto_id])) {
                $produto_nome = $_SESSION['carrinho'][$produto_id]['nome'];
                unset($_SESSION['carrinho'][$produto_id]);
                $_SESSION['sucesso'] = "{$produto_nome} removido do carrinho!";
            }
            header('Location: carrinho.php');
            exit;
            
        case 'limpar':
            $_SESSION['carrinho'] = [];
            $_SESSION['sucesso'] = 'Carrinho limpo com sucesso!';
            header('Location: carrinho.php');
            exit;
    }
}

// Buscar informações completas dos produtos no carrinho do banco
$carrinho_detalhado = [];
$subtotal = 0;
$total_itens = 0;
$carrinho_vazio = empty($_SESSION['carrinho']);

if (!$carrinho_vazio) {
    try {
        // Usando mysqli - forma SIMPLES
        $produtos_ids = array_keys($_SESSION['carrinho']);
        $placeholders = str_repeat('?,', count($produtos_ids) - 1) . '?';
        
        $sql = "SELECT p.*, m.nome as marca_nome, c.nome as categoria_nome 
                FROM produtos p 
                LEFT JOIN marcas m ON p.marca_id = m.id 
                LEFT JOIN categorias c ON p.categoria_id = c.id 
                WHERE p.id IN ($placeholders) AND p.ativo = 1";
        
        $stmt = $conn->prepare($sql);
        
        // Bind dos parâmetros
        $types = str_repeat('i', count($produtos_ids));
        $stmt->bind_param($types, ...$produtos_ids);
        $stmt->execute();
        $result = $stmt->get_result();
        $produtos_db = [];
        
        while ($row = $result->fetch_assoc()) {
            $produtos_db[] = $row;
        }
        
        // Combinar dados da sessão com dados do banco
        foreach ($produtos_db as $produto) {
            $produto_id = $produto['id'];
            $carrinho_detalhado[$produto_id] = array_merge(
                $produto,
                $_SESSION['carrinho'][$produto_id]
            );
        }
        
        // Calcular totais
        foreach ($carrinho_detalhado as $item) {
            $preco = $item['preco_promocional'] && $item['preco_promocional'] > 0 ? $item['preco_promocional'] : $item['preco'];
            $subtotal += $preco * $item['quantidade'];
            $total_itens += $item['quantidade'];
        }
        
    } catch (Exception $e) {
        error_log("Erro ao buscar produtos do carrinho: " . $e->getMessage());
        $_SESSION['erro'] = "Erro ao carregar informações dos produtos.";
    }
}

$frete = $subtotal >= 299.90 ? 0 : 29.90;
$total = $subtotal + $frete;
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Carrinho de Compras - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/carrinho.css">
</head>
<body>
    <?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho do Carrinho -->
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1 class="h2">
                        <i class="fas fa-shopping-cart text-primary me-2"></i>
                        Meu Carrinho
                    </h1>
                    <div class="breadcrumb-nav">
                        <nav aria-label="breadcrumb">
                            <ol class="breadcrumb">
                                <li class="breadcrumb-item"><a href="indexx.php">Início</a></li>
                                <li class="breadcrumb-item active">Carrinho</li>
                            </ol>
                        </nav>
                    </div>
                </div>

                <!-- Mensagens do Sistema -->
                <?php mostrarMensagem(); ?>

                <?php if ($carrinho_vazio): ?>
                    <!-- Carrinho Vazio -->
                    <div class="text-center py-5">
                        <div class="empty-cart-icon mb-4">
                            <i class="fas fa-shopping-cart fa-5x text-muted"></i>
                        </div>
                        <h3 class="text-muted mb-3">Seu carrinho está vazio</h3>
                        <p class="text-muted mb-4">Adicione alguns produtos incríveis ao seu carrinho!</p>
                        <a href="produtos.php" class="btn btn-primary btn-lg">
                            <i class="fas fa-shopping-bag me-2"></i>
                            Continuar Comprando
                        </a>
                    </div>
                <?php else: ?>
                    <div class="row">
                        <!-- Lista de Produtos -->
                        <div class="col-lg-8">
                            <div class="card shadow-sm mb-4">
                                <div class="card-header bg-light">
                                    <h5 class="mb-0">
                                        <i class="fas fa-boxes me-2"></i>
                                        Produtos no Carrinho (<?php echo $total_itens; ?>)
                                    </h5>
                                </div>
                                <div class="card-body p-0" id="cart-items-container">
                                    <?php foreach ($carrinho_detalhado as $product_id => $item): 
                                        $preco_final = $item['preco_promocional'] && $item['preco_promocional'] > 0 ? $item['preco_promocional'] : $item['preco'];
                                        $subtotal_item = $preco_final * $item['quantidade'];
                                        $imagem = !empty($item['imagem']) ? $item['imagem'] : 'assets/imagens/produtos/sem-imagem.jpg';
                                        $tem_estoque = $item['quantidade'] <= $item['estoque'];
                                    ?>
                                    <div class="cart-item border-bottom" id="cart-item-<?php echo $product_id; ?>">
                                        <div class="row align-items-center p-3">
                                            <div class="col-12 col-sm-2 mb-2 mb-sm-0">
                                                <img src="<?php echo $imagem; ?>" 
                                                     alt="<?php echo htmlspecialchars($item['nome']); ?>" 
                                                     class="img-fluid rounded cart-item-image">
                                            </div>
                                            <div class="col-12 col-sm-4 mb-2 mb-sm-0">
                                                <h6 class="mb-1"><?php echo htmlspecialchars($item['nome']); ?></h6>
                                                <p class="text-muted small mb-1">
                                                    <span class="badge bg-secondary"><?php echo htmlspecialchars($item['marca_nome']); ?></span> • 
                                                    <span class="badge bg-light text-dark"><?php echo htmlspecialchars($item['categoria_nome']); ?></span>
                                                </p>
                                                <div class="stock-status">
                                                    <?php if ($tem_estoque): ?>
                                                        <span class="badge bg-success">
                                                            <i class="fas fa-check me-1"></i>Em estoque
                                                        </span>
                                                    <?php else: ?>
                                                        <span class="badge bg-danger">
                                                            <i class="fas fa-exclamation-triangle me-1"></i>Estoque insuficiente
                                                        </span>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-2 mb-2 mb-sm-0 text-center">
                                                <div class="quantity-controls d-flex align-items-center justify-content-center">
                                                    <button class="btn btn-outline-secondary btn-sm quantity-btn decrease" 
                                                            onclick="atualizarQuantidade(<?php echo $product_id; ?>, -1)">
                                                        <i class="fas fa-minus"></i>
                                                    </button>
                                                    <input type="number" 
                                                           class="form-control form-control-sm quantity-input mx-1 text-center" 
                                                           value="<?php echo $item['quantidade']; ?>" 
                                                           min="1" 
                                                           max="<?php echo $item['estoque']; ?>"
                                                           readonly>
                                                    <button class="btn btn-outline-secondary btn-sm quantity-btn increase" 
                                                            onclick="atualizarQuantidade(<?php echo $product_id; ?>, 1)">
                                                        <i class="fas fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-2 mb-2 mb-sm-0 text-center">
                                                <div class="price-info">
                                                    <div class="h6 mb-0 text-primary fw-bold">
                                                        R$ <?php echo number_format($preco_final, 2, ',', '.'); ?>
                                                    </div>
                                                    <?php if ($item['preco_promocional'] && $item['preco_promocional'] > 0): ?>
                                                        <small class="text-muted text-decoration-line-through">
                                                            R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?>
                                                        </small>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                            <div class="col-12 col-sm-2 text-center">
                                                <div class="item-actions">
                                                    <button class="btn btn-outline-danger btn-sm remove-item mb-1" 
                                                            onclick="removerItem(<?php echo $product_id; ?>, '<?php echo htmlspecialchars($item['nome']); ?>')">
                                                        <i class="fas fa-trash"></i> Remover
                                                    </button>
                                                    <div>
                                                        <small class="text-muted">
                                                            Subtotal: <br>
                                                            <strong class="text-dark">R$ <?php echo number_format($subtotal_item, 2, ',', '.'); ?></strong>
                                                        </small>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>

                            <!-- Ações do Carrinho -->
                            <div class="d-flex justify-content-between">
                                <a href="produtos.php" class="btn btn-outline-primary">
                                    <i class="fas fa-arrow-left me-2"></i>
                                    Continuar Comprando
                                </a>
                                <div>
                                    <a href="carrinho.php?acao=limpar" class="btn btn-outline-danger" 
                                       onclick="return confirm('Tem certeza que deseja limpar todo o carrinho?')">
                                        <i class="fas fa-trash me-2"></i>
                                        Limpar Carrinho
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Resumo do Pedido -->
                        <div class="col-lg-4">
                            <div class="card shadow-sm resumo-pedido-card">
                                <div class="card-header bg-primary text-white">
                                    <h5 class="mb-0">
                                        <i class="fas fa-receipt me-2"></i>
                                        Resumo do Pedido
                                    </h5>
                                </div>
                                <div class="card-body">
                                    <!-- Itens do Resumo -->
                                    <div class="resumo-item d-flex justify-content-between mb-2">
                                        <span>Subtotal (<?php echo $total_itens; ?> itens):</span>
                                        <span>R$ <?php echo number_format($subtotal, 2, ',', '.'); ?></span>
                                    </div>

                                    <div class="resumo-item d-flex justify-content-between mb-2">
                                        <span>Frete:</span>
                                        <span><?php echo $frete == 0 ? '<span class="text-success">Grátis</span>' : 'R$ ' . number_format($frete, 2, ',', '.'); ?></span>
                                    </div>
                                    <hr>
                                    <div class="resumo-total d-flex justify-content-between mb-3">
                                        <strong>Total:</strong>
                                        <strong class="h5 text-primary">R$ <?php echo number_format($total, 2, ',', '.'); ?></strong>
                                    </div>

                                    <!-- Frete Grátis Progress -->
                                    <?php if ($subtotal < 299.90): ?>
                                    <div class="alert alert-info mb-3">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-shipping-fast me-2"></i>
                                            <div class="flex-grow-1">
                                                <small class="d-block">Faltam <strong>R$ <?php echo number_format(299.90 - $subtotal, 2, ',', '.'); ?></strong> para frete grátis!</small>
                                                <div class="progress mt-1" style="height: 6px;">
                                                    <div class="progress-bar bg-info" style="width: <?php echo ($subtotal / 299.90) * 100; ?>%"></div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <?php else: ?>
                                    <div class="alert alert-success mb-3">
                                        <div class="d-flex align-items-center">
                                            <i class="fas fa-check-circle me-2"></i>
                                            <small>Parabéns! Você ganhou frete grátis!</small>
                                        </div>
                                    </div>
                                    <?php endif; ?>

                                    <!-- Botão Finalizar Compra -->
                                    <?php if (usuarioEstaLogado()): ?>
                                        <a href="finalizar_compra.php" class="btn btn-warning btn-lg w-100 mb-3">
                                            <i class="fas fa-credit-card me-2"></i>
                                            Finalizar Compra
                                        </a>
                                    <?php else: ?>
                                        <a href="login.php?redirect=carrinho" class="btn btn-warning btn-lg w-100 mb-3">
                                            <i class="fas fa-sign-in-alt me-2"></i>
                                            Fazer Login para Comprar
                                        </a>
                                    <?php endif; ?>

                                    <!-- Métodos de Pagamento -->
                                    <div class="text-center mb-3">
                                        <small class="text-muted">Métodos de pagamento aceitos:</small>
                                        <div class="mt-2">
                                            <i class="fab fa-cc-visa fa-2x me-2 text-primary" title="Cartão de Crédito"></i>
                                            <i class="fab fa-cc-mastercard fa-2x me-2 text-danger" title="Cartão de Crédito"></i>
                                            <i class="fas fa-barcode fa-2x me-2 text-success" title="Boleto"></i>
                                            <i class="fas fa-qrcode fa-2x text-success" title="PIX"></i>
                                        </div>
                                    </div>

                                    <!-- Segurança -->
                                    <div class="text-center">
                                        <small class="text-muted">
                                            <i class="fas fa-lock me-1"></i>
                                            Compra 100% segura
                                        </small>
                                    </div>
                                </div>
                            </div>

                            <!-- Benefícios -->
                            <div class="card shadow-sm mt-4">
                                <div class="card-body">
                                    <h6 class="mb-3">
                                        <i class="fas fa-shield-alt text-success me-2"></i>
                                        Sua Compra é Protegida
                                    </h6>
                                    <div class="benefit-item mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Garantia de 12 meses</small>
                                    </div>
                                    <div class="benefit-item mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Troca em 30 dias</small>
                                    </div>
                                    <div class="benefit-item mb-2">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Compra segura SSL</small>
                                    </div>
                                    <div class="benefit-item">
                                        <i class="fas fa-check text-success me-2"></i>
                                        <small>Suporte 24/7</small>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </main>

    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
    // Método SUPER SIMPLES para atualizar quantidade
    function atualizarQuantidade(productId, change) {
        // Redirecionamento DIRETO sem AJAX
        window.location.href = `includes/processa_carrinho.php?action=update&product_id=${productId}&quantity=${getNovaQuantidade(productId, change)}`;
    }
    
    function getNovaQuantidade(productId, change) {
        const input = document.querySelector(`#cart-item-${productId} .quantity-input`);
        let quantity = parseInt(input.value);
        quantity += change;
        return Math.max(1, quantity);
    }
    
    function removerItem(productId, productName) {
        if (confirm(`Deseja remover "${productName}" do carrinho?`)) {
            window.location.href = `carrinho.php?acao=remover&id=${productId}`;
        }
    }
    </script>
</body>
</html>