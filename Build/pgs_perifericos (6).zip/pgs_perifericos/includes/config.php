<?php
session_start();

// Configurações do banco de dados - PORTA 3309
define('DB_HOST', 'localhost:3309');
define('DB_NAME', 'pgs_perifericos');
define('DB_USER', 'root');
define('DB_PASS', '');

// Conexão com o banco de dados
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Verificar conexão
    if ($conn->connect_error) {
        throw new Exception("Erro de conexão: " . $conn->connect_error);
    }
    
    // Definir charset
    $conn->set_charset("utf8mb4");
    
} catch (Exception $e) {
    die("Erro no banco de dados: " . $e->getMessage());
}
?>