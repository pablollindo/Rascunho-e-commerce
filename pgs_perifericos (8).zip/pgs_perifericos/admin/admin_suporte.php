<?php
require_once '../includes/config.php';
require_once '../includes/funcoes.php';

// Verificar se é admin ou funcionário com permissão
if (!isFuncionario()) {
    $_SESSION['erro'] = "Acesso restrito à funcionários.";
    header("Location: ../indexx.php");
    exit;
}

$action = $_GET['action'] ?? 'list';
$ticket_id = intval($_GET['id'] ?? 0);
$status_filter = $_GET['status'] ?? 'todos';

try {
    $pdo = conectarBanco();
    
    switch ($action) {
        case 'view':
            if ($ticket_id > 0) {
                // Buscar ticket e mensagens
                $stmt = $pdo->prepare("SELECT t.*, u.nome as usuario_nome, u.email as usuario_email, 
                                      f.nome as funcionario_nome
                                      FROM tickets_suporte t
                                      JOIN usuarios u ON t.usuario_id = u.id
                                      LEFT JOIN funcionarios f ON t.funcionario_responsavel = f.id
                                      WHERE t.id = ?");
                $stmt->execute([$ticket_id]);
                $ticket = $stmt->fetch(PDO::FETCH_ASSOC);
                
                if (!$ticket) {
                    $_SESSION['erro'] = "Ticket não encontrado.";
                    header("Location: admin_suporte.php");
                    exit;
                }
                
                // Buscar mensagens do ticket
                $stmt = $pdo->prepare("SELECT m.*, u.nome as usuario_nome, u.tipo as usuario_tipo
                                      FROM mensagens_suporte m
                                      JOIN usuarios u ON m.usuario_id = u.id
                                      WHERE m.ticket_id = ?
                                      ORDER BY m.data_envio ASC");
                $stmt->execute([$ticket_id]);
                $mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
            }
            break;
            
        case 'atribuir':
            if ($ticket_id > 0 && isAdmin()) {
                $funcionario_id = intval($_POST['funcionario_id']);
                $stmt = $pdo->prepare("UPDATE tickets_suporte SET funcionario_responsavel = ? WHERE id = ?");
                $stmt->execute([$funcionario_id, $ticket_id]);
                $_SESSION['sucesso'] = "Ticket atribuído com sucesso!";
                header("Location: admin_suporte.php?action=view&id=" . $ticket_id);
                exit;
            }
            break;
            
        case 'responder':
            if ($ticket_id > 0 && $_SERVER['REQUEST_METHOD'] === 'POST') {
                $mensagem = trim($_POST['mensagem']);
                
                if (empty($mensagem)) {
                    $_SESSION['erro'] = "A mensagem não pode estar vazia.";
                    header("Location: admin_suporte.php?action=view&id=" . $ticket_id);
                    exit;
                }
                
                // Inserir mensagem
                $stmt = $pdo->prepare("INSERT INTO mensagens_suporte (ticket_id, usuario_id, mensagem, eh_funcionario) 
                                      VALUES (?, ?, ?, 1)");
                $stmt->execute([$ticket_id, $_SESSION['usuario_id'], $mensagem]);
                
                // Atualizar status do ticket
                $stmt = $pdo->prepare("UPDATE tickets_suporte SET status = 'respondido', data_ultima_resposta = NOW() WHERE id = ?");
                $stmt->execute([$ticket_id]);
                
                $_SESSION['sucesso'] = "Resposta enviada com sucesso!";
                header("Location: admin_suporte.php?action=view&id=" . $ticket_id);
                exit;
            }
            break;
            
        case 'fechar':
            if ($ticket_id > 0) {
                $stmt = $pdo->prepare("UPDATE tickets_suporte SET status = 'fechado', data_fechamento = NOW() WHERE id = ?");
                $stmt->execute([$ticket_id]);
                $_SESSION['sucesso'] = "Ticket fechado com sucesso!";
                header("Location: admin_suporte.php?action=view&id=" . $ticket_id);
                exit;
            }
            break;
            
        case 'reabrir':
            if ($ticket_id > 0) {
                $stmt = $pdo->prepare("UPDATE tickets_suporte SET status = 'aberto', data_fechamento = NULL WHERE id = ?");
                $stmt->execute([$ticket_id]);
                $_SESSION['sucesso'] = "Ticket reaberto com sucesso!";
                header("Location: admin_suporte.php?action=view&id=" . $ticket_id);
                exit;
            }
            break;
    }
    
    // Buscar tickets com filtro
    $sql_tickets = "SELECT t.*, u.nome as usuario_nome, u.email as usuario_email,
                   f.nome as funcionario_nome,
                   (SELECT COUNT(*) FROM mensagens_suporte WHERE ticket_id = t.id) as total_mensagens
                   FROM tickets_suporte t
                   JOIN usuarios u ON t.usuario_id = u.id
                   LEFT JOIN funcionarios f ON t.funcionario_responsavel = f.id";
    
    $params = [];
    if ($status_filter !== 'todos') {
        $sql_tickets .= " WHERE t.status = ?";
        $params[] = $status_filter;
    }
    
    $sql_tickets .= " ORDER BY 
                     CASE 
                         WHEN t.status = 'aberto' THEN 1
                         WHEN t.status = 'em_andamento' THEN 2
                         WHEN t.status = 'respondido' THEN 3
                         ELSE 4
                     END,
                     t.prioridade DESC,
                     t.data_abertura DESC";
    
    $stmt = $pdo->prepare($sql_tickets);
    $stmt->execute($params);
    $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Buscar funcionários para atribuição
    $funcionarios = $pdo->query("SELECT id, nome FROM funcionarios WHERE ativo = 1 ORDER BY nome")->fetchAll(PDO::FETCH_ASSOC);
    
} catch (PDOException $e) {
    $_SESSION['erro'] = "Erro ao carregar tickets: " . $e->getMessage();
    $tickets = [];
    $funcionarios = [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Suporte - Admin - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/estilo.css">
    <style>
        .admin-container {
            background: #f8f9fa;
            min-height: 100vh;
        }
        .admin-sidebar {
            background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
            min-height: calc(100vh - 200px);
            color: white;
        }
        .admin-sidebar .nav-link {
            color: white;
            padding: 12px 20px;
            margin: 2px 0;
            border-radius: 5px;
            transition: all 0.3s;
        }
        .admin-sidebar .nav-link:hover {
            background: rgba(255,255,255,0.1);
            transform: translateX(5px);
        }
        .admin-sidebar .nav-link.active {
            background: rgba(255,255,255,0.2);
            font-weight: bold;
            border-left: 4px solid #ffc107;
        }
        .admin-content {
            background: white;
            min-height: calc(100vh - 200px);
            padding: 20px;
        }
        .content-header {
            background: white;
            border-bottom: 1px solid #dee2e6;
            padding: 20px 0;
            margin-bottom: 20px;
        }
        .mensagem-cliente {
            background: #f8f9fa;
            border-left: 4px solid #0d6efd;
        }
        .mensagem-funcionario {
            background: #e7f3ff;
            border-left: 4px solid #198754;
        }
        .ticket-urgente {
            background-color: #f8d7da !important;
        }
        .ticket-alta {
            background-color: #fff3cd !important;
        }
    </style>
</head>
<body>
    <?php 
    $tituloPagina = "Gerenciar Suporte - Admin";
    require_once '../includes/cabecalho.php'; 
    ?>

    <div class="admin-container">
        <div class="container-fluid">
            <div class="row">
                <!-- Sidebar -->
                <div class="col-md-3 col-lg-2 admin-sidebar p-0">
                    <div class="p-4 text-center text-white">
                        <h4 class="mb-0">PGS Admin</h4>
                        <small>Painel de Controle</small>
                    </div>
                    
                    <nav class="nav flex-column p-3">
                        <a href="admin.php" class="nav-link">
                            <i class="fas fa-tachometer-alt me-2"></i>
                            Dashboard
                        </a>
                        
                        <a href="admin_produtos.php" class="nav-link">
                            <i class="fas fa-box me-2"></i>
                            Produtos
                        </a>
                        <a href="admin_estoque.php" class="nav-link">
                            <i class="fas fa-warehouse me-2"></i>
                            Estoque
                        </a>
                        <a href="admin_categorias_marcas.php" class="nav-link">
                            <i class="fas fa-tags me-2"></i>
                            Categorias & Marcas
                        </a>
                        
                        <a href="admin_pedidos.php" class="nav-link">
                            <i class="fas fa-shopping-cart me-2"></i>
                            Pedidos
                        </a>
                        
                        <a href="admin_usuarios.php" class="nav-link">
                            <i class="fas fa-users me-2"></i>
                            Clientes
                        </a>
                        <a href="admin_funcionarios.php" class="nav-link">
                            <i class="fas fa-user-tie me-2"></i>
                            Funcionários
                        </a>
                        
                        <a href="admin_suporte.php" class="nav-link active">
                            <i class="fas fa-headset me-2"></i>
                            Suporte
                        </a>
                        
                        <a href="admin_relatorios.php" class="nav-link">
                            <i class="fas fa-chart-bar me-2"></i>
                            Relatórios
                        </a>
                        
                        <hr class="bg-light my-3">
                        
                        <a href="../indexx.php" class="nav-link">
                            <i class="fas fa-store me-2"></i>
                            Voltar para Loja
                        </a>
                    </nav>
                </div>

                <!-- Conteúdo Principal -->
                <div class="col-md-9 col-lg-10 admin-content">
                    <!-- Header Interno -->
                    <div class="content-header">
                        <div class="d-flex justify-content-between align-items-center">
                            <h1 class="h3 mb-0">
                                <i class="fas fa-headset me-2"></i>
                                Gerenciar Suporte
                            </h1>
                            <div class="btn-toolbar mb-2 mb-md-0">
                                <span class="badge bg-primary fs-6">
                                    Total: <?= count($tickets) ?> tickets
                                </span>
                            </div>
                        </div>
                    </div>

                    <?php mostrarMensagem(); ?>

                    <?php if ($action === 'view' && isset($ticket)): ?>
                        <!-- Visualização do Ticket -->
                        <div class="card mb-4">
                            <div class="card-header bg-primary text-white">
                                <div class="d-flex justify-content-between align-items-center">
                                    <h5 class="mb-0">
                                        <i class="fas fa-ticket-alt me-2"></i>
                                        Ticket #<?= $ticket['id'] ?> - <?= htmlspecialchars($ticket['assunto']) ?>
                                    </h5>
                                    <div>
                                        <?php if ($ticket['status'] !== 'fechado'): ?>
                                            <a href="admin_suporte.php?action=fechar&id=<?= $ticket['id'] ?>" 
                                               class="btn btn-sm btn-warning"
                                               onclick="return confirm('Tem certeza que deseja fechar este ticket?')">
                                                <i class="fas fa-lock me-1"></i>
                                                Fechar Ticket
                                            </a>
                                        <?php else: ?>
                                            <a href="admin_suporte.php?action=reabrir&id=<?= $ticket['id'] ?>" 
                                               class="btn btn-sm btn-success">
                                                <i class="fas fa-lock-open me-1"></i>
                                                Reabrir Ticket
                                            </a>
                                        <?php endif; ?>
                                        <a href="admin_suporte.php" class="btn btn-sm btn-secondary">
                                            <i class="fas fa-arrow-left me-1"></i>
                                            Voltar
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="card-body">
                                <!-- Informações do Ticket -->
                                <div class="row mb-4">
                                    <div class="col-md-3">
                                        <strong>Cliente:</strong><br>
                                        <?= htmlspecialchars($ticket['usuario_nome']) ?><br>
                                        <small class="text-muted"><?= htmlspecialchars($ticket['usuario_email']) ?></small>
                                    </div>
                                    <div class="col-md-3">
                                        <strong>Categoria:</strong><br>
                                        <?= ucfirst($ticket['categoria']) ?>
                                    </div>
                                    <div class="col-md-3">
                                        <strong>Status:</strong><br>
                                        <span class="badge bg-<?= getStatusBadgeColor($ticket['status']) ?>">
                                            <?= ucfirst($ticket['status']) ?>
                                        </span>
                                    </div>
                                    <div class="col-md-3">
                                        <strong>Prioridade:</strong><br>
                                        <span class="badge bg-<?= getPrioridadeBadgeColor($ticket['prioridade']) ?>">
                                            <?= ucfirst($ticket['prioridade']) ?>
                                        </span>
                                    </div>
                                </div>
                                
                                <!-- Responsável -->
                                <?php if (isAdmin()): ?>
                                <div class="row mb-4">
                                    <div class="col-12">
                                        <form method="POST" action="admin_suporte.php?action=atribuir&id=<?= $ticket['id'] ?>" class="row g-3">
                                            <div class="col-md-6">
                                                <label class="form-label"><strong>Responsável:</strong></label>
                                                <div class="input-group">
                                                    <select name="funcionario_id" class="form-select">
                                                        <option value="">Não atribuído</option>
                                                        <?php foreach ($funcionarios as $func): ?>
                                                        <option value="<?= $func['id'] ?>" 
                                                                <?= $ticket['funcionario_responsavel'] == $func['id'] ? 'selected' : '' ?>>
                                                            <?= htmlspecialchars($func['nome']) ?>
                                                        </option>
                                                        <?php endforeach; ?>
                                                    </select>
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fas fa-save"></i>
                                                    </button>
                                                </div>
                                            </div>
                                            <div class="col-md-6">
                                                <label class="form-label"><strong>Atual:</strong></label>
                                                <div>
                                                    <?= $ticket['funcionario_nome'] ? htmlspecialchars($ticket['funcionario_nome']) : '<span class="text-muted">Não atribuído</span>' ?>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                                
                                <!-- Descrição Inicial -->
                                <div class="mb-4">
                                    <strong>Descrição do Problema:</strong>
                                    <div class="border rounded p-3 bg-light">
                                        <?= nl2br(htmlspecialchars($ticket['descricao'])) ?>
                                    </div>
                                </div>
                                
                                <!-- Mensagens -->
                                <h5 class="mb-3">
                                    <i class="fas fa-comments me-2"></i>
                                    Mensagens (<?= count($mensagens) ?>)
                                </h5>
                                
                                <div class="messages-container mb-4" style="max-height: 400px; overflow-y: auto;">
                                    <?php if (empty($mensagens)): ?>
                                        <div class="text-center text-muted py-4">
                                            <i class="fas fa-comment-slash fa-2x mb-3"></i><br>
                                            Nenhuma mensagem ainda.
                                        </div>
                                    <?php else: ?>
                                        <?php foreach ($mensagens as $msg): ?>
                                        <div class="card mb-3 <?= $msg['eh_funcionario'] ? 'mensagem-funcionario' : 'mensagem-cliente' ?>">
                                            <div class="card-body">
                                                <div class="d-flex justify-content-between align-items-start mb-2">
                                                    <strong>
                                                        <?= htmlspecialchars($msg['usuario_nome']) ?>
                                                        <?php if ($msg['eh_funcionario']): ?>
                                                            <span class="badge bg-success ms-2">Funcionário</span>
                                                        <?php else: ?>
                                                            <span class="badge bg-primary ms-2">Cliente</span>
                                                        <?php endif; ?>
                                                    </strong>
                                                    <small class="text-muted">
                                                        <?= date('d/m/Y H:i', strtotime($msg['data_envio'])) ?>
                                                    </small>
                                                </div>
                                                <div class="message-content">
                                                    <?= nl2br(htmlspecialchars($msg['mensagem'])) ?>
                                                </div>
                                            </div>
                                        </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                                
                                <!-- Formulário de Resposta -->
                                <?php if ($ticket['status'] !== 'fechado'): ?>
                                <div class="card">
                                    <div class="card-header bg-success text-white">
                                        <h6 class="mb-0">
                                            <i class="fas fa-reply me-2"></i>
                                            Responder ao Ticket
                                        </h6>
                                    </div>
                                    <div class="card-body">
                                        <form method="POST" action="admin_suporte.php?action=responder&id=<?= $ticket['id'] ?>">
                                            <div class="mb-3">
                                                <textarea class="form-control" name="mensagem" rows="4" 
                                                          placeholder="Digite sua resposta..." required></textarea>
                                            </div>
                                            <div class="text-end">
                                                <button type="submit" class="btn btn-success">
                                                    <i class="fas fa-paper-plane me-2"></i>
                                                    Enviar Resposta
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>
                        
                    <?php else: ?>
                        <!-- Filtros -->
                        <div class="card mb-4">
                            <div class="card-body">
                                <div class="d-flex flex-wrap gap-2">
                                    <a href="admin_suporte.php?status=todos" 
                                       class="btn btn-sm btn-outline-secondary <?= $status_filter === 'todos' ? 'active' : '' ?>">
                                        Todos (<?= count($tickets) ?>)
                                    </a>
                                    <a href="admin_suporte.php?status=aberto" 
                                       class="btn btn-sm btn-outline-warning <?= $status_filter === 'aberto' ? 'active' : '' ?>">
                                        Abertos (<?= count(array_filter($tickets, function($t) { return $t['status'] == 'aberto'; })) ?>)
                                    </a>
                                    <a href="admin_suporte.php?status=em_andamento" 
                                       class="btn btn-sm btn-outline-primary <?= $status_filter === 'em_andamento' ? 'active' : '' ?>">
                                        Em Andamento (<?= count(array_filter($tickets, function($t) { return $t['status'] == 'em_andamento'; })) ?>)
                                    </a>
                                    <a href="admin_suporte.php?status=respondido" 
                                       class="btn btn-sm btn-outline-info <?= $status_filter === 'respondido' ? 'active' : '' ?>">
                                        Respondidos (<?= count(array_filter($tickets, function($t) { return $t['status'] == 'respondido'; })) ?>)
                                    </a>
                                    <a href="admin_suporte.php?status=fechado" 
                                       class="btn btn-sm btn-outline-success <?= $status_filter === 'fechado' ? 'active' : '' ?>">
                                        Fechados (<?= count(array_filter($tickets, function($t) { return $t['status'] == 'fechado'; })) ?>)
                                    </a>
                                </div>
                            </div>
                        </div>

                        <!-- Lista de Tickets -->
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID</th>
                                                <th>Assunto</th>
                                                <th>Cliente</th>
                                                <th>Categoria</th>
                                                <th>Status</th>
                                                <th>Prioridade</th>
                                                <th>Responsável</th>
                                                <th>Data</th>
                                                <th>Mensagens</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if (empty($tickets)): ?>
                                                <tr>
                                                    <td colspan="10" class="text-center py-4 text-muted">
                                                        <i class="fas fa-ticket-alt fa-2x mb-3"></i><br>
                                                        Nenhum ticket encontrado.
                                                    </td>
                                                </tr>
                                            <?php else: ?>
                                                <?php foreach ($tickets as $ticket): ?>
                                                <?php
                                                    $row_class = '';
                                                    if ($ticket['prioridade'] === 'urgente') {
                                                        $row_class = 'ticket-urgente';
                                                    } elseif ($ticket['prioridade'] === 'alta') {
                                                        $row_class = 'ticket-alta';
                                                    }
                                                ?>
                                                <tr class="<?= $row_class ?>">
                                                    <td>#<?= $ticket['id'] ?></td>
                                                    <td>
                                                        <strong><?= htmlspecialchars($ticket['assunto']) ?></strong>
                                                        <br>
                                                        <small class="text-muted">
                                                            <?= truncateText($ticket['descricao'], 50) ?>
                                                        </small>
                                                    </td>
                                                    <td>
                                                        <?= htmlspecialchars($ticket['usuario_nome']) ?>
                                                        <br>
                                                        <small class="text-muted"><?= htmlspecialchars($ticket['usuario_email']) ?></small>
                                                    </td>
                                                    <td><?= ucfirst($ticket['categoria']) ?></td>
                                                    <td>
                                                        <span class="badge bg-<?= getStatusBadgeColor($ticket['status']) ?>">
                                                            <?= ucfirst($ticket['status']) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-<?= getPrioridadeBadgeColor($ticket['prioridade']) ?>">
                                                            <?= ucfirst($ticket['prioridade']) ?>
                                                        </span>
                                                    </td>
                                                    <td>
                                                        <?= $ticket['funcionario_nome'] ? htmlspecialchars($ticket['funcionario_nome']) : '<span class="text-muted">Não atribuído</span>' ?>
                                                    </td>
                                                    <td>
                                                        <?= date('d/m/Y', strtotime($ticket['data_abertura'])) ?>
                                                        <br>
                                                        <small class="text-muted"><?= date('H:i', strtotime($ticket['data_abertura'])) ?></small>
                                                    </td>
                                                    <td>
                                                        <span class="badge bg-secondary"><?= $ticket['total_mensagens'] ?></span>
                                                    </td>
                                                    <td>
                                                        <div class="btn-group btn-group-sm">
                                                            <a href="admin_suporte.php?action=view&id=<?= $ticket['id'] ?>" 
                                                               class="btn btn-outline-primary" title="Visualizar">
                                                                <i class="fas fa-eye"></i>
                                                            </a>
                                                        </div>
                                                    </td>
                                                </tr>
                                                <?php endforeach; ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                        <!-- Estatísticas -->
                        <div class="row mt-4">
                            <div class="col-md-3">
                                <div class="card text-white bg-warning">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Abertos</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($tickets, function($t) { return $t['status'] == 'aberto'; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-primary">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Em Andamento</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($tickets, function($t) { return $t['status'] == 'em_andamento'; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-info">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Respondidos</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($tickets, function($t) { return $t['status'] == 'respondido'; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="card text-white bg-success">
                                    <div class="card-body text-center">
                                        <h6 class="card-title">Fechados</h6>
                                        <p class="card-text h4">
                                            <?= count(array_filter($tickets, function($t) { return $t['status'] == 'fechado'; })) ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <!-- Rodapé Igual ao Indexx -->
    <?php include '../includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php
