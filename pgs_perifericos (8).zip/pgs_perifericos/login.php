<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/formularios.css">
</head>
<body>
    <!-- Import do Cabeçalho -->
    <?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-7">
                <div class="card login-card shadow">
                    <div class="card-header bg-primary text-white text-center py-4">
                        <h3 class="mb-0">
                            <i class="fas fa-sign-in-alt me-2"></i>
                            Fazer Login
                        </h3>
                        <p class="mb-0 mt-2">Acesse sua conta</p>
                    </div>
                    <div class="card-body p-4">
                        <!-- Informações sobre tipos de login -->
                        <div class="alert alert-info mb-4">
                            <div class="d-flex align-items-center">
                                <i class="fas fa-info-circle fa-2x me-3"></i>
                                <div>
                                    <h6 class="mb-1">Tipos de Acesso</h6>
                                    <p class="mb-0">Use o mesmo email cadastrado (pessoal para clientes / corporativo para funcionários)</p>
                                    <button type="button" class="btn btn-outline-info btn-sm mt-2" data-bs-toggle="modal" data-bs-target="#infoLoginModal">
                                        <i class="fas fa-question-circle me-1"></i>Saiba mais sobre os acessos
                                    </button>
                                </div>
                            </div>
                        </div>

                        <!-- Mensagens -->
                        <?php mostrarMensagem(); ?>

                        <form action="includes/processa_login.php" method="POST">
                            <!-- Email -->
                            <div class="mb-3">
                                <label for="email" class="form-label">
                                    <i class="fas fa-envelope me-1 text-primary"></i>
                                    E-mail
                                </label>
                                <input type="email" class="form-control form-control-lg" id="email" name="email" 
                                       placeholder="seu@email.com" required
                                       value="<?php echo $_POST['email'] ?? ''; ?>">
                                <div class="form-text">
                                    Use o email cadastrado (pessoal ou corporativo)
                                    <button type="button" class="btn btn-link btn-sm p-0 text-info" data-bs-toggle="modal" data-bs-target="#emailLoginModal">
                                        <i class="fas fa-question-circle me-1"></i>Dúvidas sobre email?
                                    </button>
                                </div>
                            </div>

                            <!-- Senha -->
                            <div class="mb-3">
                                <label for="senha" class="form-label">
                                    <i class="fas fa-lock me-1 text-primary"></i>
                                    Senha
                                </label>
                                <div class="input-group">
                                    <input type="password" class="form-control form-control-lg" id="senha" name="senha" 
                                           placeholder="Sua senha" required>
                                    <button type="button" class="btn btn-outline-secondary" onclick="togglePassword()">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>

                            <!-- Lembrar de mim e Esqueci senha -->
                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="lembrar" name="lembrar">
                                        <label class="form-check-label" for="lembrar">
                                            Lembrar de mim
                                        </label>
                                    </div>
                                </div>
                                <div class="col-md-6 text-end">
                                    <a href="#" class="text-decoration-none small" data-bs-toggle="modal" data-bs-target="#esqueciSenhaModal">
                                        <i class="fas fa-key me-1"></i>
                                        Esqueci minha senha
                                    </a>
                                </div>
                            </div>

                            <!-- Botão Entrar -->
                            <button type="submit" class="btn btn-primary btn-lg w-100 mb-3">
                                <i class="fas fa-sign-in-alt me-2"></i>
                                Entrar na Minha Conta
                            </button>

                            <!-- Divisor -->
                            <div class="position-relative my-4">
                                <hr>
                                <span class="position-absolute top-50 start-50 translate-middle bg-white px-3 text-muted">
                                    ou
                                </span>
                            </div>

                            <!-- Links de Cadastro -->
                            <div class="text-center">
                                <p class="text-muted mb-2">Ainda não tem uma conta?</p>
                                <div class="d-grid gap-2 d-md-block">
                                    <a href="cadastro.php?tipo=cliente" class="btn btn-outline-primary btn-lg me-md-2 mb-2">
                                        <i class="fas fa-user me-2"></i>
                                        Cadastrar como Cliente
                                    </a>
                                    <a href="cadastro.php?tipo=funcionario" class="btn btn-outline-success btn-lg mb-2">
                                        <i class="fas fa-user-tie me-2"></i>
                                        Cadastrar como Funcionário
                                    </a>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Cards Informativos -->
                <div class="row mt-4">
                    <div class="col-md-6">
                        <div class="card border-warning h-100">
                            <div class="card-body text-center">
                                <h6 class="text-warning mb-2">
                                    <i class="fas fa-user-tie me-1"></i>
                                    Área de Funcionários
                                </h6>
                                <p class="small text-muted mb-2">
                                    Funcionários e administradores, faça login com suas credenciais corporativas
                                </p>
                                <button type="button" class="btn btn-outline-warning btn-sm" data-bs-toggle="modal" data-bs-target="#infoFuncionarioModal">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Saiba mais
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="card border-info h-100">
                            <div class="card-body text-center">
                                <h6 class="text-info mb-2">
                                    <i class="fas fa-user me-1"></i>
                                    Área de Clientes
                                </h6>
                                <p class="small text-muted mb-2">
                                    Clientes, façam login com seu email pessoal para acessar histórico de pedidos e benefícios
                                </p>
                                <button type="button" class="btn btn-outline-info btn-sm" data-bs-toggle="modal" data-bs-target="#infoClienteModal">
                                    <i class="fas fa-info-circle me-1"></i>
                                    Saiba mais
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Lado Direito - Benefícios -->
            <div class="col-md-6 col-lg-5">
                <div class="card benefits-card h-100">
                    <div class="card-body p-4">
                        <h4 class="text-primary mb-4">
                            <i class="fas fa-star me-2"></i>
                            Benefícios de ter uma conta
                        </h4>
                        
                        <div class="benefit-item mb-3">
                            <div class="d-flex align-items-start">
                                <i class="fas fa-shopping-bag text-success me-3 mt-1"></i>
                                <div>
                                    <h6 class="mb-1">Histórico de Pedidos</h6>
                                    <p class="small text-muted mb-0">Acompanhe todos os seus pedidos em um só lugar</p>
                                </div>
                            </div>
                        </div>

                        <div class="benefit-item mb-3">
                            <div class="d-flex align-items-start">
                                <i class="fas fa-heart text-danger me-3 mt-1"></i>
                                <div>
                                    <h6 class="mb-1">Lista de Desejos</h6>
                                    <p class="small text-muted mb-0">Salve produtos para comprar depois</p>
                                </div>
                            </div>
                        </div>

                        <div class="benefit-item mb-3">
                            <div class="d-flex align-items-start">
                                <i class="fas fa-truck text-info me-3 mt-1"></i>
                                <div>
                                    <h6 class="mb-1">Endereços Salvos</h6>
                                    <p class="small text-muted mb-0">Agilize suas compras com endereços pré-cadastrados</p>
                                </div>
                            </div>
                        </div>

                        <div class="benefit-item mb-3">
                            <div class="d-flex align-items-start">
                                <i class="fas fa-gift text-warning me-3 mt-1"></i>
                                <div>
                                    <h6 class="mb-1">Ofertas Exclusivas</h6>
                                    <p class="small text-muted mb-0">Receba promoções especiais para clientes cadastrados</p>
                                </div>
                            </div>
                        </div>

                        <div class="benefit-item">
                            <div class="d-flex align-items-start">
                                <i class="fas fa-clock text-secondary me-3 mt-1"></i>
                                <div>
                                    <h6 class="mb-1">Checkout Rápido</h6>
                                    <p class="small text-muted mb-0">Finalize suas compras mais rapidamente</p>
                                </div>
                            </div>
                        </div>

                        <hr class="my-4">

                        <!-- Destaques -->
                        <div class="text-center">
                            <h6 class="text-muted mb-3">Nossa Comunidade</h6>
                            <div class="row">
                                <div class="col-4 text-center">
                                    <div class="stat-number text-primary">5.2k+</div>
                                    <small class="text-muted">Clientes</small>
                                </div>
                                <div class="col-4 text-center">
                                    <div class="stat-number text-success">12.7k+</div>
                                    <small class="text-muted">Pedidos</small>
                                </div>
                                <div class="col-4 text-center">
                                    <div class="stat-number text-warning">4.8</div>
                                    <small class="text-muted">Avaliação</small>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Import do Rodapé -->
    <?php include 'includes/rodape.php'; ?>

    <!-- Modal Informações sobre Login -->
    <div class="modal fade" id="infoLoginModal" tabindex="-1" aria-labelledby="infoLoginModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="infoLoginModalLabel">
                        <i class="fas fa-sign-in-alt me-2"></i>
                        Tipos de Acesso - PGS Periféricos
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="card border-primary h-100">
                                <div class="card-header bg-primary text-white">
                                    <h6 class="mb-0">
                                        <i class="fas fa-user me-2"></i>
                                        Acesso como Cliente
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <h6 class="text-primary">📧 Email:</h6>
                                    <p class="small">Use seu email pessoal cadastrado</p>
                                    
                                    <h6 class="text-primary">🎯 O que você acessa:</h6>
                                    <ul class="small">
                                        <li>Histórico de pedidos</li>
                                        <li>Lista de desejos</li>
                                        <li>Endereços salvos</li>
                                        <li>Ofertas exclusivas</li>
                                        <li>Avaliações de produtos</li>
                                    </ul>
                                    
                                    <h6 class="text-primary">💡 Dica:</h6>
                                    <p class="small">Use o mesmo email que cadastrou na hora da compra</p>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="card border-success h-100">
                                <div class="card-header bg-success text-white">
                                    <h6 class="mb-0">
                                        <i class="fas fa-user-tie me-2"></i>
                                        Acesso como Funcionário
                                    </h6>
                                </div>
                                <div class="card-body">
                                    <h6 class="text-success">📧 Email:</h6>
                                    <p class="small">Use seu email corporativo</p>
                                    
                                    <h6 class="text-success">🎯 O que você acessa:</h6>
                                    <ul class="small">
                                        <li>Painel administrativo</li>
                                        <li>Gestão de pedidos</li>
                                        <li>Controle de estoque</li>
                                        <li>Atendimento ao cliente</li>
                                        <li>Relatórios e analytics</li>
                                    </ul>
                                    
                                    <h6 class="text-success">🔒 Segurança:</h6>
                                    <p class="small">Acesso restrito à equipe PGS Periféricos</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Informações sobre Email -->
    <div class="modal fade" id="emailLoginModal" tabindex="-1" aria-labelledby="emailLoginModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-info text-white">
                    <h5 class="modal-title" id="emailLoginModalLabel">
                        <i class="fas fa-envelope me-2"></i>
                        Dúvidas sobre Email?
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-4">
                        <h6 class="text-primary">
                            <i class="fas fa-user me-1"></i>
                            Para Clientes:
                        </h6>
                        <p class="small">Use o email pessoal que você cadastrou:</p>
                        <div class="alert alert-light small">
                            <strong>Exemplos:</strong><br>
                            • joao.silva@gmail.com<br>
                            • maria123@hotmail.com<br>
                            • pedro.oliveira@outlook.com
                        </div>
                    </div>
                    
                    <div>
                        <h6 class="text-success">
                            <i class="fas fa-user-tie me-1"></i>
                            Para Funcionários:
                        </h6>
                        <p class="small">Use seu email corporativo @pgs.com:</p>
                        <div class="alert alert-light small">
                            <strong>Exemplos:</strong><br>
                            • carlos.souza@pgs.com<br>
                            • ana.rodrigues@pgs.com<br>
                            • lucas.oliveira@pgs.com
                        </div>
                    </div>
                    
                    <div class="alert alert-warning small mt-3">
                        <i class="fas fa-exclamation-triangle me-1"></i>
                        <strong>Problemas para acessar?</strong> Entre em contato com o suporte.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Esqueci Senha -->
    <div class="modal fade" id="esqueciSenhaModal" tabindex="-1" aria-labelledby="esqueciSenhaModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="esqueciSenhaModalLabel">
                        <i class="fas fa-key me-2"></i>
                        Recuperar Senha
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-3">Digite seu email para receber um link de recuperação de senha:</p>
                    
                    <div class="mb-3">
                        <label for="emailRecuperacao" class="form-label">Email</label>
                        <input type="email" class="form-control" id="emailRecuperacao" placeholder="seu@email.com">
                    </div>
                    
                    <div class="alert alert-info small">
                        <i class="fas fa-info-circle me-1"></i>
                        Enviaremos um email com instruções para redefinir sua senha.
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-warning">Enviar Link</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Informações Funcionário -->
    <div class="modal fade" id="infoFuncionarioModal" tabindex="-1" aria-labelledby="infoFuncionarioModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-warning text-dark">
                    <h5 class="modal-title" id="infoFuncionarioModalLabel">
                        <i class="fas fa-user-tie me-2"></i>
                        Acesso para Funcionários
                    </h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-warning">
                                <h6 class="alert-heading">
                                    <i class="fas fa-exclamation-circle me-2"></i>
                                    Informações Importantes
                                </h6>
                                <p class="mb-0">Para funcionários da PGS Periféricos, é obrigatório o uso do email corporativo.</p>
                            </div>
                            
                            <h6 class="text-warning mb-3">
                                <i class="fas fa-envelope me-2"></i>
                                Email Corporativo Obrigatório
                            </h6>
                            
                            <div class="mb-4">
                                <p><strong>✅ Use SEMPRE seu email @pgs.com:</strong></p>
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <code class="text-success">
                                            • joao.silva@pgs.com<br>
                                            • maria.oliveira@pgs.com<br>
                                            • carlos.santos@pgs.com<br>
                                            • ana.rodrigues@pgs.com
                                        </code>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <p><strong>❌ NÃO use emails pessoais:</strong></p>
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <code class="text-danger">
                                            • joao.silva@gmail.com<br>
                                            • maria123@hotmail.com<br>
                                            • carlos.santos@outlook.com
                                        </code>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card border-success h-100">
                                        <div class="card-header bg-success text-white">
                                            <h6 class="mb-0">
                                                <i class="fas fa-check-circle me-2"></i>
                                                O que você acessa
                                            </h6>
                                        </div>
                                        <div class="card-body">
                                            <ul class="small mb-0">
                                                <li>Painel administrativo</li>
                                                <li>Gestão de pedidos</li>
                                                <li>Controle de estoque</li>
                                                <li>Atendimento ao cliente</li>
                                                <li>Relatórios e analytics</li>
                                                <li>Cadastro de produtos</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card border-info h-100">
                                        <div class="card-header bg-info text-white">
                                            <h6 class="mb-0">
                                                <i class="fas fa-shield-alt me-2"></i>
                                                Segurança
                                            </h6>
                                        </div>
                                        <div class="card-body">
                                            <ul class="small mb-0">
                                                <li>Acesso restrito à equipe</li>
                                                <li>Email corporativo obrigatório</li>
                                                <li>Permissões por cargo</li>
                                                <li>Auditoria de acesso</li>
                                                <li>Dados protegidos</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="alert alert-info mt-4">
                                <h6 class="alert-heading">
                                    <i class="fas fa-question-circle me-2"></i>
                                    Precisa de ajuda?
                                </h6>
                                <p class="mb-0 small">
                                    Se você é funcionário e não tem acesso ao email corporativo, 
                                    entre em contato com o departamento de TI.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-warning" data-bs-dismiss="modal">
                        <i class="fas fa-check me-1"></i>
                        Entendi
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal Informações Cliente -->
    <div class="modal fade" id="infoClienteModal" tabindex="-1" aria-labelledby="infoClienteModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header bg-primary text-white">
                    <h5 class="modal-title" id="infoClienteModalLabel">
                        <i class="fas fa-user me-2"></i>
                        Acesso para Clientes
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="alert alert-primary">
                                <h6 class="alert-heading">
                                    <i class="fas fa-info-circle me-2"></i>
                                    Informações Importantes
                                </h6>
                                <p class="mb-0">Para clientes, use seu email pessoal. <strong>Não é permitido o uso de email @pgs.com</strong>.</p>
                            </div>
                            
                            <h6 class="text-primary mb-3">
                                <i class="fas fa-envelope me-2"></i>
                                Email Pessoal
                            </h6>
                            
                            <div class="mb-4">
                                <p><strong>✅ Use seu email pessoal preferido:</strong></p>
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <code class="text-success">
                                            • joao.silva@gmail.com<br>
                                            • maria.oliveira@hotmail.com<br>
                                            • carlos.santos@outlook.com<br>
                                            • ana.rodrigues@yahoo.com
                                        </code>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="mb-4">
                                <p><strong>❌ NÃO use emails @pgs.com:</strong></p>
                                <div class="card bg-light">
                                    <div class="card-body">
                                        <code class="text-danger">
                                            • qualquer.email@pgs.com<br>
                                            • nome.sobrenome@pgs.com
                                        </code>
                                    </div>
                                </div>
                                <p class="small text-muted mt-2">
                                    Emails @pgs.com são exclusivos para funcionários da empresa.
                                </p>
                            </div>
                            
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="card border-success h-100">
                                        <div class="card-header bg-success text-white">
                                            <h6 class="mb-0">
                                                <i class="fas fa-shopping-bag me-2"></i>
                                                Benefícios
                                            </h6>
                                        </div>
                                        <div class="card-body">
                                            <ul class="small mb-0">
                                                <li>Histórico de pedidos</li>
                                                <li>Lista de desejos</li>
                                                <li>Endereços salvos</li>
                                                <li>Ofertas exclusivas</li>
                                                <li>Avaliações de produtos</li>
                                                <li>Checkout rápido</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="card border-warning h-100">
                                        <div class="card-header bg-warning text-dark">
                                            <h6 class="mb-0">
                                                <i class="fas fa-gift me-2"></i>
                                                Vantagens
                                            </h6>
                                        </div>
                                        <div class="card-body">
                                            <ul class="small mb-0">
                                                <li>Promoções especiais</li>
                                                <li>Frete grátis</li>
                                                <li>Cashback</li>
                                                <li>Programa de fidelidade</li>
                                                <li>Atendimento prioritário</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                            <div class="alert alert-warning mt-4">
                                <h6 class="alert-heading">
                                    <i class="fas fa-lightbulb me-2"></i>
                                    Dica Importante
                                </h6>
                                <p class="mb-0 small">
                                    Use o mesmo email em todas as suas compras para acumular benefícios 
                                    e ter todo seu histórico em um só lugar.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" data-bs-dismiss="modal">
                        <i class="fas fa-check me-1"></i>
                        Entendi
                    </button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function togglePassword() {
            const passwordInput = document.getElementById('senha');
            const eyeIcon = document.querySelector('#senha + .btn i');
            
            if (passwordInput.type === 'password') {
                passwordInput.type = 'text';
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                passwordInput.type = 'password';
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        }

        // Preencher email se veio por parâmetro
        document.addEventListener('DOMContentLoaded', function() {
            const urlParams = new URLSearchParams(window.location.search);
            const email = urlParams.get('email');
            if (email) {
                document.getElementById('email').value = email;
            }
        });
    </script>
</body>
</html>