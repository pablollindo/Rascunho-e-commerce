<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';

// Verificar se usuário está logado
if (!usuarioEstaLogado()) {
    $_SESSION['erro'] = "Você precisa estar logado para editar seus dados.";
    redirecionar('login.php');
}

$usuario_id = $_SESSION['usuario_id'];
$usuario_tipo = $_SESSION['usuario_tipo'];

// Buscar dados atuais do usuário
$usuario = [];
$dados_funcionario = [];

try {
    // Buscar dados básicos do usuário
    if ($usuario_tipo === 'cliente') {
        $sql_usuario = "SELECT u.*, c.cpf, c.telefone, c.data_nascimento 
                        FROM usuarios u 
                        LEFT JOIN clientes c ON u.id = c.usuario_id 
                        WHERE u.id = ?";
    } else {
        $sql_usuario = "SELECT u.*, f.cpf, f.telefone, f.data_nascimento 
                        FROM usuarios u 
                        LEFT JOIN funcionarios f ON u.id = f.usuario_id 
                        WHERE u.id = ?";
    }
    
    $stmt = $conn->prepare($sql_usuario);
    $stmt->bind_param("i", $usuario_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    // Se for funcionário, buscar dados profissionais
    if ($usuario_tipo === 'funcionario' || $usuario_tipo === 'admin') {
        $sql_funcionario = "SELECT * FROM funcionarios WHERE usuario_id = ?";
        $stmt = $conn->prepare($sql_funcionario);
        $stmt->bind_param("i", $usuario_id);
        $stmt->execute();
        $result = $stmt->get_result();
        $dados_funcionario = $result->fetch_assoc();
    }

} catch (Exception $e) {
    $_SESSION['erro'] = "Erro ao carregar dados: " . $e->getMessage();
}

// Processar atualização dos dados
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['atualizar_dados'])) {
    $nome = sanitizar($_POST['nome'] ?? '');
    $telefone = sanitizar($_POST['telefone'] ?? '');
    $data_nascimento = $_POST['data_nascimento'] ?? '';

    // Validar dados
    if (empty($nome)) {
        $_SESSION['erro'] = "O nome é obrigatório.";
    } else {
        try {
            $conn->begin_transaction();
            
            // Atualizar tabela usuarios
            $sql_usuario = "UPDATE usuarios SET nome = ?, telefone = ?, data_nascimento = ? WHERE id = ?";
            $stmt = $conn->prepare($sql_usuario);
            $telefone_formatado = !empty($telefone) ? preg_replace('/[^0-9]/', '', $telefone) : null;
            $data_nascimento_formatada = !empty($data_nascimento) ? $data_nascimento : null;
            
            $stmt->bind_param("sssi", $nome, $telefone_formatado, $data_nascimento_formatada, $usuario_id);
            $stmt->execute();
            
            // Atualizar tabela específica (clientes ou funcionarios)
            if ($usuario_tipo === 'cliente') {
                $sql_cliente = "UPDATE clientes SET nome = ?, telefone = ?, data_nascimento = ? WHERE usuario_id = ?";
                $stmt = $conn->prepare($sql_cliente);
                $stmt->bind_param("sssi", $nome, $telefone_formatado, $data_nascimento_formatada, $usuario_id);
                $stmt->execute();
            } else {
                // Para funcionários, só atualiza dados pessoais
                $sql_funcionario = "UPDATE funcionarios SET nome = ?, telefone = ?, data_nascimento = ? WHERE usuario_id = ?";
                $stmt = $conn->prepare($sql_funcionario);
                $stmt->bind_param("sssi", $nome, $telefone_formatado, $data_nascimento_formatada, $usuario_id);
                $stmt->execute();
            }
            
            $conn->commit();
            
            // Atualizar nome na sessão
            $_SESSION['usuario_nome'] = $nome;
            $_SESSION['sucesso'] = "Dados atualizados com sucesso!";
            
            // Recarregar a página para mostrar dados atualizados
            redirecionar('editar_dados.php');
            
        } catch (Exception $e) {
            $conn->rollback();
            $_SESSION['erro'] = "Erro ao atualizar dados: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Dados - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
    <link rel="stylesheet" href="assets/css/formularios.css">
    <style>
        .card {
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .card-header {
            border-bottom: 2px solid #dee2e6;
        }
        .btn-primary {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            border: none;
        }
        .btn-primary:hover {
            background: linear-gradient(135deg, #764ba2 0%, #667eea 100%);
        }
    </style>
</head>
<body>
    <?php include 'includes/cabecalho.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row justify-content-center">
            <div class="col-md-8 col-lg-6">
                <div class="card">
                    <div class="card-header bg-primary text-white">
                        <div class="d-flex justify-content-between align-items-center">
                            <h4 class="mb-0">
                                <i class="fas fa-user-edit me-2"></i>
                                Editar Dados Pessoais
                            </h4>
                            <a href="minha_conta.php" class="btn btn-light btn-sm">
                                <i class="fas fa-arrow-left me-1"></i>Voltar
                            </a>
                        </div>
                    </div>
                    <div class="card-body p-4">
                        <!-- Mensagens -->
                        <?php mostrarMensagem(); ?>

                        <form method="POST" action="">
                            <!-- Dados Pessoais -->
                            <div class="mb-4">
                                <h5 class="border-bottom pb-2 mb-4">
                                    <i class="fas fa-user me-2 text-primary"></i>
                                    Dados Pessoais
                                </h5>
                                
                                <div class="row">
                                    <div class="col-md-12 mb-3">
                                        <label for="nome" class="form-label">
                                            <i class="fas fa-user me-1"></i>Nome Completo *
                                        </label>
                                        <input type="text" class="form-control" id="nome" name="nome" 
                                               value="<?php echo htmlspecialchars($usuario['nome'] ?? ''); ?>" required
                                               placeholder="Digite seu nome completo"
                                               maxlength="100">
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="email" class="form-label">
                                            <i class="fas fa-envelope me-1"></i>Email
                                        </label>
                                        <input type="email" class="form-control" id="email" 
                                               value="<?php echo htmlspecialchars($usuario['email'] ?? ''); ?>" 
                                               readonly disabled>
                                        <small class="form-text text-muted">O email não pode ser alterado.</small>
                                    </div>
                                    
                                    <div class="col-md-6 mb-3">
                                        <label for="telefone" class="form-label">
                                            <i class="fas fa-phone me-1"></i>Telefone *
                                        </label>
                                        <input type="text" class="form-control" id="telefone" name="telefone" 
                                               value="<?php echo htmlspecialchars($usuario['telefone'] ?? ''); ?>" 
                                               placeholder="(11) 99999-9999" required
                                               maxlength="15"
                                               oninput="formatarTelefone(this)">
                                        <small class="form-text text-muted">Máximo 15 dígitos</small>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="data_nascimento" class="form-label">
                                            <i class="fas fa-calendar me-1"></i>Data de Nascimento *
                                        </label>
                                        <input type="date" class="form-control" id="data_nascimento" name="data_nascimento" 
                                               value="<?php echo !empty($usuario['data_nascimento']) && $usuario['data_nascimento'] != '0000-00-00' ? $usuario['data_nascimento'] : ''; ?>" required>
                                    </div>
                                    
                                    <?php if ($usuario_tipo === 'cliente'): ?>
                                    <div class="col-md-6 mb-3">
                                        <label for="cpf" class="form-label">
                                            <i class="fas fa-id-card me-1"></i>CPF
                                        </label>
                                        <input type="text" class="form-control" id="cpf" 
                                               value="<?php echo htmlspecialchars($usuario['cpf'] ?? ''); ?>" 
                                               readonly disabled>
                                        <small class="form-text text-muted">O CPF não pode ser alterado.</small>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <!-- Dados Profissionais (Apenas visualização para funcionários) -->
                            <?php if ($usuario_tipo === 'funcionario' || $usuario_tipo === 'admin'): ?>
                            <div class="mb-4">
                                <h5 class="border-bottom pb-2 mb-4">
                                    <i class="fas fa-briefcase me-2 text-success"></i>
                                    Dados Profissionais
                                </h5>
                                
                                <div class="alert alert-info">
                                    <i class="fas fa-info-circle me-2"></i>
                                    Os dados profissionais não podem ser alterados por você. 
                                    Contate o administrador do sistema para alterações.
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Cargo</label>
                                        <p class="form-control-plaintext bg-light p-2 rounded">
                                            <?php echo !empty($dados_funcionario['cargo']) ? ucfirst($dados_funcionario['cargo']) : 'Não informado'; ?>
                                        </p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Departamento</label>
                                        <p class="form-control-plaintext bg-light p-2 rounded">
                                            <?php echo !empty($dados_funcionario['departamento']) ? ucfirst($dados_funcionario['departamento']) : 'Não informado'; ?>
                                        </p>
                                    </div>
                                </div>
                                
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Data de Admissão</label>
                                        <p class="form-control-plaintext bg-light p-2 rounded">
                                            <?php 
                                            if (!empty($dados_funcionario['data_admissao']) && $dados_funcionario['data_admissao'] != '0000-00-00') {
                                                echo date('d/m/Y', strtotime($dados_funcionario['data_admissao']));
                                            } else {
                                                echo 'Não informado';
                                            }
                                            ?>
                                        </p>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label class="form-label fw-bold">Matrícula</label>
                                        <p class="form-control-plaintext bg-light p-2 rounded">
                                            <?php 
                                            if (!empty($dados_funcionario['matricula'])) {
                                                echo htmlspecialchars($dados_funcionario['matricula']);
                                            } else {
                                                echo 'Não informada';
                                            }
                                            ?>
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <!-- Botões -->
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <a href="minha_conta.php" class="btn btn-secondary me-md-2">
                                    <i class="fas fa-times me-2"></i>Cancelar
                                </a>
                                <button type="submit" name="atualizar_dados" class="btn btn-primary">
                                    <i class="fas fa-save me-2"></i>Salvar Alterações
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    
    <script>
        // Formatação do telefone
        function formatarTelefone(input) {
            let value = input.value.replace(/\D/g, '');
            if (value.length > 11) value = value.substring(0, 11);
            
            if (value.length > 10) {
                value = value.replace(/(\d{2})(\d{5})(\d{4})/, '($1) $2-$3');
            } else if (value.length > 6) {
                value = value.replace(/(\d{2})(\d{4})(\d{0,4})/, '($1) $2-$3');
            } else if (value.length > 2) {
                value = value.replace(/(\d{2})(\d{0,5})/, '($1) $2');
            } else if (value.length > 0) {
                value = value.replace(/(\d{0,2})/, '($1');
            }
            
            input.value = value;
        }

        // Inicializar formatação do telefone
        document.addEventListener('DOMContentLoaded', function() {
            const telefoneInput = document.getElementById('telefone');
            if (telefoneInput) {
                formatarTelefone(telefoneInput);
            }
        });

        // Validação do formulário
        document.querySelector('form').addEventListener('submit', function(e) {
            const nome = document.getElementById('nome').value.trim();
            const telefone = document.getElementById('telefone').value.trim();
            
            if (!nome) {
                e.preventDefault();
                alert('Por favor, preencha o nome completo.');
                document.getElementById('nome').focus();
                return;
            }
            
            if (!telefone) {
                e.preventDefault();
                alert('Por favor, preencha o telefone.');
                document.getElementById('telefone').focus();
                return;
            }
            
            // Validar formato do telefone (mínimo 10 dígitos)
            const telefoneNumeros = telefone.replace(/\D/g, '');
            if (telefoneNumeros.length < 10) {
                e.preventDefault();
                alert('Por favor, insira um telefone válido com DDD + número.');
                document.getElementById('telefone').focus();
                return;
            }
        });
    </script>
</body>
</html>