<?php
require_once 'includes/config.php';
require_once 'includes/funcoes.php';
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>FAQ - PGS Periféricos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link rel="stylesheet" href="assets/css/estilo.css">
</head>
<body>
    <!-- Header e Navbar Únicos -->
    <?php include 'includes/cabecalho_simples.php'; ?>

    <!-- Conteúdo Principal -->
    <main class="container my-5">
        <div class="row">
            <div class="col-12">
                <!-- Cabeçalho FAQ -->
                <div class="text-center mb-5">
                    <h1 class="display-5 fw-bold text-primary mb-3">
                        <i class="fas fa-question-circle me-3"></i>
                        Perguntas Frequentes
                    </h1>
                    <p class="lead text-muted">
                        Encontre respostas para as dúvidas mais comuns sobre nossa loja
                    </p>
                    
                    <!-- Barra de Pesquisa FAQ -->
                    <div class="row justify-content-center">
                        <div class="col-md-8">
                            <div class="input-group input-group-lg mb-4">
                                <input type="text" class="form-control" id="searchFAQ" placeholder="Buscar na FAQ...">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Navegação por Categorias -->
                <div class="row mb-5">
                    <div class="col-12">
                        <div class="d-flex flex-wrap gap-2 justify-content-center">
                            <button class="btn btn-outline-primary active" data-category="all">
                                <i class="fas fa-th-large me-2"></i>Todas
                            </button>
                            <button class="btn btn-outline-primary" data-category="conta">
                                <i class="fas fa-user me-2"></i>Minha Conta
                            </button>
                            <button class="btn btn-outline-primary" data-category="pedidos">
                                <i class="fas fa-shopping-bag me-2"></i>Pedidos
                            </button>
                            <button class="btn btn-outline-primary" data-category="pagamento">
                                <i class="fas fa-credit-card me-2"></i>Pagamento
                            </button>
                            <button class="btn btn-outline-primary" data-category="entrega">
                                <i class="fas fa-truck me-2"></i>Entrega
                            </button>
                            <button class="btn btn-outline-primary" data-category="produtos">
                                <i class="fas fa-box me-2"></i>Produtos
                            </button>
                            <button class="btn btn-outline-primary" data-category="garantia">
                                <i class="fas fa-shield-alt me-2"></i>Garantia
                            </button>
                        </div>
                    </div>
                </div>

                <!-- Lista de Perguntas -->
                <div class="row">
                    <div class="col-12">
                        <!-- Seção: Minha Conta -->
                        <div class="faq-section mb-5" data-category="conta">
                            <h3 class="border-bottom pb-2 mb-4">
                                <i class="fas fa-user text-primary me-2"></i>
                                Minha Conta
                            </h3>
                            
                            <div class="accordion" id="accordionConta">
                                <!-- Pergunta 1 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#conta1">
                                            <i class="fas fa-question-circle text-primary me-2"></i>
                                            Como criar uma conta na PGS Periféricos?
                                        </button>
                                    </h2>
                                    <div id="conta1" class="accordion-collapse collapse show" data-bs-parent="#accordionConta">
                                        <div class="accordion-body">
                                            <p>Para criar uma conta:</p>
                                            <ol>
                                                <li>Clique em "Cadastrar" no menu superior</li>
                                                <li>Escolha entre "Cadastrar como Cliente" ou "Cadastrar como Funcionário"</li>
                                                <li>Preencha seus dados pessoais</li>
                                                <li>Confirme seu email</li>
                                                <li>Pronto! Sua conta estará ativa</li>
                                            </ol>
                                            <p class="text-muted small">
                                                <i class="fas fa-info-circle me-1"></i>
                                                Clientes usam email pessoal, funcionários usam email @pgs.com
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 2 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#conta2">
                                            <i class="fas fa-question-circle text-primary me-2"></i>
                                            Esqueci minha senha, o que fazer?
                                        </button>
                                    </h2>
                                    <div id="conta2" class="accordion-collapse collapse" data-bs-parent="#accordionConta">
                                        <div class="accordion-body">
                                            <p>Para recuperar sua senha:</p>
                                            <ol>
                                                <li>Vá para a página de login</li>
                                                <li>Clique em "Esqueci minha senha"</li>
                                                <li>Digite o email da sua conta</li>
                                                <li>Verifique sua caixa de entrada</li>
                                                <li>Siga as instruções do email recebido</li>
                                            </ol>
                                            <div class="alert alert-info mt-3">
                                                <i class="fas fa-clock me-2"></i>
                                                O link de recuperação expira em 24 horas por segurança.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 3 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#conta3">
                                            <i class="fas fa-question-circle text-primary me-2"></i>
                                            Como alterar meus dados cadastrais?
                                        </button>
                                    </h2>
                                    <div id="conta3" class="accordion-collapse collapse" data-bs-parent="#accordionConta">
                                        <div class="accordion-body">
                                            <p>Para alterar seus dados:</p>
                                            <ol>
                                                <li>Faça login em sua conta</li>
                                                <li>Clique em "Minha Conta" no menu</li>
                                                <li>Vá para "Dados Pessoais"</li>
                                                <li>Edite as informações desejadas</li>
                                                <li>Clique em "Salvar Alterações"</li>
                                            </ol>
                                            <p class="text-muted small">
                                                <i class="fas fa-exclamation-triangle me-1"></i>
                                                Alguns dados como CPF não podem ser alterados por segurança.
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Seção: Pedidos -->
                        <div class="faq-section mb-5" data-category="pedidos">
                            <h3 class="border-bottom pb-2 mb-4">
                                <i class="fas fa-shopping-bag text-success me-2"></i>
                                Pedidos
                            </h3>
                            
                            <div class="accordion" id="accordionPedidos">
                                <!-- Pergunta 1 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#pedidos1">
                                            <i class="fas fa-question-circle text-success me-2"></i>
                                            Como faço um pedido?
                                        </button>
                                    </h2>
                                    <div id="pedidos1" class="accordion-collapse collapse show" data-bs-parent="#accordionPedidos">
                                        <div class="accordion-body">
                                            <p>Fazer um pedido é simples:</p>
                                            <ol>
                                                <li>Navegue pelos produtos e adicione ao carrinho</li>
                                                <li>Clique no ícone do carrinho</li>
                                                <li>Revise os itens e quantidades</li>
                                                <li>Clique em "Finalizar Compra"</li>
                                                <li>Escolha a forma de pagamento</li>
                                                <li>Confirme o pedido</li>
                                            </ol>
                                            <p class="text-muted small">
                                                <i class="fas fa-lightbulb me-1"></i>
                                                Você pode comprar sem cadastro, mas ter uma conta oferece benefícios!
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 2 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#pedidos2">
                                            <i class="fas fa-question-circle text-success me-2"></i>
                                            Como acompanhar meu pedido?
                                        </button>
                                    </h2>
                                    <div id="pedidos2" class="accordion-collapse collapse" data-bs-parent="#accordionPedidos">
                                        <div class="accordion-body">
                                            <p>Para acompanhar seu pedido:</p>
                                            <ul>
                                                <li><strong>Clientes cadastrados:</strong> Acesse "Meus Pedidos" em sua conta</li>
                                                <li><strong>Compra sem cadastro:</strong> Use o código de rastreamento enviado por email</li>
                                                <li><strong>App:</strong> Baixe nosso aplicativo para acompanhamento em tempo real</li>
                                            </ul>
                                            <div class="alert alert-warning mt-3">
                                                <i class="fas fa-clock me-2"></i>
                                                O status do pedido é atualizado automaticamente.
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 3 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#pedidos3">
                                            <i class="fas fa-question-circle text-success me-2"></i>
                                            Posso cancelar um pedido?
                                        </button>
                                    </h2>
                                    <div id="pedidos3" class="accordion-collapse collapse" data-bs-parent="#accordionPedidos">
                                        <div class="accordion-body">
                                            <p>Sim, é possível cancelar um pedido seguindo estas regras:</p>
                                            <ul>
                                                <li><strong>Antes do processamento:</strong> Cancelamento imediato</li>
                                                <li><strong>Durante o processamento:</strong> Cancelamento sujeito à análise</li>
                                                <li><strong>Após envio:</strong> Não é possível cancelar</li>
                                            </ul>
                                            <p>Para cancelar:</p>
                                            <ol>
                                                <li>Acesse "Meus Pedidos"</li>
                                                <li>Localize o pedido desejado</li>
                                                <li>Clique em "Cancelar Pedido"</li>
                                                <li>Informe o motivo do cancelamento</li>
                                            </ol>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Seção: Pagamento -->
                        <div class="faq-section mb-5" data-category="pagamento">
                            <h3 class="border-bottom pb-2 mb-4">
                                <i class="fas fa-credit-card text-warning me-2"></i>
                                Pagamento
                            </h3>
                            
                            <div class="accordion" id="accordionPagamento">
                                <!-- Pergunta 1 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#pagamento1">
                                            <i class="fas fa-question-circle text-warning me-2"></i>
                                            Quais formas de pagamento são aceitas?
                                        </button>
                                    </h2>
                                    <div id="pagamento1" class="accordion-collapse collapse show" data-bs-parent="#accordionPagamento">
                                        <div class="accordion-body">
                                            <p>Aceitamos as seguintes formas de pagamento:</p>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <h6>Cartões de Crédito:</h6>
                                                    <ul>
                                                        <li>Visa</li>
                                                        <li>Mastercard</li>
                                                        <li>American Express</li>
                                                        <li>Elo</li>
                                                        <li>Hipercard</li>
                                                    </ul>
                                                </div>
                                                <div class="col-md-6">
                                                    <h6>Outras Formas:</h6>
                                                    <ul>
                                                        <li>PIX (5% de desconto)</li>
                                                        <li>Boleto Bancário</li>
                                                        <li>Cartão de Débito</li>
                                                        <li>Duas formas de pagamento</li>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 2 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#pagamento2">
                                            <i class="fas fa-question-circle text-warning me-2"></i>
                                            O pagamento é seguro?
                                        </button>
                                    </h2>
                                    <div id="pagamento2" class="accordion-collapse collapse" data-bs-parent="#accordionPagamento">
                                        <div class="accordion-body">
                                            <p>Sim, sua segurança é nossa prioridade:</p>
                                            <ul>
                                                <li><strong>Criptografia SSL:</strong> Todos os dados são criptografados</li>
                                                <li><strong>Anti-fraude:</strong> Sistema de análise de transações em tempo real</li>
                                                <li><strong>Certificado:</strong> Site verificado e seguro</li>
                                                <li><strong>Privacidade:</strong> Não armazenamos dados sensíveis do cartão</li>
                                            </ul>
                                            <div class="alert alert-success mt-3">
                                                <i class="fas fa-shield-alt me-2"></i>
                                                Nossa loja possui certificado de segurança e é 100% segura para compras.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Seção: Entrega -->
                        <div class="faq-section mb-5" data-category="entrega">
                            <h3 class="border-bottom pb-2 mb-4">
                                <i class="fas fa-truck text-info me-2"></i>
                                Entrega
                            </h3>
                            
                            <div class="accordion" id="accordionEntrega">
                                <!-- Pergunta 1 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#entrega1">
                                            <i class="fas fa-question-circle text-info me-2"></i>
                                            Qual o prazo de entrega?
                                        </button>
                                    </h2>
                                    <div id="entrega1" class="accordion-collapse collapse show" data-bs-parent="#accordionEntrega">
                                        <div class="accordion-body">
                                            <p>Os prazos de entrega variam conforme a região:</p>
                                            <ul>
                                                <li><strong>Capitais:</strong> 3 a 5 dias úteis</li>
                                                <li><strong>Interior:</strong> 5 a 10 dias úteis</li>
                                                <li><strong>Áreas remotas:</strong> 10 a 15 dias úteis</li>
                                            </ul>
                                            <p class="text-muted small">
                                                <i class="fas fa-clock me-1"></i>
                                                O prazo começa a contar após a confirmação do pagamento.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 2 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#entrega2">
                                            <i class="fas fa-question-circle text-info me-2"></i>
                                            Tem frete grátis?
                                        </button>
                                    </h2>
                                    <div id="entrega2" class="accordion-collapse collapse" data-bs-parent="#accordionEntrega">
                                        <div class="accordion-body">
                                            <p>Sim! Oferecemos frete grátis nas seguintes condições:</p>
                                            <ul>
                                                <li>Compras acima de R$ 299,90 para todo Brasil</li>
                                                <li>Clientes Prime (assinatura mensal)</li>
                                                <li>Promoções especiais</li>
                                            </ul>
                                            <div class="alert alert-info mt-3">
                                                <i class="fas fa-shipping-fast me-2"></i>
                                                O valor do frete é calculado automaticamente no carrinho.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Seção: Produtos -->
                        <div class="faq-section mb-5" data-category="produtos">
                            <h3 class="border-bottom pb-2 mb-4">
                                <i class="fas fa-box text-secondary me-2"></i>
                                Produtos
                            </h3>
                            
                            <div class="accordion" id="accordionProdutos">
                                <!-- Pergunta 1 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#produtos1">
                                            <i class="fas fa-question-circle text-secondary me-2"></i>
                                            Os produtos têm garantia?
                                        </button>
                                    </h2>
                                    <div id="produtos1" class="accordion-collapse collapse show" data-bs-parent="#accordionProdutos">
                                        <div class="accordion-body">
                                            <p>Sim, todos os produtos possuem garantia:</p>
                                            <ul>
                                                <li><strong>Garantia do Fabricante:</strong> 12 meses (padrão)</li>
                                                <li><strong>Garantia Estendida:</strong> Disponível para alguns produtos</li>
                                                <li><strong>Garantia Legal:</strong> 90 dias para vícios ocultos</li>
                                            </ul>
                                            <p class="text-muted small">
                                                <i class="fas fa-file-contract me-1"></i>
                                                A nota fiscal é necessária para acionar a garantia.
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- Pergunta 2 -->
                                <div class="accordion-item">
                                    <h2 class="accordion-header">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#produtos2">
                                            <i class="fas fa-question-circle text-secondary me-2"></i>
                                            Como funciona a troca de produtos?
                                        </button>
                                    </h2>
                                    <div id="produtos2" class="accordion-collapse collapse" data-bs-parent="#accordionProdutos">
                                        <div class="accordion-body">
                                            <p>Política de troca:</p>
                                            <ul>
                                                <li><strong>Prazo:</strong> 30 dias após o recebimento</li>
                                                <li><strong>Condição:</strong> Produto deve estar lacrado e com etiquetas</li>
                                                <li><strong>Custo:</strong> Frete por nossa conta</li>
                                                <li><strong>Processo:</strong> Entre em contato com nosso suporte</li>
                                            </ul>
                                            <div class="alert alert-warning mt-3">
                                                <i class="fas fa-exclamation-triangle me-2"></i>
                                                Produtos personalizados ou com selo de lacre rompido não podem ser trocados.
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Ainda com Dúvidas -->
                        <div class="card bg-light border-0">
                            <div class="card-body text-center py-5">
                                <h4 class="text-primary mb-3">
                                    <i class="fas fa-headset me-2"></i>
                                    Ainda com dúvidas?
                                </h4>
                                <p class="text-muted mb-4">
                                    Nossa equipe de suporte está pronta para ajudar você
                                </p>
                                <div class="d-flex flex-wrap gap-3 justify-content-center">
                                    <a href="suporte.php" class="btn btn-primary btn-lg">
                                        <i class="fas fa-envelope me-2"></i>
                                        Abrir ticket
                                    </a>
                                    <a href="tel:+5511999999999" class="btn btn-outline-primary btn-lg">
                                        <i class="fas fa-phone me-2"></i>
                                        (11) 99999-9999
                                    </a>
                                    <button class="btn btn-outline-secondary btn-lg" onclick="window.open('https://wa.me/5511999999999', '_blank')">
                                        <i class="fab fa-whatsapp me-2"></i>
                                        WhatsApp
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <!-- Footer -->
    <?php include 'includes/rodape.php'; ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Filtro por categoria
        document.addEventListener('DOMContentLoaded', function() {
            const categoryButtons = document.querySelectorAll('[data-category]');
            const faqSections = document.querySelectorAll('.faq-section');
            const searchInput = document.getElementById('searchFAQ');

            // Filtro por categoria
            categoryButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const category = this.getAttribute('data-category');
                    
                    // Atualizar botão ativo
                    categoryButtons.forEach(btn => btn.classList.remove('active'));
                    this.classList.add('active');
                    
                    // Mostrar/ocultar seções
                    faqSections.forEach(section => {
                        if (category === 'all' || section.getAttribute('data-category') === category) {
                            section.style.display = 'block';
                        } else {
                            section.style.display = 'none';
                        }
                    });
                });
            });

            // Busca em tempo real
            searchInput.addEventListener('input', function() {
                const searchTerm = this.value.toLowerCase();
                
                faqSections.forEach(section => {
                    const questions = section.querySelectorAll('.accordion-button');
                    let sectionHasMatch = false;
                    
                    questions.forEach(question => {
                        const questionText = question.textContent.toLowerCase();
                        if (questionText.includes(searchTerm)) {
                            question.closest('.accordion-item').style.display = 'block';
                            sectionHasMatch = true;
                            
                            // Abrir a pergunta se houver match
                            const collapseId = question.getAttribute('data-bs-target');
                            const collapseElement = document.querySelector(collapseId);
                            new bootstrap.Collapse(collapseElement, { toggle: false }).show();
                        } else {
                            question.closest('.accordion-item').style.display = 'none';
                        }
                    });
                    
                    // Mostrar/ocultar seção baseado nos resultados
                    section.style.display = sectionHasMatch ? 'block' : 'none';
                });
            });

            // Abrir primeira pergunta de cada seção
            faqSections.forEach(section => {
                const firstQuestion = section.querySelector('.accordion-button');
                if (firstQuestion) {
                    const collapseId = firstQuestion.getAttribute('data-bs-target');
                    const collapseElement = document.querySelector(collapseId);
                    new bootstrap.Collapse(collapseElement, { toggle: false }).show();
                }
            });
        });
    </script>
</body>
</html>