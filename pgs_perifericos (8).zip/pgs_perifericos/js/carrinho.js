// Sistema de Gerenciamento do Carrinho
class CarrinhoManager {
    constructor() {
        this.processing = false; // Flag para evitar múltiplos cliques
        this.init();
    }

    init() {
        this.bindEvents();
    }

    bindEvents() {
        // Botões de quantidade - usando delegação de eventos
        document.addEventListener('click', (e) => {
            if (e.target.closest('.quantity-btn') && !this.processing) {
                this.alterarQuantidade(e);
            }
        });

        // Input de quantidade
        document.addEventListener('change', (e) => {
            if (e.target.classList.contains('quantity-input') && !this.processing) {
                this.atualizarQuantidade(e.target);
            }
        });

        // Remover item
        document.addEventListener('click', (e) => {
            if (e.target.closest('.remove-item') && !this.processing) {
                this.removerItem(e);
            }
        });
    }

    async alterarQuantidade(e) {
        e.preventDefault();
        
        // Prevenir múltiplos cliques
        if (this.processing) return;
        this.processing = true;

        const btn = e.target.closest('.quantity-btn');
        const isIncrease = btn.classList.contains('increase');
        const productId = btn.dataset.productId;
        const input = btn.closest('.quantity-controls').querySelector('.quantity-input');
        
        let quantity = parseInt(input.value);

        if (isIncrease) {
            quantity++;
        } else {
            quantity = Math.max(1, quantity - 1);
        }

        input.value = quantity;
        
        try {
            await this.atualizarQuantidadeNoServidor(productId, quantity);
        } finally {
            // Liberar para próximo clique após um pequeno delay
            setTimeout(() => {
                this.processing = false;
            }, 300);
        }
    }

    async atualizarQuantidade(input) {
        if (this.processing) return;
        this.processing = true;

        const productId = input.dataset.productId;
        const quantity = parseInt(input.value);
        
        if (quantity < 1) {
            input.value = 1;
            this.processing = false;
            return;
        }

        try {
            await this.atualizarQuantidadeNoServidor(productId, quantity);
        } finally {
            setTimeout(() => {
                this.processing = false;
            }, 300);
        }
    }

    async atualizarQuantidadeNoServidor(productId, quantity) {
        try {
            const response = await this.fazerRequisicao('update', productId, quantity);
            
            if (response.success) {
                this.mostrarMensagem('success', response.message);
                // Atualizar a página após um breve delay para mostrar a mensagem
                setTimeout(() => {
                    window.location.reload();
                }, 800);
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.mostrarMensagem('error', error.message);
            // Recarregar a página em caso de erro
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        }
    }

    async removerItem(e) {
        e.preventDefault();
        
        if (this.processing) return;
        this.processing = true;

        const btn = e.target.closest('.remove-item');
        const productId = btn.dataset.productId;
        const productName = btn.dataset.productName;

        if (!confirm(`Deseja remover "${productName}" do carrinho?`)) {
            this.processing = false;
            return;
        }

        try {
            const response = await this.fazerRequisicao('remove', productId);
            
            if (response.success) {
                this.mostrarMensagem('success', response.message);
                // Recarregar a página após remoção
                setTimeout(() => {
                    window.location.reload();
                }, 800);
            } else {
                throw new Error(response.message);
            }
        } catch (error) {
            this.mostrarMensagem('error', error.message);
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } finally {
            setTimeout(() => {
                this.processing = false;
            }, 300);
        }
    }

    async fazerRequisicao(action, productId = 0, quantity = 1) {
        const formData = new FormData();
        formData.append('action', action);
        formData.append('product_id', productId);
        formData.append('quantity', quantity);

        const response = await fetch('includes/processa_carrinho.php', {
            method: 'POST',
            body: formData
        });

        return await response.json();
    }

    mostrarMensagem(tipo, mensagem) {
        // Remover mensagens existentes
        const alertsExistentes = document.querySelectorAll('.alert');
        alertsExistentes.forEach(alert => alert.remove());

        const alertDiv = document.createElement('div');
        alertDiv.className = `alert alert-${tipo === 'success' ? 'success' : 'danger'} alert-dismissible fade show`;
        alertDiv.innerHTML = `
            ${mensagem}
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        `;

        const main = document.querySelector('main .container');
        if (main) {
            // Inserir após o cabeçalho do carrinho
            const cabecalho = main.querySelector('.d-flex.justify-content-between.align-items-center.mb-4');
            if (cabecalho && cabecalho.nextSibling) {
                main.insertBefore(alertDiv, cabecalho.nextSibling);
            } else {
                main.insertBefore(alertDiv, main.firstChild);
            }
        }

        // Auto-remover após 3 segundos
        setTimeout(() => {
            if (alertDiv.parentNode) {
                alertDiv.remove();
            }
        }, 3000);
    }
}

// Inicializar quando o DOM estiver carregado
document.addEventListener('DOMContentLoaded', function() {
    window.carrinhoManager = new CarrinhoManager();
});