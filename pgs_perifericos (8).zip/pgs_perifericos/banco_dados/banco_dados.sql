-- BANCO DE DADOS ATUALIZADO COM TABELAS SEPARADAS
-- porta do xampp é a 3309

CREATE DATABASE IF NOT EXISTS pgs_perifericos;
USE pgs_perifericos;

-- Tabela de usuários (mantida para compatibilidade)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('cliente','admin','funcionario') DEFAULT 'cliente',
    cpf VARCHAR(14) UNIQUE,
    telefone VARCHAR(15),
    data_nascimento DATE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE
);

-- NOVA TABELA: Clientes
CREATE TABLE clientes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNIQUE,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    cpf VARCHAR(14) UNIQUE NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    data_nascimento DATE NOT NULL,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    ativo BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- NOVA TABELA: Funcionários
CREATE TABLE funcionarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT UNIQUE,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    cpf VARCHAR(14) UNIQUE,
    telefone VARCHAR(15),
    data_nascimento DATE,
    cargo ENUM('administrador','estoquista','atendente','vendedor','gerente') NOT NULL,
    departamento VARCHAR(50) NOT NULL,
    data_admissao DATE NOT NULL,
    data_demissao DATE NULL,
    matricula VARCHAR(50) UNIQUE NULL,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de categorias
CREATE TABLE categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    descricao TEXT,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de marcas
CREATE TABLE marcas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    descricao TEXT,
    site_url VARCHAR(255),
    logo VARCHAR(255),
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de produtos
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    categoria_id INT,
    marca_id INT,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    especificacoes TEXT,
    preco DECIMAL(10,2) NOT NULL,
    preco_promocional DECIMAL(10,2),
    estoque INT DEFAULT 0,
    imagem VARCHAR(255),
    garantia_meses INT DEFAULT 12,
    ativo BOOLEAN DEFAULT TRUE,
    em_destaque BOOLEAN DEFAULT FALSE,
    em_promocao BOOLEAN DEFAULT FALSE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    media_avaliacoes DECIMAL(3,2) DEFAULT 0.00,
    total_avaliacoes INT DEFAULT 0,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id),
    FOREIGN KEY (marca_id) REFERENCES marcas(id)
);

-- Tabela de endereços dos clientes
CREATE TABLE enderecos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    titulo VARCHAR(50) NOT NULL,
    cep VARCHAR(9) NOT NULL,
    logradouro VARCHAR(200) NOT NULL,
    numero VARCHAR(10) NOT NULL,
    complemento VARCHAR(100),
    bairro VARCHAR(100) NOT NULL,
    cidade VARCHAR(100) NOT NULL,
    estado VARCHAR(2) NOT NULL,
    principal BOOLEAN DEFAULT FALSE,
    data_cadastro TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de pedidos
CREATE TABLE pedidos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cliente_id INT,
    total DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    desconto DECIMAL(10,2) DEFAULT 0,
    status ENUM('pendente','pago','processando','enviado','entregue','cancelado') DEFAULT 'pendente',
    metodo_pagamento ENUM('cartao','pix','boleto'),
    numero_cartao VARCHAR(20),
    nome_titular VARCHAR(100),
    data_vencimento DATE,
    codigo_seguranca VARCHAR(4),
    codigo_pix TEXT,
    codigo_boleto VARCHAR(50),
    data_pedido TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_pagamento TIMESTAMP NULL,
    data_envio TIMESTAMP NULL,
    endereco_entrega TEXT,
    FOREIGN KEY (cliente_id) REFERENCES usuarios(id)
);

-- Tabela de itens do pedido
CREATE TABLE itens_pedido (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pedido_id INT,
    produto_id INT,
    quantidade INT DEFAULT 1,
    preco_unitario DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
);

-- Tabela de avaliações
CREATE TABLE avaliacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    produto_id INT NOT NULL,
    usuario_id INT NOT NULL,
    pedido_id INT NOT NULL,
    nota INT NOT NULL CHECK (nota >= 1 AND nota <= 5),
    titulo VARCHAR(200),
    comentario TEXT,
    data_avaliacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    aprovado BOOLEAN DEFAULT TRUE,
    recomendacao ENUM('sim','nao') DEFAULT 'sim',
    FOREIGN KEY (produto_id) REFERENCES produtos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (pedido_id) REFERENCES pedidos(id),
    UNIQUE KEY unique_avaliacao (usuario_id, produto_id)
);

-- Tabela de cupons de desconto
CREATE TABLE cupons_desconto (
    id INT AUTO_INCREMENT PRIMARY KEY,
    codigo VARCHAR(50) UNIQUE NOT NULL,
    desconto_percentual DECIMAL(5,2),
    desconto_valor DECIMAL(10,2),
    data_validade DATE,
    usos_maximos INT,
    usos_atuais INT DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE,
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Inserir cupons de desconto de teste
INSERT INTO cupons_desconto (codigo, desconto_percentual, desconto_valor, data_validade, usos_maximos) VALUES 
('BEMVINDO10', 10.00, NULL, '2024-12-31', 100),
('PRIMEIRACOMPRA', NULL, 25.00, '2024-12-31', 50),
('PROMO15', 15.00, NULL, '2024-06-30', 200),
('FRETE100', NULL, 10.00, '2024-12-31', NULL);

-- Tabela de tickets de suporte
CREATE TABLE tickets_suporte (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT,
    assunto VARCHAR(200) NOT NULL,
    categoria ENUM('compra','produto','garantia','entrega','conta','outros') NOT NULL,
    descricao TEXT NOT NULL,
    status ENUM('aberto','em_andamento','respondido','fechado') DEFAULT 'aberto',
    prioridade ENUM('baixa','media','alta','urgente') DEFAULT 'media',
    data_abertura TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_ultima_resposta TIMESTAMP NULL,
    data_fechamento TIMESTAMP NULL,
    funcionario_responsavel INT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (funcionario_responsavel) REFERENCES funcionarios(id)
);

-- Tabela de mensagens do suporte
CREATE TABLE mensagens_suporte (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ticket_id INT,
    usuario_id INT,
    mensagem TEXT NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    eh_funcionario BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (ticket_id) REFERENCES tickets_suporte(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de FAQ
CREATE TABLE faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pergunta VARCHAR(255) NOT NULL,
    resposta TEXT NOT NULL,
    categoria ENUM('compra','produto','garantia','entrega','pagamento') NOT NULL,
    ordem INT DEFAULT 0,
    ativo BOOLEAN DEFAULT TRUE
);

-- Tabela de wishlist
CREATE TABLE wishlist (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    produto_id INT NOT NULL,
    data_adicao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (produto_id) REFERENCES produtos(id),
    UNIQUE KEY unique_wishlist (usuario_id, produto_id)
);

-- Índices para performance
CREATE INDEX idx_produtos_destaque ON produtos(em_destaque, ativo);
CREATE INDEX idx_produtos_promocao ON produtos(em_promocao, ativo);
CREATE INDEX idx_pedidos_status ON pedidos(status, data_pedido);
CREATE INDEX idx_tickets_status ON tickets_suporte(status, data_abertura);
CREATE INDEX idx_usuarios_email ON usuarios(email);
CREATE INDEX idx_funcionarios_email ON funcionarios(email);
CREATE INDEX idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX idx_pedidos_cliente ON pedidos(cliente_id);
CREATE INDEX idx_avaliacoes_produto ON avaliacoes(produto_id);
CREATE INDEX idx_avaliacoes_usuario ON avaliacoes(usuario_id);
CREATE INDEX idx_produtos_marca ON produtos(marca_id);
CREATE INDEX idx_marcas_nome ON marcas(nome);
CREATE INDEX idx_wishlist_usuario ON wishlist(usuario_id);

-- Dados iniciais
INSERT INTO categorias (nome, descricao) VALUES 
('Teclados', 'Teclados mecânicos, membrana e gaming'),
('Mouses', 'Mouses gamers, ópticos e sem fio'),
('Headsets', 'Fones de ouvido e headsets gamers'),
('Monitores', 'Monitores gaming e profissionais'),
('Mousepads', 'Mousepads speed e control'),
('Webcams', 'Webcams para streaming e reuniões'),
('Microfones', 'Microfones para streaming e gravação');

-- Inserir marcas populares
INSERT INTO marcas (nome, descricao, site_url) VALUES 
('Redragon', 'Marca especializada em periféricos gamers de alta qualidade', 'https://redragon.com.br'),
('Logitech', 'Líder mundial em periféricos para computador e gaming', 'https://logitech.com'),
('HyperX', 'Marca da Kingston focada em produtos para gaming', 'https://hyperx.com'),
('Dell', 'Fabricante de computadores e periféricos profissionais', 'https://dell.com'),
('Razer', 'Marca premium de periféricos para gaming', 'https://razer.com'),
('Corsair', 'Especialista em componentes e periféricos gamers', 'https://corsair.com'),
('SteelSeries', 'Marca dinamarquesa de equipamentos para gaming', 'https://steelseries.com'),
('ASUS', 'Fabricante de componentes e periféricos gamers ROG', 'https://asus.com');

-- Inserir dados de exemplo para clientes e funcionários
INSERT INTO usuarios (nome, email, senha, tipo, cpf, telefone, data_nascimento) VALUES 
('Administrador Master', 'admin@pgsecommerce.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin', '11122233344', '(11) 99999-9999', '1980-01-01'),
('João Estoquista', 'estoque@pgsecommerce.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario', '22233344455', '(11) 98888-8888', '1985-03-15'),
('Maria Atendente', 'atendimento@pgsecommerce.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario', '33344455566', '(11) 97777-7777', '1990-07-20'),
('Pedro Vendedor', 'vendas@pgsecommerce.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'funcionario', '44455566677', '(11) 96666-6666', '1988-11-10'),
('Cliente Teste', 'cliente@email.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'cliente', '55566677788', '(11) 95555-5555', '1995-05-25');

-- Inserir funcionários
INSERT INTO funcionarios (usuario_id, nome, email, cpf, telefone, data_nascimento, cargo, departamento, data_admissao, matricula) VALUES
(1, 'Administrador Master', 'admin@pgsecommerce.com', '11122233344', '(11) 99999-9999', '1980-01-01', 'administrador', 'Administração', '2023-01-01', 'PG001'),
(2, 'João Estoquista', 'estoque@pgsecommerce.com', '22233344455', '(11) 98888-8888', '1985-03-15', 'estoquista', 'Estoque', '2023-02-15', 'PG002'),
(3, 'Maria Atendente', 'atendimento@pgsecommerce.com', '33344455566', '(11) 97777-7777', '1990-07-20', 'atendente', 'Atendimento', '2023-03-20', 'PG003'),
(4, 'Pedro Vendedor', 'vendas@pgsecommerce.com', '44455566677', '(11) 96666-6666', '1988-11-10', 'vendedor', 'Vendas', '2023-04-10', 'PG004');

-- Inserir cliente
INSERT INTO clientes (usuario_id, nome, email, cpf, telefone, data_nascimento) VALUES
(5, 'Cliente Teste', 'cliente@email.com', '55566677788', '(11) 95555-5555', '1995-05-25');

-- INSERIR PRODUTOS NO BANCO DE DADOS

-- Inserir produtos
INSERT INTO produtos (categoria_id, marca_id, nome, descricao, especificacoes, preco, preco_promocional, estoque, garantia_meses, em_destaque, em_promocao, ativo, data_cadastro) VALUES

-- TECLADOS (2 produtos)
(1, 1, 'Teclado Mecânico Gamer Redragon Kumara RGB', 'Teclado mecânico gamer com switches Outemu Brown, iluminação RGB personalizável e design robusto. Ideal para jogos e trabalho.', 'Switches Outemu Brown\nLayout ABNT2\nAnti-ghosting N-Key Rollover\nIluminação RGB\nConstrução em ABS', 249.90, 199.90, 15, 12, 1, 1, 1, NOW()),
(1, 3, 'Teclado Mecânico Gamer HyperX Alloy Origins Core', 'Teclado mecânico compacto com switches HyperX Red, estrutura em alumínio e iluminação RGB vibrante.', 'Switches HyperX Red\nLayout Tenkeyless\nEstrutura em alumínio\nIluminação RGB dinâmica', 499.90, 449.90, 8, 24, 1, 0, 1, NOW());

-- Completando inserção de outros produtos...

SELECT 'Produtos inseridos com sucesso!' as status;
SELECT COUNT(*) as total_produtos FROM produtos;